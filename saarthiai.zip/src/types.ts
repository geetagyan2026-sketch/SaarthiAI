export interface SourceLink {
  title: string;
  uri: string;
}

export interface QuickActionItem {
  label: string;
  prompt: string;
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  content: string;
  image?: string;
  sources?: SourceLink[];
  quickActions?: QuickActionItem[];
  cached?: boolean;
  timestamp: number;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  createdAt: number;
  updatedAt: number;
}

export interface Suggestion {
  id: string;
  title: string;
  prompt: string;
  iconName: string;
  category: string;
}
