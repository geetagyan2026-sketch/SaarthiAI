import React, { useState, useEffect } from 'react';
import { ChatSession, Message } from './types';
import { generateSaarthiWithSources } from './lib/geminiService';
import { buildSmartRegionCardReply, RegionCardCategory } from './lib/regionCardGuides';
import { findRegionOption, isGlobalUnspecifiedLocation } from './lib/regions';
import { isAndroidApp } from './lib/platform';
import { Header } from './components/Header';
import { SidebarHistory } from './components/SidebarHistory';
import { WelcomeScreen } from './components/WelcomeScreen';
import { MessageList } from './components/MessageList';
import { PromptBar } from './components/PromptBar';
import { SettingsModal } from './components/SettingsModal';
import { ApkGuideModal } from './components/ApkGuideModal';
import { AdSenseBanner } from './components/AdSenseBanner';
import { AdMobBanner } from './components/AdMobBanner';
import { RewardedAdModal } from './components/RewardedAdModal';
import { ProPlansModal } from './components/ProPlansModal';
import { PrivacyPolicyModal } from './components/PrivacyPolicyModal';
import { TermsModal } from './components/TermsModal';
import { ContactModal } from './components/ContactModal';
import { AboutModal } from './components/AboutModal';
import { ResumeModal } from './components/ResumeModal';
import { PhotoStudioModal } from './components/PhotoStudioModal';
import { InvitationModal } from './components/InvitationModal';
import { PanchangModal } from './components/PanchangModal';
import { DailyHelperModal } from './components/DailyHelperModal';
import { ToolsDrawer } from './components/ToolsDrawer';
import { OfflineIndicator } from './components/OfflineIndicator';

const STORAGE_KEY = 'saarthi_ai_chat_sessions_v11';
const PRO_STATUS_KEY = 'saarthi_pro_status';

export default function App() {
  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.error(e);
    }
    return [
      {
        id: 'session-1',
        title: 'नई बातचीत',
        messages: [],
        createdAt: Date.now(),
        updatedAt: Date.now(),
      },
    ];
  });

  const [currentSessionId, setCurrentSessionId] = useState<string>(() => sessions[0]?.id || 'session-1');
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('saarthi_dark_mode') === 'true' || true;
  });

  const [language, setLanguage] = useState<string>(() => localStorage.getItem('saarthi_lang') || 'hi');
  const [location, setLocation] = useState<string>(() => {
    const savedLoc = localStorage.getItem('saarthi_location');
    if (savedLoc) return savedLoc;
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
    const lang = navigator.language || '';
    if (tz.includes('Kolkata') || lang.includes('IN') || lang.includes('hi')) {
      return '🇮🇳 India — Rajasthan';
    }
    return '🌍 Global / World';
  });

  const [isPro, setIsPro] = useState<boolean>(() => {
    try {
      const proRecord = localStorage.getItem(PRO_STATUS_KEY);
      if (proRecord) {
        const data = JSON.parse(proRecord);
        if (data.expiresAt && data.expiresAt > Date.now()) {
          return true;
        }
      }
    } catch (e) {
      console.error(e);
    }
    return false;
  });

  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isToolsDrawerOpen, setIsToolsDrawerOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isApkGuideOpen, setIsApkGuideOpen] = useState(false);
  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false);
  const [isTermsOpen, setIsTermsOpen] = useState(false);
  const [isContactOpen, setIsContactOpen] = useState(false);
  const [isAboutOpen, setIsAboutOpen] = useState(false);
  const [isResumeModalOpen, setIsResumeModalOpen] = useState(false);
  const [isPhotoStudioModalOpen, setIsPhotoStudioModalOpen] = useState(false);
  const [isInvitationModalOpen, setIsInvitationModalOpen] = useState(false);
  const [isPanchangModalOpen, setIsPanchangModalOpen] = useState(false);
  const [isDailyHelperModalOpen, setIsDailyHelperModalOpen] = useState(false);
  const [isRewardedAdOpen, setIsRewardedAdOpen] = useState(false);
  const [isProPlansOpen, setIsProPlansOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Pending action for 1-use watch ad flow
  const [pendingAction, setPendingAction] = useState<(() => void) | null>(null);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions));
  }, [sessions]);

  useEffect(() => {
    localStorage.setItem('saarthi_dark_mode', String(darkMode));
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  useEffect(() => {
    localStorage.setItem('saarthi_lang', language);
  }, [language]);

  useEffect(() => {
    localStorage.setItem('saarthi_location', location);
  }, [location]);

  const currentSession = sessions.find((s) => s.id === currentSessionId) || sessions[0];

  const handleNewChat = () => {
    const newSession: ChatSession = {
      id: 'session-' + Date.now(),
      title: language === 'en' ? 'New Chat' : 'नई बातचीत',
      messages: [],
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    setSessions((prev) => [newSession, ...prev]);
    setCurrentSessionId(newSession.id);
  };

  const handleDeleteSession = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = sessions.filter((s) => s.id !== id);
    if (updated.length === 0) {
      const fresh: ChatSession = {
        id: 'session-' + Date.now(),
        title: language === 'en' ? 'New Chat' : 'नई बातचीत',
        messages: [],
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      setSessions([fresh]);
      setCurrentSessionId(fresh.id);
    } else {
      setSessions(updated);
      if (currentSessionId === id) {
        setCurrentSessionId(updated[0].id);
      }
    }
  };

  const executeActionWithAdCheck = (action: () => void) => {
    if (isPro) {
      action();
      return;
    }
    // Free user: Require viewing 6s ad before unlocking this single action
    setPendingAction(() => action);
    setIsRewardedAdOpen(true);
  };

  const handleSendMessage = (promptText: string, image?: string) => {
    executeActionWithAdCheck(() => performSendMessage(promptText, image));
  };

  const performSendMessage = async (promptText: string, image?: string) => {
    const cleanPrompt = promptText.trim();
    if (!image && /^(📝\s*)?(ऑनलाइन फॉर्म भरें|online form apply|apply online form)$/i.test(cleanPrompt)) {
      handleStartOnlineForm();
      return;
    }

    const userMsg: Message = {
      id: 'msg-' + Date.now(),
      role: 'user',
      content: promptText,
      image,
      timestamp: Date.now(),
    };

    const updatedMessages = [...currentSession.messages, userMsg];
    const sessionTitle =
      currentSession.messages.length === 0
        ? promptText.length > 30
          ? promptText.slice(0, 30) + '...'
          : promptText
        : currentSession.title;

    setSessions((prev) =>
      prev.map((s) =>
        s.id === currentSessionId
          ? { ...s, title: sessionTitle, messages: updatedMessages, updatedAt: Date.now() }
          : s
      )
    );

    setIsLoading(true);

    try {
      const isActiveGlobal = isGlobalUnspecifiedLocation(location);
      const historyForApi = currentSession.messages
        .filter((m) => {
          if (isActiveGlobal) return true;
          return !/Global\s*\/\s*World\s*(पर\s*सेट|set)|region is currently set to \*\*Global/i.test(m.content);
        })
        .map((m) => ({
          role: m.role,
          content: m.content,
        }));

      const { text: replyText, sources, cached } = await generateSaarthiWithSources(
        promptText,
        historyForApi,
        image,
        language,
        location
      );

      const aiMsg: Message = {
        id: 'msg-' + (Date.now() + 1),
        role: 'model',
        content: replyText,
        sources,
        cached,
        timestamp: Date.now(),
      };

      setSessions((prev) =>
        prev.map((s) =>
          s.id === currentSessionId
            ? { ...s, messages: [...s.messages, aiMsg], updatedAt: Date.now() }
            : s
        )
      );
    } catch (err: unknown) {
      console.warn(err);
      const fallbackMsg: Message = {
        id: 'msg-' + (Date.now() + 1),
        role: 'model',
        content:
          language === 'en'
            ? `Please ask your question again or check the official portal for ${location}.`
            : `कृपया अपना प्रश्न पुनः पूछें। SaarthiAI आपके लिए जानकारी तैयार कर रहा है।`,
        timestamp: Date.now(),
      };
      setSessions((prev) =>
        prev.map((s) =>
          s.id === currentSessionId
            ? { ...s, messages: [...s.messages, fallbackMsg], updatedAt: Date.now() }
            : s
        )
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleStartOnlineForm = () => {
    executeActionWithAdCheck(() => performStartOnlineForm());
  };

  const performStartOnlineForm = () => {
    const now = Date.now();
    const userPrompt =
      language === 'en'
        ? '📝 I want to fill an online form (Job, Admission, or Govt Service)'
        : '📝 मुझे ऑनलाइन फॉर्म भरना है (नौकरी, एडमिशन या सरकारी फॉर्म)';

    const assistantPrompt =
      language === 'en'
        ? [
            `### 📝 Online Form Guide — Which form would you like to fill?`,
            `Please type the name of the form you want to apply for, for example:`,
            `• **Govt Jobs:** RPSC, RSSB, SSC CGL/CHSL, UPSC, Railway RRB, UP Police`,
            `• **School / College Admission:** University UG/PG Admission, CUET, NEET, JEE, Scholarship`,
            `• **Citizen / Govt Services:** PAN Card, Passport, Caste / Domicile / Income Certificate (e-Mitra), PM-KISAN`,
            ``,
            `As soon as you reply with the form name, I will give you the **required documents list, exact fee, step-by-step form-filling guide, and a direct button to open the official portal**.`,
          ].join('\n')
        : [
            `### 📝 ऑनलाइन फॉर्म सहायक — आप कौन-सा फॉर्म भरना चाहते हैं?`,
            `कृपया नीचे चैट में उस फॉर्म का नाम लिखकर भेजें जिसे आप भरना चाहते हैं, जैसे:`,
            `• **सरकारी नौकरी / भर्ती:** RPSC, RSSB, SSC CGL/CHSL, UPSC, Railway, Police`,
            `• **स्कूल / कॉलेज एडमिशन:** कॉलेज प्रवेश, CUET, NEET, JEE, छात्रवृत्ति (Scholarship)`,
            `• **ई-मित्र / सरकारी कार्ड:** पैन कार्ड (PAN Card), पासपोर्ट, जाति / मूल निवास / आय प्रमाण पत्र, PM किसान`,
            ``,
            `जैसे ही आप फॉर्म का नाम लिखेंगे, मैं आपको यहीं चैट में **आवश्यक डॉक्यूमेंट की लिस्ट, आवेदन शुल्क (Fees), फॉर्म भरने की पूरी स्टेप-बाय-स्टेप प्रक्रिया और असली सरकारी पोर्टल पर फॉर्म भरने का सीधा बटन** दे दूंगा!`,
          ].join('\n');

    const isGlobalLoc = isGlobalUnspecifiedLocation(location);
    const activeReg = findRegionOption(location);
    const activeRegShort = activeReg.shortName;
    const isRajasthanSelected = /rajasthan/i.test(activeReg.value);
    const isMpSelected = /madhya pradesh/i.test(activeReg.value);
    const isBiharSelected = /bihar/i.test(activeReg.value);
    const isUpSelected = /uttar pradesh/i.test(activeReg.value);
    const isIndiaScope = activeReg.scope === 'india';

    const citizenQuickAction = isMpSelected
      ? {
          label: '🆔 समग्र / मूल निवास / जाति (MPOnline)',
          prompt: 'मध्य प्रदेश समग्र आईडी, मूल निवास, जाति व आय प्रमाण पत्र (mpedistrict.gov.in / mponline.gov.in) की प्रक्रिया, फीस और दस्तावेज़ बताएं',
        }
      : isBiharSelected
        ? {
            label: '🆔 आवासीय / जाति / आय (RTPS Bihar)',
            prompt: 'बिहार RTPS (serviceonline.bihar.gov.in) पर आवासीय, जाति और आय प्रमाण पत्र की फीस, दस्तावेज़ और आवेदन प्रक्रिया बताएं',
          }
        : isUpSelected
          ? {
              label: '🆔 आय / जाति / निवास (e-District UP)',
              prompt: 'उत्तर प्रदेश e-District (edistrict.up.gov.in) पर आय, जाति और निवास प्रमाण पत्र की ₹15 फीस, दस्तावेज़ और प्रक्रिया बताएं',
            }
          : isRajasthanSelected
            ? {
                label: '🆔 जन आधार / मूल निवास / जाति प्रमाण पत्र',
                prompt: 'राजस्थान जन आधार / मूल निवास / जाति प्रमाण पत्र (sso.rajasthan.gov.in ई-मित्र) ऑनलाइन फॉर्म की प्रक्रिया, फीस और दस्तावेज़ बताएं',
              }
            : !isGlobalLoc && !isIndiaScope
              ? {
                  label: `🏛️ ${activeRegShort} Digital Citizen Portal`,
                  prompt: `Explain ${activeRegShort} official Digital Citizen Portal (${activeReg.citizenGuide?.portalDomain || activeReg.domainHint}) services, fees, required documents, and step-by-step application process.`,
                }
              : !isGlobalLoc && isIndiaScope && !/all india/i.test(activeReg.value)
                ? {
                    label: `🆔 जाति / मूल निवास / आय (${activeRegShort})`,
                    prompt: `${activeRegShort} (${activeReg.citizenGuide?.portalDomain || activeReg.domainHint}) में जाति, मूल निवास और आय प्रमाण पत्र ऑनलाइन फॉर्म की प्रक्रिया, फीस और दस्तावेज़ बताएं`,
                  }
                : {
                    label: '🆔 जाति / मूल निवास / आय (e-District / राज्य पोर्टल)',
                    prompt: 'भारत के विभिन्न राज्यों (MPOnline, RTPS Bihar, e-District UP, Rajasthan SSO) में जाति, मूल निवास और आय प्रमाण पत्र बनवाने की प्रक्रिया बताएं',
                  };

    const jobQuickAction = isMpSelected
      ? {
          label: '📋 MPPSC / MPESB / SSC सरकारी नौकरी फॉर्म',
          prompt: 'मध्य प्रदेश MPPSC, MPESB (esb.mp.gov.in) व SSC सरकारी नौकरी फॉर्म 2026 की योग्यता, आयु सीमा, तिथियां, फीस और आवेदन प्रक्रिया बताएं',
        }
      : isBiharSelected
        ? {
            label: '📋 BPSC / BSSC / SSC सरकारी नौकरी फॉर्म',
            prompt: 'बिहार BPSC, BSSC व SSC सरकारी नौकरी फॉर्म 2026 की योग्यता, आयु सीमा, तिथियां, फीस और आवेदन प्रक्रिया बताएं',
          }
        : isUpSelected
          ? {
              label: '📋 UPPSC / UP Police / SSC नौकरी फॉर्म',
              prompt: 'उत्तर प्रदेश UPPSC, UP Police व UPSSSC सरकारी नौकरी फॉर्म 2026 की योग्यता, आयु सीमा, तिथियां, फीस और आवेदन प्रक्रिया बताएं',
            }
          : isRajasthanSelected
            ? {
                label: '📋 RPSC / RSSB / SSC सरकारी नौकरी फॉर्म',
                prompt: 'राजस्थान RPSC, RSSB व SSC सरकारी नौकरी ऑनलाइन फॉर्म 2026 की योग्यता, आयु सीमा, तिथियां, फीस और आवेदन प्रक्रिया बताएं',
              }
            : !isGlobalLoc && !isIndiaScope
              ? {
                  label: `🛂 ${activeRegShort} Visa & Work Permit Form`,
                  prompt: `Explain ${activeRegShort} official Work Visa / Residency application form, fees, documents, and step-by-step process.`,
                }
              : {
                  label: '📋 UPSC / SSC / राज्य सरकारी नौकरी फॉर्म',
                  prompt: 'UPSC, SSC व राज्य सरकारी नौकरी ऑनलाइन फॉर्म 2026 की योग्यता, आयु सीमा, तिथियां, फीस और आवेदन प्रक्रिया बताएं',
                };

    const quickActions = !isGlobalLoc && !isIndiaScope
      ? [
          citizenQuickAction,
          jobQuickAction,
          {
            label: `🎓 ${activeRegShort} University Admission Form`,
            prompt: `Explain ${activeRegShort} university admission form, student visa requirements, fees, and deadlines.`,
          },
          {
            label: '🛂 Indian Passport / OCI / Visa Guide',
            prompt: 'पासपोर्ट (Passport) / OCI ऑनलाइन आवेदन फॉर्म की प्रक्रिया, सरकारी फीस और दस्तावेज़ बताएं',
          },
        ]
      : [
          {
            label: '💳 पैन कार्ड (PAN Card) फॉर्म',
            prompt: 'पैन कार्ड (PAN Card) ऑनलाइन आवेदन फॉर्म की प्रक्रिया, असली सरकारी फीस और दस्तावेज़ बताएं',
          },
          {
            label: '🛂 पासपोर्ट (Passport) आवेदन',
            prompt: 'पासपोर्ट (Passport) ऑनलाइन आवेदन फॉर्म की प्रक्रिया, सरकारी फीस और दस्तावेज़ बताएं',
          },
          citizenQuickAction,
          jobQuickAction,
          {
            label: '🎓 स्कूल / कॉलेज एडमिशन फॉर्म',
            prompt: `${isGlobalLoc ? '' : activeRegShort + ' '}स्कूल / कॉलेज एडमिशन फॉर्म 2026 की पात्रता, कोर्स, अंतिम तारीख, फीस और प्रवेश प्रक्रिया बताएं`,
          },
          {
            label: isMpSelected ? '🍚 लाड़ली बहना / राशन / आयुष्मान (MP)' : '🍚 राशन कार्ड / आयुष्मान कार्ड',
            prompt: isMpSelected
              ? 'मध्य प्रदेश में लाड़ली बहना योजना, राशन कार्ड और आयुष्मान भारत कार्ड ऑनलाइन आवेदन की प्रक्रिया, फीस और दस्तावेज़ बताएं'
              : `${isGlobalLoc ? '' : activeRegShort + ' '}राशन कार्ड और आयुष्मान भारत कार्ड ऑनलाइन आवेदन की प्रक्रिया, फीस और दस्तावेज़ बताएं`,
          },
        ];

    const userMsg: Message = {
      id: 'msg-' + now,
      role: 'user',
      content: userPrompt,
      timestamp: now,
    };
    const aiMsg: Message = {
      id: 'msg-' + (now + 1),
      role: 'model',
      content: assistantPrompt,
      quickActions,
      timestamp: now + 1,
    };

    const sessionTitle =
      currentSession.messages.length === 0
        ? language === 'en'
          ? 'Online Form Apply'
          : 'ऑनलाइन फॉर्म भरें'
        : currentSession.title;

    setSessions((prev) =>
      prev.map((s) =>
        s.id === currentSessionId
          ? {
              ...s,
              title: sessionTitle,
              messages: [...s.messages, userMsg, aiMsg],
              updatedAt: Date.now(),
            }
          : s
      )
    );
  };

  const handleRegionCardClick = (category: RegionCardCategory) => {
    executeActionWithAdCheck(() => performRegionCardClick(category));
  };

  const performRegionCardClick = (category: RegionCardCategory) => {
    const now = Date.now();
    const smartReply = buildSmartRegionCardReply(category, location, language);

    const userMsg: Message = {
      id: 'msg-' + now,
      role: 'user',
      content: smartReply.userPrompt,
      timestamp: now,
    };

    const aiMsg: Message = {
      id: 'msg-' + (now + 1),
      role: 'model',
      content: smartReply.assistantText,
      sources: smartReply.sources,
      quickActions: smartReply.quickActions,
      timestamp: now + 1,
    };

    const sessionTitle =
      currentSession.messages.length === 0
        ? smartReply.userPrompt.slice(0, 30)
        : currentSession.title;

    setSessions((prev) =>
      prev.map((s) =>
        s.id === currentSessionId
          ? {
              ...s,
              title: sessionTitle,
              messages: [...s.messages, userMsg, aiMsg],
              updatedAt: Date.now(),
            }
          : s
      )
    );
  };

  const handleRegenerate = async () => {
    if (currentSession.messages.length === 0 || isLoading) return;
    const lastUserMsgIndex = [...currentSession.messages].reverse().findIndex((m) => m.role === 'user');
    if (lastUserMsgIndex === -1) return;
    const lastUserMsg = currentSession.messages[currentSession.messages.length - 1 - lastUserMsgIndex];

    const trimmedMessages = currentSession.messages.slice(0, currentSession.messages.length - 1);
    setSessions((prev) =>
      prev.map((s) => (s.id === currentSessionId ? { ...s, messages: trimmedMessages } : s))
    );

    await handleSendMessage(lastUserMsg.content, lastUserMsg.image);
  };

  const handleRewardGranted = () => {
    if (pendingAction) {
      const action = pendingAction;
      setPendingAction(null);
      action();
    }
  };

  return (
    <div
      className={`min-h-dvh flex flex-col font-sans overflow-x-hidden transition-colors duration-200 ${
        darkMode ? 'bg-gray-950 text-gray-100 dark' : 'bg-gray-50 text-gray-900'
      }`}
    >
      <Header
        onNewChat={handleNewChat}
        onToggleHistory={() => setIsHistoryOpen(true)}
        onOpenToolsDrawer={() => setIsToolsDrawerOpen(true)}
        language={language}
        onLanguageChange={setLanguage}
        location={location}
        onLocationChange={setLocation}
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenApkGuide={() => setIsApkGuideOpen(true)}
        onOpenPrivacy={() => setIsPrivacyOpen(true)}
        onOpenAbout={() => setIsAboutOpen(true)}
        onOpenProPlans={() => setIsProPlansOpen(true)}
        isPro={isPro}
      />

      <SidebarHistory
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        sessions={sessions}
        currentSessionId={currentSessionId}
        onSelectSession={setCurrentSessionId}
        onNewChat={handleNewChat}
        onDeleteSession={handleDeleteSession}
        darkMode={darkMode}
        onOpenApkGuide={() => setIsApkGuideOpen(true)}
      />

      <ToolsDrawer
        isOpen={isToolsDrawerOpen}
        onClose={() => setIsToolsDrawerOpen(false)}
        onOpenResumeModal={() => executeActionWithAdCheck(() => setIsResumeModalOpen(true))}
        onOpenPhotoStudioModal={() => executeActionWithAdCheck(() => setIsPhotoStudioModalOpen(true))}
        onOpenInvitationModal={() => executeActionWithAdCheck(() => setIsInvitationModalOpen(true))}
        onOpenPanchangModal={() => executeActionWithAdCheck(() => setIsPanchangModalOpen(true))}
        onOpenDailyHelperModal={() => executeActionWithAdCheck(() => setIsDailyHelperModalOpen(true))}
        onSelectSuggestion={(prompt) => handleSendMessage(prompt)}
        onSelectRegionCard={handleRegionCardClick}
        location={location}
        darkMode={darkMode}
      />

      <main className="flex-1 flex flex-col relative max-w-5xl mx-auto w-full">
        {currentSession.messages.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center">
            <WelcomeScreen
              onSelectSuggestion={(prompt) => handleSendMessage(prompt)}
              onSelectRegionCard={handleRegionCardClick}
              onStartOnlineForm={handleStartOnlineForm}
              onOpenResumeModal={() => executeActionWithAdCheck(() => setIsResumeModalOpen(true))}
              onOpenPhotoStudioModal={() => executeActionWithAdCheck(() => setIsPhotoStudioModalOpen(true))}
              onOpenInvitationModal={() => executeActionWithAdCheck(() => setIsInvitationModalOpen(true))}
              onOpenPanchangModal={() => executeActionWithAdCheck(() => setIsPanchangModalOpen(true))}
              onOpenDailyHelperModal={() => executeActionWithAdCheck(() => setIsDailyHelperModalOpen(true))}
              location={location}
              darkMode={darkMode}
            />
            {!isPro && (
              <div className="w-full max-w-xl px-4 pb-4">
                <AdSenseBanner slotId="welcome-ad-slot" />
              </div>
            )}
          </div>
        ) : (
          <MessageList
            messages={currentSession.messages}
            isLoading={isLoading}
            onRegenerate={handleRegenerate}
            onQuickAction={(prompt) => handleSendMessage(prompt)}
            language={language}
            darkMode={darkMode}
          />
        )}

        <PromptBar
          onSendMessage={handleSendMessage}
          isLoading={isLoading}
          language={language}
          darkMode={darkMode}
        />
      </main>

      {!isPro && <AdMobBanner />}

      <footer
        className={`py-3 px-4 border-t text-center text-xs flex flex-wrap items-center justify-center gap-3 sm:gap-4 ${
          darkMode ? 'bg-gray-900/80 border-gray-800 text-gray-400' : 'bg-white border-gray-200 text-gray-600'
        }`}
      >
        <button onClick={() => setIsAboutOpen(true)} className="hover:underline">
          About Us
        </button>
        <span>•</span>
        <button onClick={() => setIsPrivacyOpen(true)} className="hover:underline">
          Privacy Policy
        </button>
        <span>•</span>
        <button onClick={() => setIsTermsOpen(true)} className="hover:underline">
          Terms &amp; Conditions
        </button>
        <span>•</span>
        <button onClick={() => setIsContactOpen(true)} className="hover:underline">
          Contact Us
        </button>
        <span>•</span>
        <button onClick={() => setIsApkGuideOpen(true)} className="hover:underline">
          APK Guide
        </button>
      </footer>

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        language={language}
        onLanguageChange={setLanguage}
        location={location}
        onLocationChange={setLocation}
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
        onOpenApkGuide={() => setIsApkGuideOpen(true)}
      />

      <ApkGuideModal
        isOpen={isApkGuideOpen}
        onClose={() => setIsApkGuideOpen(false)}
        darkMode={darkMode}
      />

      <PrivacyPolicyModal
        isOpen={isPrivacyOpen}
        onClose={() => setIsPrivacyOpen(false)}
        darkMode={darkMode}
      />

      <TermsModal
        isOpen={isTermsOpen}
        onClose={() => setIsTermsOpen(false)}
        darkMode={darkMode}
      />

      <ContactModal
        isOpen={isContactOpen}
        onClose={() => setIsContactOpen(false)}
        darkMode={darkMode}
      />

      <AboutModal
        isOpen={isAboutOpen}
        onClose={() => setIsAboutOpen(false)}
        darkMode={darkMode}
      />

      <ResumeModal
        isOpen={isResumeModalOpen}
        onClose={() => setIsResumeModalOpen(false)}
        darkMode={darkMode}
      />

      <PhotoStudioModal
        isOpen={isPhotoStudioModalOpen}
        onClose={() => setIsPhotoStudioModalOpen(false)}
        darkMode={darkMode}
      />

      <InvitationModal
        isOpen={isInvitationModalOpen}
        onClose={() => setIsInvitationModalOpen(false)}
        darkMode={darkMode}
      />

      <PanchangModal
        isOpen={isPanchangModalOpen}
        onClose={() => setIsPanchangModalOpen(false)}
        darkMode={darkMode}
        language={language}
        location={location}
      />

      <DailyHelperModal
        isOpen={isDailyHelperModalOpen}
        onClose={() => setIsDailyHelperModalOpen(false)}
        darkMode={darkMode}
        language={language}
        location={location}
      />

      <RewardedAdModal
        isOpen={isRewardedAdOpen}
        onClose={() => {
          setIsRewardedAdOpen(false);
          setPendingAction(null);
        }}
        onRewardGranted={handleRewardGranted}
        onOpenProPlans={() => setIsProPlansOpen(true)}
        darkMode={darkMode}
      />

      <ProPlansModal
        isOpen={isProPlansOpen}
        onClose={() => setIsProPlansOpen(false)}
        location={location}
        darkMode={darkMode}
        onActivatePro={(days) => {
          const expiresAt = Date.now() + days * 24 * 60 * 60 * 1000;
          localStorage.setItem(PRO_STATUS_KEY, JSON.stringify({ expiresAt, activatedAt: Date.now() }));
          setIsPro(true);
        }}
      />

      <OfflineIndicator />
    </div>
  );
}
