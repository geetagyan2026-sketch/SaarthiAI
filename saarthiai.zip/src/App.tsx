import React, { useState, useEffect } from 'react';
import { ChatSession, Message } from './types';
import { generateSaarthiResponse } from './lib/geminiService';
import { isAndroidApp } from './lib/platform';
import { Header } from './components/Header';
import { SidebarHistory } from './components/SidebarHistory';
import { WelcomeScreen } from './components/WelcomeScreen';
import { MessageList } from './components/MessageList';
import { PromptBar } from './components/PromptBar';
import { SettingsModal } from './components/SettingsModal';
import { ApkGuideModal } from './components/ApkGuideModal';
import { AdSenseBanner } from './components/AdSenseBanner';
import { AdMobBanner } from './components/AdMobBanner';
import { RewardedAdModal } from './components/RewardedAdModal';
import { PrivacyPolicyModal } from './components/PrivacyPolicyModal';
import { AboutModal } from './components/AboutModal';
import { ResumeModal } from './components/ResumeModal';
import { PhotoStudioModal } from './components/PhotoStudioModal';
import { InvitationModal } from './components/InvitationModal';
import { PanchangModal } from './components/PanchangModal';
import { ExamModal } from './components/ExamModal';
import { DailyHelperModal } from './components/DailyHelperModal';
import { ToolsDrawer } from './components/ToolsDrawer';

const STORAGE_KEY = 'saarthi_ai_chat_sessions_v10';
const DAILY_QUOTA_KEY = 'saarthi_daily_quota';
const DAILY_LIMIT = 3;

export default function App() {
  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.error(e);
    }
    return [
      {
        id: 'session-1',
        title: 'नई बातचीत',
        messages: [],
        createdAt: Date.now(),
        updatedAt: Date.now(),
      },
    ];
  });

  const [currentSessionId, setCurrentSessionId] = useState<string>(() => sessions[0]?.id || 'session-1');
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('saarthi_dark_mode') === 'true' || true;
  });

  const [language, setLanguage] = useState<string>(() => localStorage.getItem('saarthi_lang') || 'hi');
  const [location, setLocation] = useState<string>(() => localStorage.getItem('saarthi_location') || '🌍 Global / World');

  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isToolsDrawerOpen, setIsToolsDrawerOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isApkGuideOpen, setIsApkGuideOpen] = useState(false);
  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false);
  const [isAboutOpen, setIsAboutOpen] = useState(false);
  const [isResumeModalOpen, setIsResumeModalOpen] = useState(false);
  const [isPhotoStudioModalOpen, setIsPhotoStudioModalOpen] = useState(false);
  const [isInvitationModalOpen, setIsInvitationModalOpen] = useState(false);
  const [isPanchangModalOpen, setIsPanchangModalOpen] = useState(false);
  const [isExamModalOpen, setIsExamModalOpen] = useState(false);
  const [isDailyHelperModalOpen, setIsDailyHelperModalOpen] = useState(false);
  const [isRewardedAdOpen, setIsRewardedAdOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const [questionCount, setQuestionCount] = useState<number>(() => {
    try {
      const record = localStorage.getItem(DAILY_QUOTA_KEY);
      if (record) {
        const data = JSON.parse(record);
        const today = new Date().toDateString();
        if (data.date === today) {
          return data.count || 0;
        }
      }
    } catch (e) {
      console.error(e);
    }
    return 0;
  });

  const isApp = isAndroidApp();

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions));
  }, [sessions]);

  useEffect(() => {
    localStorage.setItem('saarthi_dark_mode', String(darkMode));
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  useEffect(() => {
    localStorage.setItem('saarthi_lang', language);
  }, [language]);

  useEffect(() => {
    localStorage.setItem('saarthi_location', location);
  }, [location]);

  const updateQuota = (newCount: number) => {
    setQuestionCount(newCount);
    localStorage.setItem(DAILY_QUOTA_KEY, JSON.stringify({
      date: new Date().toDateString(),
      count: newCount,
    }));
  };

  const currentSession = sessions.find(s => s.id === currentSessionId) || sessions[0];

  const handleNewChat = () => {
    const newSession: ChatSession = {
      id: 'session-' + Date.now(),
      title: language === 'en' ? 'New Chat' : 'नई बातचीत',
      messages: [],
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    setSessions(prev => [newSession, ...prev]);
    setCurrentSessionId(newSession.id);
  };

  const handleDeleteSession = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = sessions.filter(s => s.id !== id);
    if (updated.length === 0) {
      const fresh: ChatSession = {
        id: 'session-' + Date.now(),
        title: language === 'en' ? 'New Chat' : 'नई बातचीत',
        messages: [],
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      setSessions([fresh]);
      setCurrentSessionId(fresh.id);
    } else {
      setSessions(updated);
      if (currentSessionId === id) {
        setCurrentSessionId(updated[0].id);
      }
    }
  };

  const handleSendMessage = async (promptText: string, image?: string) => {
    if (isApp && questionCount >= DAILY_LIMIT) {
      setIsRewardedAdOpen(true);
      return;
    }

    const userMsg: Message = {
      id: 'msg-' + Date.now(),
      role: 'user',
      content: promptText,
      image,
      timestamp: Date.now(),
    };

    const updatedMessages = [...currentSession.messages, userMsg];
    const sessionTitle = currentSession.messages.length === 0
      ? (promptText.length > 30 ? promptText.slice(0, 30) + '...' : promptText)
      : currentSession.title;

    setSessions(prev =>
      prev.map(s =>
        s.id === currentSessionId
          ? { ...s, title: sessionTitle, messages: updatedMessages, updatedAt: Date.now() }
          : s
      )
    );

    if (isApp) {
      updateQuota(questionCount + 1);
    }

    setIsLoading(true);

    try {
      const historyForApi = currentSession.messages.map(m => ({
        role: m.role,
        content: m.content,
      }));

      const replyText = await generateSaarthiResponse(promptText, historyForApi, image, language, location);

      const aiMsg: Message = {
        id: 'msg-' + (Date.now() + 1),
        role: 'model',
        content: replyText,
        timestamp: Date.now(),
      };

      setSessions(prev =>
        prev.map(s =>
          s.id === currentSessionId
            ? { ...s, messages: [...s.messages, aiMsg], updatedAt: Date.now() }
            : s
        )
      );
    } catch (err: any) {
      console.error(err);
      const errorMsg: Message = {
        id: 'msg-' + (Date.now() + 1),
        role: 'model',
        content: language === 'en' ? 'Sorry, error getting response.' : 'माफ़ कीजिए, उत्तर प्राप्त करने में तकनीकी समस्या हुई।',
        timestamp: Date.now(),
      };
      setSessions(prev =>
        prev.map(s =>
          s.id === currentSessionId
            ? { ...s, messages: [...s.messages, errorMsg], updatedAt: Date.now() }
            : s
        )
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegenerate = async () => {
    if (currentSession.messages.length === 0 || isLoading) return;
    const lastUserMsgIndex = [...currentSession.messages].reverse().findIndex(m => m.role === 'user');
    if (lastUserMsgIndex === -1) return;
    const lastUserMsg = currentSession.messages[currentSession.messages.length - 1 - lastUserMsgIndex];

    const trimmedMessages = currentSession.messages.slice(0, currentSession.messages.length - 1);
    setSessions(prev =>
      prev.map(s =>
        s.id === currentSessionId ? { ...s, messages: trimmedMessages } : s
      )
    );

    await handleSendMessage(lastUserMsg.content, lastUserMsg.image);
  };

  const handleRewardGranted = () => {
    updateQuota(Math.max(0, questionCount - 2));
  };

  return (
    <div className={`min-h-screen flex flex-col font-sans transition-colors duration-200 ${
      darkMode ? 'bg-gray-950 text-gray-100 dark' : 'bg-gray-50 text-gray-900'
    }`}>
      <Header
        onNewChat={handleNewChat}
        onToggleHistory={() => setIsHistoryOpen(true)}
        onOpenToolsDrawer={() => setIsToolsDrawerOpen(true)}
        language={language}
        onLanguageChange={setLanguage}
        location={location}
        onLocationChange={setLocation}
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenApkGuide={() => setIsApkGuideOpen(true)}
        onOpenPrivacy={() => setIsPrivacyOpen(true)}
        onOpenAbout={() => setIsAboutOpen(true)}
      />

      <SidebarHistory
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        sessions={sessions}
        currentSessionId={currentSessionId}
        onSelectSession={setCurrentSessionId}
        onDeleteSession={handleDeleteSession}
        onNewChat={handleNewChat}
        darkMode={darkMode}
        onOpenApkGuide={() => setIsApkGuideOpen(true)}
      />

      <ToolsDrawer
        isOpen={isToolsDrawerOpen}
        onClose={() => setIsToolsDrawerOpen(false)}
        onOpenResumeModal={() => setIsResumeModalOpen(true)}
        onOpenPhotoStudioModal={() => setIsPhotoStudioModalOpen(true)}
        onOpenInvitationModal={() => setIsInvitationModalOpen(true)}
        onOpenPanchangModal={() => setIsPanchangModalOpen(true)}
        onOpenExamModal={() => setIsExamModalOpen(true)}
        onOpenDailyHelperModal={() => setIsDailyHelperModalOpen(true)}
        onSelectSuggestion={(prompt) => handleSendMessage(prompt)}
        darkMode={darkMode}
      />

      <main className="flex-1 flex flex-col overflow-hidden relative pb-12">
        {currentSession.messages.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center">
            <WelcomeScreen
              onSelectSuggestion={(prompt) => handleSendMessage(prompt)}
              onOpenResumeModal={() => setIsResumeModalOpen(true)}
              onOpenPhotoStudioModal={() => setIsPhotoStudioModalOpen(true)}
              onOpenInvitationModal={() => setIsInvitationModalOpen(true)}
              onOpenPanchangModal={() => setIsPanchangModalOpen(true)}
              onOpenExamModal={() => setIsExamModalOpen(true)}
              onOpenDailyHelperModal={() => setIsDailyHelperModalOpen(true)}
              darkMode={darkMode}
            />
            {!isApp && (
              <div className="w-full max-w-xl px-4 pb-4">
                <AdSenseBanner slotId="welcome-ad-slot" />
              </div>
            )}
          </div>
        ) : (
          <MessageList
            messages={currentSession.messages}
            isLoading={isLoading}
            onRegenerate={handleRegenerate}
            language={language}
            darkMode={darkMode}
          />
        )}

        <PromptBar
          onSendMessage={handleSendMessage}
          isLoading={isLoading}
          language={language}
          darkMode={darkMode}
        />
      </main>

      <AdMobBanner />

      <footer className={`py-3 px-4 border-t text-center text-xs flex items-center justify-center gap-4 ${
        darkMode ? 'bg-gray-900/80 border-gray-800 text-gray-400' : 'bg-white border-gray-200 text-gray-600'
      }`}>
        <button onClick={() => setIsPrivacyOpen(true)} className="hover:underline">
          गोपनीयता नीति (Privacy Policy)
        </button>
        <span>•</span>
        <button onClick={() => setIsAboutOpen(true)} className="hover:underline">
          हमारे बारे में (About)
        </button>
        <span>•</span>
        <button onClick={() => setIsApkGuideOpen(true)} className="hover:underline">
          APK गाइड
        </button>
      </footer>

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        darkMode={darkMode}
      />

      <ApkGuideModal
        isOpen={isApkGuideOpen}
        onClose={() => setIsApkGuideOpen(false)}
        darkMode={darkMode}
      />

      <PrivacyPolicyModal
        isOpen={isPrivacyOpen}
        onClose={() => setIsPrivacyOpen(false)}
        darkMode={darkMode}
      />

      <AboutModal
        isOpen={isAboutOpen}
        onClose={() => setIsAboutOpen(false)}
        darkMode={darkMode}
      />

      <ResumeModal
        isOpen={isResumeModalOpen}
        onClose={() => setIsResumeModalOpen(false)}
        darkMode={darkMode}
      />

      <PhotoStudioModal
        isOpen={isPhotoStudioModalOpen}
        onClose={() => setIsPhotoStudioModalOpen(false)}
        darkMode={darkMode}
      />

      <InvitationModal
        isOpen={isInvitationModalOpen}
        onClose={() => setIsInvitationModalOpen(false)}
        darkMode={darkMode}
      />

      <PanchangModal
        isOpen={isPanchangModalOpen}
        onClose={() => setIsPanchangModalOpen(false)}
        darkMode={darkMode}
      />

      <ExamModal
        isOpen={isExamModalOpen}
        onClose={() => setIsExamModalOpen(false)}
        darkMode={darkMode}
      />

      <DailyHelperModal
        isOpen={isDailyHelperModalOpen}
        onClose={() => setIsDailyHelperModalOpen(false)}
        darkMode={darkMode}
      />

      <RewardedAdModal
        isOpen={isRewardedAdOpen}
        onClose={() => setIsRewardedAdOpen(false)}
        onRewardGranted={handleRewardGranted}
        darkMode={darkMode}
      />
    </div>
  );
}
