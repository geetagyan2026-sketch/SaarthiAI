import React, { useState, useEffect } from 'react';
import { Sparkles, X, Play, ShieldCheck, Zap, CheckCircle2 } from 'lucide-react';

export const PAYMENT_LINKS = {
  india: {
    day1: 'https://rzp.io/rzp/msb8hRxf',
    days15: 'https://rzp.io/rzp/uKYiWN2Q',
    month1: 'https://rzp.io/rzp/3uUMgA2G',
  },
  world: {
    day1: 'https://rzp.io/rzp/EM97xGN',
    days15: 'https://rzp.io/rzp/Y3J9yP0',
    month1: 'https://rzp.io/rzp/2t4s2ZI',
  },
};

interface RewardedAdModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRewardGranted: () => void;
  onOpenProPlans: () => void;
  darkMode: boolean;
}

export const RewardedAdModal: React.FC<RewardedAdModalProps> = ({
  isOpen,
  onClose,
  onRewardGranted,
  onOpenProPlans,
  darkMode,
}) => {
  const [timeLeft, setTimeLeft] = useState(6);
  const [canContinue, setCanContinue] = useState(false);

  useEffect(() => {
    if (!isOpen) {
      setTimeLeft(6);
      setCanContinue(false);
      return;
    }

    setTimeLeft(6);
    setCanContinue(false);

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setCanContinue(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div
        className={`w-full max-w-md p-6 rounded-3xl shadow-2xl border text-center transition-all ${
          darkMode ? 'bg-gray-900 border-gray-800 text-white' : 'bg-white border-gray-200 text-gray-900'
        }`}
      >
        <div className="flex items-center justify-between mb-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-500 text-[11px] font-bold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Sponsored Ad — Unlock 1 Use</span>
          </div>
          <button
            onClick={onClose}
            className={`p-1 rounded-lg ${darkMode ? 'hover:bg-gray-800 text-gray-400' : 'hover:bg-gray-100 text-gray-600'}`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <h3 className="font-bold text-base sm:text-lg mb-1">प्रायोजित विज्ञापन (Sponsored Ad)</h3>
        <p className={`text-xs mb-4 ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
          मुफ्त उपयोग जारी रखने के लिए कृपया 6 सेकंड प्रतीक्षा करें।
        </p>

        {/* Google AdSense Responsive Container Placeholder */}
        <div className="my-4 p-4 rounded-2xl bg-gray-100 dark:bg-gray-800/80 border border-dashed border-gray-300 dark:border-gray-700 text-center">
          <div className="text-[10px] uppercase tracking-wider text-gray-400 mb-1">Google AdSense Placement</div>
          <div 
            className="py-6 px-4 bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 shadow-xs"
            data-ad-client="ca-pub-XXXXXXXXXXXXXXXX"
            data-ad-slot="9876543210"
            data-ad-format="auto"
          >
            <div className="font-bold text-indigo-600 dark:text-indigo-400 text-xs sm:text-sm mb-1">
              🌟 SaarthiAI Global Sponsor
            </div>
            <p className="text-[11px] text-gray-500 dark:text-gray-400">
              भारत और दुनिया के सभी राज्यों के लिए आधिकारिक डिजिटल पोर्टल और सरकारी फॉर्म गाइड।
            </p>
          </div>
        </div>

        {/* 6-second Countdown Timer */}
        <div className="mb-5">
          {!canContinue ? (
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 text-xs font-semibold animate-pulse">
              <span className="w-2 h-2 rounded-full bg-indigo-500"></span>
              <span>Unlocking your tool in {timeLeft}s...</span>
            </div>
          ) : (
            <div className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-500 text-xs font-bold">
              <CheckCircle2 className="w-4 h-4" />
              <span>Ad watched! Click below to continue.</span>
            </div>
          )}
        </div>

        <div className="space-y-2.5">
          <button
            onClick={() => {
              if (canContinue) {
                onRewardGranted();
                onClose();
              }
            }}
            disabled={!canContinue}
            className={`w-full py-3 px-4 rounded-2xl font-bold text-xs sm:text-sm shadow-lg flex items-center justify-center gap-2 transition-all ${
              canContinue
                ? 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white cursor-pointer active:scale-95'
                : 'bg-gray-300 dark:bg-gray-800 text-gray-500 cursor-not-allowed opacity-70'
            }`}
          >
            <Play className="w-4 h-4 fill-current" />
            <span>{canContinue ? 'Continue to Tool (1 Use Unlocked)' : `Please wait (${timeLeft}s)...`}</span>
          </button>

          <button
            onClick={() => {
              onClose();
              onOpenProPlans();
            }}
            className="w-full py-2.5 px-4 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-bold text-xs shadow-md flex items-center justify-center gap-2 transition-all active:scale-95"
          >
            <Zap className="w-4 h-4 fill-current" />
            <span>Upgrade to Pro (Skip All Ads)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
