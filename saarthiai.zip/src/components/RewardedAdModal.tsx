import React, { useState } from 'react';
import { AdMob } from '@capacitor-community/admob';
import { isAndroidApp } from '../lib/platform';
import { Play, Sparkles, X, CheckCircle, Gift } from 'lucide-react';

interface RewardedAdModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRewardGranted: () => void;
  darkMode: boolean;
}

export const RewardedAdModal: React.FC<RewardedAdModalProps> = ({ isOpen, onClose, onRewardGranted, darkMode }) => {
  const [watching, setWatching] = useState(false);

  if (!isOpen) return null;

  const handleWatchAd = async () => {
    setWatching(true);
    if (isAndroidApp()) {
      try {
        await AdMob.prepareRewardVideoAd({
          adId: 'ca-app-pub-3940256099942544/5224354917',
          isTesting: true,
        });
        const reward = await AdMob.showRewardVideoAd();
        if (reward) {
          onRewardGranted();
          onClose();
        }
      } catch (e) {
        console.error('Rewarded ad error:', e);
        setTimeout(() => {
          onRewardGranted();
          setWatching(false);
          onClose();
        }, 2000);
      } finally {
        setWatching(false);
      }
    } else {
      setTimeout(() => {
        onRewardGranted();
        setWatching(false);
        onClose();
      }, 1500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
      <div className={`w-full max-w-sm p-6 rounded-3xl shadow-2xl border text-center transition-all ${
        darkMode ? 'bg-gray-900 border-gray-800 text-white' : 'bg-white border-gray-200 text-gray-900'
      }`}>
        <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-600 text-white flex items-center justify-center mx-auto mb-4 shadow-lg animate-bounce">
          <Gift className="w-7 h-7" />
        </div>

        <h3 className="font-bold text-lg mb-2">मुफ्त सवाल सीमा समाप्त!</h3>
        <p className={`text-xs mb-6 ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
          आज के आपके सभी 3 मुफ्त सवाल पूरे हो चुके हैं। एक छोटा विज्ञापन देखकर +2 और मुफ्त सवाल तुरंत अनलॉक करें!
        </p>

        <div className="space-y-3">
          <button
            onClick={handleWatchAd}
            disabled={watching}
            className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold text-xs sm:text-sm shadow-lg flex items-center justify-center gap-2 transition-all active:scale-95"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>{watching ? 'विज्ञापन चल रहा है...' : 'विज्ञापन देखें (+2 सवाल पाएं)'}</span>
          </button>

          <button
            onClick={onClose}
            className={`w-full py-2.5 rounded-xl text-xs font-medium transition-colors ${
              darkMode ? 'hover:bg-gray-800 text-gray-400' : 'hover:bg-gray-100 text-gray-600'
            }`}
          >
            बाद में
          </button>
        </div>
      </div>
    </div>
  );
};
