import React from 'react';

interface AdSenseBannerProps {
  slotId?: string;
  className?: string;
}

export const AdSenseBanner: React.FC<AdSenseBannerProps> = ({ slotId = "1234567890", className = "" }) => {
  return (
    <div className={`my-4 p-3 rounded-2xl bg-gray-100 dark:bg-gray-800/60 border border-gray-200 dark:border-gray-700/60 text-center overflow-hidden ${className}`}>
      <div className="text-[10px] text-gray-400 mb-1 uppercase tracking-wider">विज्ञापन (Advertisement - Google AdSense)</div>
      <div 
        className="min-h-[90px] flex items-center justify-center bg-white dark:bg-gray-900 rounded-xl border border-dashed border-gray-300 dark:border-gray-700 p-4 text-xs text-gray-500"
        data-ad-client="ca-pub-XXXXXXXXXXXXXXXX"
        data-ad-slot={slotId}
        data-ad-format="auto"
        data-full-width-responsive="true"
      >
        {/* Actual Google AdSense script wrapper */}
        <div className="flex flex-col items-center gap-1">
          <span className="font-semibold text-indigo-600 dark:text-indigo-400">SaarthiAI Sponsor</span>
          <span className="text-[11px] text-gray-400">भारत का स्मार्ट AI असिस्टेंट — सरकारी योजनाएं, खेती और पढ़ाई</span>
        </div>
      </div>
    </div>
  );
};
