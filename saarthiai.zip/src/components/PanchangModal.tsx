import React, { useState, useEffect } from 'react';
import { Sun, X, Volume2, VolumeX, Calendar, Clock, Sparkles, Loader2, RefreshCw } from 'lucide-react';
import { generateSaarthiResponse } from '../lib/geminiService';

interface PanchangModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  language?: string;
  location?: string;
}

export const PanchangModal: React.FC<PanchangModalProps> = ({
  isOpen,
  onClose,
  darkMode,
  language = 'hi',
  location = 'India',
}) => {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [aiPanchang, setAiPanchang] = useState('');
  const [speechNotice, setSpeechNotice] = useState('');

  useEffect(() => {
    if (!isOpen) {
      setIsLoading(false);
      setIsSpeaking(false);
      setSpeechNotice('');
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const panchangText = `आज का पंचांग और शुभ मुहूर्त: 
विक्रम संवत 2083, कार्तिक मास, शुक्ल पक्ष। 
आज की तिथि: द्वादशी। 
नक्षत्र: उत्तराभाद्रपद। 
योग: सिद्ध। 
राहुकाल: दोपहर 01:30 बजे से 03:00 बजे तक (इस दौरान कोई नया शुभ कार्य न करें)। 
अभिजित मुहूर्त (शुभ समय): सुबह 11:45 बजे से दोपहर 12:30 बजे तक — वाहन, संपत्ति या नया कार्य शुरू करने के लिए उत्तम समय।`;

  const handleClose = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
    setIsLoading(false);
    onClose();
  };

  const handleFetchAiPanchang = async () => {
    if (isLoading) return;
    setIsLoading(true);
    const todayStr = new Date().toLocaleDateString('hi-IN', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
    const prompt = `आज दिनांक ${todayStr} (${location}) के लिए पंचांग विवरण, शुभ चौघड़िया, अभिजित मुहूर्त, राहुकाल और आज के दिन के लिए विशेष शुभ विचार आसान भाषा में बताएं।`;

    try {
      const res = await generateSaarthiResponse(prompt, [], undefined, language, location);
      setAiPanchang(res);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : String(e);
      setAiPanchang(msg || 'पंचांग अपडेट प्राप्त करने में त्रुटि हुई।');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSpeak = () => {
    if (!('speechSynthesis' in window)) {
      setSpeechNotice('आपका ब्राउज़र वॉइस स्पीच का समर्थन नहीं करता।');
      return;
    }

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(aiPanchang || panchangText);
    utterance.lang = language === 'en' ? 'en-US' : 'hi-IN';
    utterance.rate = 0.95;

    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
      <div className={`w-full max-w-lg max-h-[90vh] overflow-y-auto p-6 rounded-3xl shadow-2xl border transition-all ${
        darkMode ? 'bg-gray-900 border-gray-800 text-white' : 'bg-white border-gray-200 text-gray-900'
      }`}>
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-gray-200 dark:border-gray-800">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-600 text-white flex items-center justify-center shadow-md">
              <Sun className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-base sm:text-lg">🕉️ आज का पंचांग और शुभ मुहूर्त</h2>
              <p className="text-xs text-gray-400">चौघड़िया, राहुकाल और शुभ समय</p>
            </div>
          </div>
          <button
            type="button"
            onClick={handleClose}
            className={`p-1.5 rounded-lg transition-colors ${darkMode ? 'hover:bg-gray-800 text-gray-400' : 'hover:bg-gray-100 text-gray-600'}`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4 text-xs sm:text-sm">
          <div className={`p-4 rounded-2xl border ${darkMode ? 'bg-gray-800/60 border-gray-700' : 'bg-amber-50/70 border-amber-200'}`}>
            <h3 className="font-bold text-sm mb-2 flex items-center gap-1.5 text-amber-500">
              <Calendar className="w-4 h-4" />
              <span>पंचांग विवरण</span>
            </h3>
            <ul className={`space-y-1.5 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
              <li>🗓️ <strong>संवत / मास:</strong> विक्रम संवत 2083, कार्तिक शुक्ल पक्ष</li>
              <li>🌙 <strong>तिथि:</strong> द्वादशी (प्रातः काल तक)</li>
              <li>⭐ <strong>नक्षत्र:</strong> उत्तराभाद्रपद</li>
              <li>✨ <strong>योग:</strong> सिद्ध योग</li>
            </ul>
          </div>

          <div className={`p-4 rounded-2xl border ${darkMode ? 'bg-gray-800/60 border-gray-700' : 'bg-red-50/70 border-red-200'}`}>
            <h3 className="font-bold text-sm mb-1 text-red-500 flex items-center gap-1.5">
              <Clock className="w-4 h-4" />
              <span>राहुकाल (अशुभ समय)</span>
            </h3>
            <p className="text-xs opacity-90">दोपहर 01:30 बजे से 03:00 बजे तक — इस दौरान कोई नया शुभ कार्य या यात्रा शुरू न करें।</p>
          </div>

          <div className={`p-4 rounded-2xl border ${darkMode ? 'bg-gray-800/60 border-gray-700' : 'bg-emerald-50/70 border-emerald-200'}`}>
            <h3 className="font-bold text-sm mb-1 text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4" />
              <span>अभिजित मुहूर्त (सर्वश्रेष्ठ शुभ समय)</span>
            </h3>
            <p className="text-xs opacity-90">सुबह 11:45 बजे से दोपहर 12:30 बजे तक — वाहन, प्रॉपर्टी या नया बिज़नेस शुरू करने के लिए अत्यंत शुभ।</p>
          </div>

          <button
            type="button"
            onClick={handleFetchAiPanchang}
            disabled={isLoading}
            className="w-full py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white font-bold text-xs shadow-md flex items-center justify-center gap-2 transition-all"
          >
            {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
            <span>{isLoading ? 'AI पंचांग तैयार कर रहा है...' : '✨ AI से आज का विस्तृत पंचांग व राशि सलाह पाएं'}</span>
          </button>

          {aiPanchang && (
            <div className={`p-4 rounded-2xl border whitespace-pre-wrap text-xs sm:text-sm leading-relaxed ${
              darkMode ? 'bg-gray-800/80 border-gray-700 text-gray-200' : 'bg-amber-50/50 border-amber-200 text-gray-800'
            }`}>
              {aiPanchang}
            </div>
          )}

          {speechNotice && (
            <p className="text-xs text-amber-500">{speechNotice}</p>
          )}

          <div className="pt-2 flex items-center justify-between">
            <button
              type="button"
              onClick={handleSpeak}
              className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl border font-semibold text-xs transition-all ${
                isSpeaking
                  ? 'bg-red-500 text-white border-red-600'
                  : darkMode ? 'bg-gray-800 border-gray-700 text-indigo-300 hover:bg-gray-700' : 'bg-indigo-50 border-indigo-200 text-indigo-700 hover:bg-indigo-100'
              }`}
            >
              {isSpeaking ? <VolumeX className="w-4 h-4 animate-pulse" /> : <Volume2 className="w-4 h-4 text-indigo-500" />}
              <span>{isSpeaking ? 'बोलना बंद करें' : '🔊 हिंदी में सुनें'}</span>
            </button>

            <button
              type="button"
              onClick={handleClose}
              className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-md transition-all"
            >
              बंद करें
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
