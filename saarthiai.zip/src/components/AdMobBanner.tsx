import React, { useEffect, useState } from 'react';
import { AdMob, BannerAdPosition, BannerAdSize } from '@capacitor-community/admob';
import { isAndroidApp } from '../lib/platform';
import { Smartphone } from 'lucide-react';

interface AdMobBannerProps {
  onRewardEarned?: () => void;
}

export const AdMobBanner: React.FC<AdMobBannerProps> = () => {
  const [adLoaded, setAdLoaded] = useState(false);
  const isApp = isAndroidApp();

  useEffect(() => {
    if (!isApp) return;

    async function initAdMob() {
      try {
        await AdMob.initialize({});

        // Show Banner Ad
        await AdMob.showBanner({
          adId: 'ca-app-pub-3940256099942544/6300978111',
          position: BannerAdPosition.BOTTOM_CENTER,
          size: BannerAdSize.BANNER,
          margin: 60,
          isTesting: true,
        } as any);
        setAdLoaded(true);
      } catch (e) {
        console.error('AdMob init error:', e);
      }
    }

    initAdMob();

    return () => {
      if (isApp) {
        AdMob.hideBanner().catch(() => {});
      }
    };
  }, [isApp]);

  if (!isApp) return null;

  return (
    <div className="fixed bottom-16 left-0 right-0 z-10 px-4 pointer-events-none">
      <div className="max-w-md mx-auto bg-gray-900/80 backdrop-blur-md text-white px-3 py-1 rounded-full text-[10px] flex items-center justify-between shadow-lg pointer-events-auto border border-gray-800">
        <span className="flex items-center gap-1.5 text-emerald-400">
          <Smartphone className="w-3 h-3" />
          <span>AdMob Android Banner Active</span>
        </span>
        <span className="text-gray-400">Sponsored</span>
      </div>
    </div>
  );
};
