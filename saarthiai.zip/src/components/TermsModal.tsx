import React from 'react';
import { FileText, X } from 'lucide-react';

interface TermsModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
}

export const TermsModal: React.FC<TermsModalProps> = ({ isOpen, onClose, darkMode }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
      <div className={`w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 rounded-3xl shadow-2xl border transition-all ${
        darkMode ? 'bg-gray-900 border-gray-800 text-white' : 'bg-white border-gray-200 text-gray-900'
      }`}>
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-gray-200 dark:border-gray-800">
          <div className="flex items-center gap-2.5">
            <FileText className="w-6 h-6 text-indigo-500" />
            <h2 className="font-bold text-lg">नियम और शर्तें (Terms &amp; Conditions)</h2>
          </div>
          <button
            onClick={onClose}
            className={`p-1.5 rounded-lg transition-colors ${darkMode ? 'hover:bg-gray-800 text-gray-400' : 'hover:bg-gray-100 text-gray-600'}`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className={`space-y-4 text-xs sm:text-sm leading-relaxed ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
          <p>
            <strong>SaarthiAI</strong> का उपयोग करने पर आप निम्नलिखित नियमों और शर्तों से सहमत होते हैं। कृपया ऐप का उपयोग करने से पहले इन्हें ध्यान से पढ़ें।
          </p>

          <h3 className="font-bold text-sm text-indigo-500">1. सेवाओं का उपयोग (Use of Services)</h3>
          <p>
            SaarthiAI उपयोगकर्ताओं को सरकारी योजनाओं, ई-मित्र सेवाओं, शिक्षा और सामान्य ज्ञान की जानकारी प्रदान करता है। हम आधिकारिक पोर्टल्स (.gov.in / .gov) से डेटा प्राप्त करते हैं, किंतु अंतिम आधिकारिक पुष्टि संबंधित सरकारी वेबसाइट से करें।
          </p>

          <h3 className="font-bold text-sm text-indigo-500">2. प्रो प्लान और विज्ञापन (Pro Plan &amp; Ads)</h3>
          <p>
            मुफ्त यूज़र्स के लिए हर एक्शन से पहले 6-सेकंड का प्रायोजित विज्ञापन (Rewarded Ad) दिखाया जाता है। विज्ञापन मुक्त अनुभव के लिए यूज़र अपनी क्षेत्र-आधारित (भारत ₹ INR / विश्व $ USD) प्रो योजना चुनकर अपग्रेड कर सकते हैं।
          </p>

          <h3 className="font-bold text-sm text-indigo-500">3. बौद्धिक संपदा (Intellectual Property)</h3>
          <p>
            ऐप का डिज़ाइन, कोड और यूआई सुरक्षित हैं। बिना अनुमति किसी भी भाग का व्यावसायिक उपयोग वर्जित है।
          </p>

          <div className="pt-4 flex justify-end">
            <button
              onClick={onClose}
              className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-md transition-all"
            >
              बंद करें
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
