import React from 'react';
import { Sparkles, MessageSquarePlus, History, Sun, Moon, Settings, Smartphone, Wrench, Globe, MapPin, Shield, Info } from 'lucide-react';

interface HeaderProps {
  onNewChat: () => void;
  onToggleHistory: () => void;
  onOpenToolsDrawer: () => void;
  language: string;
  onLanguageChange: (lang: string) => void;
  location: string;
  onLocationChange: (loc: string) => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  onOpenSettings: () => void;
  onOpenApkGuide: () => void;
  onOpenPrivacy: () => void;
  onOpenAbout: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onNewChat,
  onToggleHistory,
  onOpenToolsDrawer,
  language,
  onLanguageChange,
  location,
  onLocationChange,
  darkMode,
  onToggleDarkMode,
  onOpenSettings,
  onOpenApkGuide,
  onOpenPrivacy,
  onOpenAbout,
}) => {
  const languages = [
    { code: 'hi', label: 'हिंदी (Hindi)' },
    { code: 'en', label: 'English' },
    { code: 'ar', label: 'العربية (Arabic)' },
    { code: 'es', label: 'Español (Spanish)' },
    { code: 'fr', label: 'Français (French)' },
    { code: 'pa', label: 'ਪੰਜਾਬी (Punjabi)' },
    { code: 'bn', label: 'বাংলা (Bengali)' },
  ];

  const locations = [
    '🌍 Global / World',
    '🇮🇳 India - General',
    '🇮🇳 India - Rajasthan',
    '🇮🇳 India - Uttar Pradesh',
    '🇮🇳 India - Bihar',
    '🇮🇳 India - Madhya Pradesh',
    '🇮🇳 India - Maharashtra',
    '🇺🇸 United States (USA)',
    '🇦🇪 United Arab Emirates (UAE)',
    '🇬🇧 United Kingdom (UK)',
    '🇨🇦 Canada',
    '🇦🇺 Australia',
  ];

  return (
    <header className={`sticky top-0 z-30 flex items-center justify-between px-3 sm:px-4 py-3 border-b backdrop-blur-md transition-colors ${
      darkMode ? 'bg-gray-900/90 border-gray-800 text-white' : 'bg-white/90 border-gray-200 text-gray-800'
    }`}>
      <div className="flex items-center gap-2 sm:gap-3">
        <button
          onClick={onToggleHistory}
          className={`p-2 rounded-xl transition-colors ${darkMode ? 'hover:bg-gray-800 text-gray-300' : 'hover:bg-gray-100 text-gray-700'}`}
          title="चैट इतिहास (History)"
          aria-label="Toggle History"
        >
          <History className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 cursor-pointer" onClick={onNewChat}>
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-orange-500 via-indigo-600 to-emerald-500 flex items-center justify-center text-white shadow-md">
            <Sparkles className="w-5 h-5" />
          </div>
          <div className="hidden xs:block">
            <h1 className="font-bold text-base sm:text-lg leading-tight tracking-tight flex items-center gap-1">
              SaarthiAI <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 font-medium">✨ Pro</span>
            </h1>
            <p className="text-[10px] text-gray-500 dark:text-gray-400">Global AI Assistant</p>
          </div>
        </div>
      </div>

      <div className="hidden md:flex items-center gap-2">
        <div className="flex items-center gap-1 bg-gray-100 dark:bg-gray-800/80 px-2 py-1.5 rounded-xl border border-gray-200 dark:border-gray-700">
          <Globe className="w-3.5 h-3.5 text-indigo-500" />
          <select
            value={language}
            onChange={(e) => onLanguageChange(e.target.value)}
            className="bg-transparent text-xs font-medium outline-none cursor-pointer"
          >
            {languages.map(l => (
              <option key={l.code} value={l.code} className="bg-white dark:bg-gray-900 text-gray-900 dark:text-white">
                {l.label}
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-1 bg-gray-100 dark:bg-gray-800/80 px-2 py-1.5 rounded-xl border border-gray-200 dark:border-gray-700">
          <MapPin className="w-3.5 h-3.5 text-emerald-500" />
          <select
            value={location}
            onChange={(e) => onLocationChange(e.target.value)}
            className="bg-transparent text-xs font-medium outline-none cursor-pointer max-w-[140px] truncate"
          >
            {locations.map(loc => (
              <option key={loc} value={loc} className="bg-white dark:bg-gray-900 text-gray-900 dark:text-white">
                {loc}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="flex items-center gap-1.5 sm:gap-2">
        <button
          onClick={onOpenToolsDrawer}
          className={`flex items-center gap-1 px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
            darkMode ? 'bg-purple-950/60 text-purple-300 hover:bg-purple-900/70 border border-purple-800/60' : 'bg-purple-50 text-purple-700 hover:bg-purple-100 border border-purple-200'
          }`}
          title="सभी टूल्स देखें (13+)"
        >
          <Wrench className="w-4 h-4 text-purple-500" />
          <span className="hidden xs:inline">टूल्स (13+)</span>
        </button>

        <button
          onClick={onNewChat}
          className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white text-xs font-semibold shadow-sm transition-all active:scale-95"
          title="नया चैट शुरू करें"
        >
          <MessageSquarePlus className="w-4 h-4" />
          <span className="hidden xs:inline">नया चैट</span>
        </button>

        <button
          onClick={onToggleDarkMode}
          className={`p-2 rounded-xl transition-colors ${darkMode ? 'hover:bg-gray-800 text-yellow-400' : 'hover:bg-gray-100 text-gray-700'}`}
          title="Theme"
        >
          {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
        </button>

        <button
          onClick={onOpenSettings}
          className={`p-2 rounded-xl transition-colors ${darkMode ? 'hover:bg-gray-800 text-gray-300' : 'hover:bg-gray-100 text-gray-700'}`}
          title="Settings"
        >
          <Settings className="w-5 h-5" />
        </button>
      </div>
    </header>
  );
};
