import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  MessageSquarePlus,
  History,
  Sun,
  Moon,
  Settings,
  Wrench,
  Globe,
  MapPin,
  ChevronDown,
  Search,
  Zap,
} from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';
import {
  SUPPORTED_LANGUAGES,
  INDIA_REGIONS,
  GLOBAL_REGIONS,
  findRegionOption,
  RegionScope,
} from '../lib/regions';

interface HeaderProps {
  onNewChat: () => void;
  onToggleHistory: () => void;
  onOpenToolsDrawer: () => void;
  language: string;
  onLanguageChange: (lang: string) => void;
  location: string;
  onLocationChange: (loc: string) => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  onOpenSettings: () => void;
  onOpenApkGuide: () => void;
  onOpenPrivacy: () => void;
  onOpenAbout: () => void;
  onOpenProPlans: () => void;
  isPro: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  onNewChat,
  onToggleHistory,
  onOpenToolsDrawer,
  language,
  onLanguageChange,
  location,
  onLocationChange,
  darkMode,
  onToggleDarkMode,
  onOpenSettings,
  onOpenProPlans,
  isPro,
}) => {
  const activeRegion = findRegionOption(location);
  const [isRegionOpen, setIsRegionOpen] = useState(false);
  const [activeScope, setActiveScope] = useState<RegionScope>(activeRegion.scope);
  const [regionFilter, setRegionFilter] = useState('');
  const popoverRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setActiveScope(activeRegion.scope);
  }, [activeRegion.scope]);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (popoverRef.current && !popoverRef.current.contains(e.target as Node)) {
        setIsRegionOpen(false);
      }
    };
    if (isRegionOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isRegionOpen]);

  const listForScope = activeScope === 'india' ? INDIA_REGIONS : GLOBAL_REGIONS;
  const filteredRegions = listForScope.filter((r) =>
    `${r.label} ${r.shortName} ${r.domainHint}`.toLowerCase().includes(regionFilter.trim().toLowerCase())
  );

  return (
    <header
      className={`sticky top-0 z-30 border-b backdrop-blur-md transition-colors ${
        darkMode ? 'bg-gray-900/95 border-gray-800 text-white' : 'bg-white/95 border-gray-200 text-gray-800'
      }`}
    >
      {/* Top Row: Brand, Controls, Actions */}
      <div className="flex items-center justify-between px-2.5 sm:px-4 py-2.5 gap-2">
        <div className="flex items-center gap-1.5 sm:gap-3 min-w-0">
          <button
            onClick={onToggleHistory}
            className={`p-2 rounded-xl transition-colors shrink-0 ${
              darkMode ? 'hover:bg-gray-800 text-gray-300' : 'hover:bg-gray-100 text-gray-700'
            }`}
            title="चैट इतिहास (History)"
            aria-label="Toggle History"
          >
            <History className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 cursor-pointer min-w-0" onClick={onNewChat}>
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr from-orange-500 via-indigo-600 to-emerald-500 flex items-center justify-center text-white shadow-md shrink-0">
              <Sparkles className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div className="hidden sm:block min-w-0">
              <h1 className="font-bold text-base sm:text-lg leading-tight tracking-tight flex items-center gap-1">
                SaarthiAI
                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-500 font-semibold">
                  Global
                </span>
              </h1>
              <p className="text-[10px] text-gray-500 dark:text-gray-400 truncate">
                All India &amp; World Official Assistant
              </p>
            </div>
          </div>
        </div>

        {/* Center/Desktop Region + Language Selector */}
        <div className="flex items-center gap-1.5 sm:gap-2" ref={popoverRef}>
          {/* Smart Region / Location Selector (Works on both Mobile & Desktop) */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setIsRegionOpen((prev) => !prev)}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-semibold transition-all ${
                darkMode
                  ? 'bg-gray-800/90 border-gray-700 hover:border-emerald-500/70 text-gray-100'
                  : 'bg-gray-100 border-gray-200 hover:border-emerald-500 text-gray-800'
              }`}
              title="Region / Location Selector (India & Global)"
            >
              <MapPin className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
              <span className="max-w-[92px] sm:max-w-[140px] truncate">
                {activeRegion.flag} {activeRegion.shortName}
              </span>
              <ChevronDown className="w-3.5 h-3.5 opacity-70 shrink-0" />
            </button>

            {isRegionOpen && (
              <div
                className={`fixed sm:absolute left-2 right-2 sm:left-0 sm:right-auto top-14 sm:top-full sm:mt-2 sm:w-80 rounded-2xl border shadow-2xl p-3 z-50 ${
                  darkMode ? 'bg-gray-900 border-gray-700 text-white' : 'bg-white border-gray-200 text-gray-900'
                }`}
              >
                <div className="text-[11px] font-bold uppercase tracking-wider text-gray-400 mb-2">
                  🌍 Region / Location Selector
                </div>

                {/* Two Main Scope Tabs: India vs Global */}
                <div className="grid grid-cols-2 gap-1.5 p-1 rounded-xl bg-gray-100 dark:bg-gray-800 mb-2.5">
                  <button
                    type="button"
                    onClick={() => {
                      setActiveScope('india');
                      setRegionFilter('');
                    }}
                    className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all ${
                      activeScope === 'india'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-gray-600 dark:text-gray-300 hover:bg-gray-200/60 dark:hover:bg-gray-700/60'
                    }`}
                  >
                    🇮🇳 India (All States)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveScope('global');
                      setRegionFilter('');
                    }}
                    className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all ${
                      activeScope === 'global'
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'text-gray-600 dark:text-gray-300 hover:bg-gray-200/60 dark:hover:bg-gray-700/60'
                    }`}
                  >
                    🌐 Global / World
                  </button>
                </div>

                {/* Filter Input */}
                <div
                  className={`flex items-center gap-2 px-2.5 py-1.5 rounded-xl border mb-2 ${
                    darkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
                  }`}
                >
                  <Search className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                  <input
                    type="text"
                    value={regionFilter}
                    onChange={(e) => setRegionFilter(e.target.value)}
                    placeholder={activeScope === 'india' ? 'राज्य खोजें (e.g. Rajasthan, UP)...' : 'Country search (e.g. USA, UK)...'}
                    className="w-full bg-transparent text-xs outline-none"
                  />
                </div>

                {/* Scrollable Region List */}
                <div className="max-h-64 overflow-y-auto space-y-1 custom-scrollbar pr-0.5">
                  {filteredRegions.map((reg) => {
                    const isSelected = reg.value === activeRegion.value;
                    return (
                      <button
                        key={reg.value}
                        type="button"
                        onClick={() => {
                          onLocationChange(reg.value);
                          setIsRegionOpen(false);
                          setRegionFilter('');
                        }}
                        className={`w-full flex items-center justify-between gap-2 px-2.5 py-2 rounded-xl text-left text-xs transition-colors ${
                          isSelected
                            ? 'bg-indigo-600 text-white font-semibold'
                            : darkMode
                              ? 'hover:bg-gray-800 text-gray-200'
                              : 'hover:bg-gray-100 text-gray-800'
                        }`}
                      >
                        <span className="truncate">{reg.label}</span>
                        <span
                          className={`text-[10px] shrink-0 px-1.5 py-0.5 rounded ${
                            isSelected ? 'bg-white/20 text-white' : 'bg-emerald-500/10 text-emerald-500'
                          }`}
                        >
                          {reg.domainHint}
                        </span>
                      </button>
                    );
                  })}
                  {filteredRegions.length === 0 && (
                    <div className="text-center py-4 text-xs text-gray-400">
                      कोई मिलान नहीं मिला (No match found)
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Language Selector */}
          <div
            className={`flex items-center gap-1 px-2 py-1.5 rounded-xl border ${
              darkMode ? 'bg-gray-800/90 border-gray-700' : 'bg-gray-100 border-gray-200'
            }`}
          >
            <Globe className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
            <select
              value={language}
              onChange={(e) => onLanguageChange(e.target.value)}
              aria-label="Select Language"
              className="bg-transparent text-xs font-medium outline-none cursor-pointer max-w-[78px] sm:max-w-[125px] truncate"
            >
              {SUPPORTED_LANGUAGES.map((l) => (
                <option
                  key={l.code}
                  value={l.code}
                  className="bg-white dark:bg-gray-900 text-gray-900 dark:text-white"
                >
                  {l.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
          <PWAInstallButton darkMode={darkMode} />

          {/* Pro Button */}
          <button
            onClick={onOpenProPlans}
            className={`flex items-center gap-1 px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              isPro
                ? 'bg-emerald-600 text-white shadow-md'
                : 'bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white shadow-sm'
            }`}
            title="Pro Recharge Plans"
          >
            <Zap className="w-3.5 h-3.5 fill-current" />
            <span className="hidden sm:inline">{isPro ? 'Pro Active ✨' : 'Pro (No Ads)'}</span>
          </button>

          <button
            onClick={onOpenToolsDrawer}
            className={`flex items-center gap-1 px-2 sm:px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              darkMode
                ? 'bg-purple-950/60 text-purple-300 hover:bg-purple-900/70 border border-purple-800/60'
                : 'bg-purple-50 text-purple-700 hover:bg-purple-100 border border-purple-200'
            }`}
            title="सभी टूल्स देखें"
          >
            <Wrench className="w-4 h-4 text-purple-500" />
            <span className="hidden lg:inline">टूल्स</span>
          </button>

          <button
            onClick={onNewChat}
            className="flex items-center gap-1 px-2.5 sm:px-3 py-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white text-xs font-semibold shadow-sm transition-all active:scale-95"
            title="नया चैट शुरू करें"
          >
            <MessageSquarePlus className="w-4 h-4" />
            <span className="hidden md:inline">नया चैट</span>
          </button>

          <button
            onClick={onToggleDarkMode}
            className={`p-2 rounded-xl transition-colors hidden xs:flex ${
              darkMode ? 'hover:bg-gray-800 text-yellow-400' : 'hover:bg-gray-100 text-gray-700'
            }`}
            title="Theme"
          >
            {darkMode ? <Sun className="w-4 h-4 sm:w-5 sm:h-5" /> : <Moon className="w-4 h-4 sm:w-5 sm:h-5" />}
          </button>

          <button
            onClick={onOpenSettings}
            className={`p-2 rounded-xl transition-colors ${
              darkMode ? 'hover:bg-gray-800 text-gray-300' : 'hover:bg-gray-100 text-gray-700'
            }`}
            title="Settings"
          >
            <Settings className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>
        </div>
      </div>
    </header>
  );
};
