import React, { useEffect, useRef, useState } from 'react';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas-pro';
import {
  FileText,
  X,
  Download,
  Sparkles,
  Upload,
  Trash2,
  Phone,
  Mail,
  MapPin,
  Globe,
  Briefcase,
  GraduationCap,
  FolderKanban,
  Languages,
  UserCheck,
  Loader2,
  Check,
  Eye,
  PenLine,
} from 'lucide-react';

interface ResumeModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
}

type TemplateId = 'executive' | 'ats' | 'fresher' | 'creative';
type AccentId = 'blue' | 'slate' | 'emerald';

interface ResumeData {
  fullName: string;
  jobTitle: string;
  phone: string;
  email: string;
  address: string;
  linkedin: string;
  summary: string;
  education: string;
  skills: string;
  languages: string;
  experience: string;
  projects: string;
}

const ACCENT_THEMES: Record<
  AccentId,
  {
    label: string;
    swatch: string;
    primary: string;
    dark: string;
    soft: string;
    border: string;
    pillText: string;
  }
> = {
  blue: {
    label: 'Blue',
    swatch: '#1D4ED8',
    primary: '#1D4ED8',
    dark: '#0F294D',
    soft: '#EFF6FF',
    border: '#BFDBFE',
    pillText: '#1E3A8A',
  },
  slate: {
    label: 'Dark Slate',
    swatch: '#334155',
    primary: '#334155',
    dark: '#0F172A',
    soft: '#F1F5F9',
    border: '#CBD5E1',
    pillText: '#0F172A',
  },
  emerald: {
    label: 'Emerald',
    swatch: '#047857',
    primary: '#047857',
    dark: '#064E3B',
    soft: '#ECFDF5',
    border: '#A7F3D0',
    pillText: '#065F46',
  },
};

const TEMPLATE_META: Array<{
  id: TemplateId;
  name: string;
  subtitle: string;
}> = [
  { id: 'executive', name: 'Modern Executive', subtitle: '2-कॉलम + फोटो' },
  { id: 'ats', name: 'ATS Corporate', subtitle: 'कंपनी जॉब स्टैंडर्ड' },
  { id: 'fresher', name: 'Fresher Smart', subtitle: 'फ्रेशर व छात्र' },
  { id: 'creative', name: 'Creative Minimal', subtitle: 'क्लीन मॉडर्न' },
];

const INITIAL_RESUME_DATA: ResumeData = {
  fullName: 'Rahul Sharma',
  jobTitle: 'Accounts & Office Operations Executive',
  phone: '+91 98765 43210',
  email: 'rahul.sharma@example.com',
  address: 'Jaipur, Rajasthan',
  linkedin: 'linkedin.com/in/rahul-sharma',
  summary:
    'Detail-oriented and dependable graduate with practical expertise in Tally Prime, GST compliance, Advanced MS Excel, and client coordination. Proven ability to maintain error-free records, streamline daily office reporting, and support team productivity.',
  education:
    'B.Com (Bachelor of Commerce) — University of Rajasthan, 2024 (72%)\n12th (Senior Secondary, Commerce) — RBSE Board, 2021 (84%)',
  skills:
    'Tally Prime, GST Filing & Billing, Advanced MS Excel, Data Entry & MIS Reporting, Hindi & English Typing, Client Coordination',
  languages: 'Hindi (Native), English (Professional)',
  experience:
    '• Accounts Assistant | Bright Enterprises (2024 – Present): Managed daily voucher entries, GST invoice reconciliation, and monthly MIS reports in Excel.\n• Office Intern | FinServe Solutions (3 Months): Assisted in bank reconciliation, client documentation, and digital record archiving.',
  projects:
    '• Automated Monthly Expense & GST Reconciliation Tracker in MS Excel (reduced manual tally time by 30%).\n• Certified in RSCIT & Tally Prime Professional Accounting.',
};

function parseLines(text: string): string[] {
  return text
    .split(/\n+/)
    .map((line) => line.replace(/^[•\-*]\s*/, '').trim())
    .filter(Boolean);
}

function parseCommaList(text: string): string[] {
  return text
    .split(/[,\n]+/)
    .map((item) => item.trim())
    .filter(Boolean);
}

function getInitials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return 'CV';
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return `${parts[0][0] || ''}${parts[parts.length - 1][0] || ''}`.toUpperCase();
}

interface ResumeSheetProps {
  template: TemplateId;
  accent: AccentId;
  data: ResumeData;
  photo: string | null;
  isFresher: boolean;
}

const ResumeSheet: React.FC<ResumeSheetProps> = ({
  template,
  accent,
  data,
  photo,
  isFresher,
}) => {
  const theme = ACCENT_THEMES[accent];
  const skills = parseCommaList(data.skills);
  const languages = parseCommaList(data.languages);
  const educationLines = parseLines(data.education);
  const experienceLines = parseLines(data.experience);
  const projectLines = parseLines(data.projects);

  const experienceHeading = isFresher
    ? 'INTERNSHIPS & PRACTICAL TRAINING'
    : 'WORK EXPERIENCE';
  const summaryHeading = isFresher ? 'CAREER OBJECTIVE' : 'PROFESSIONAL SUMMARY';

  // Template 1: Modern Executive (Two-column with dark sidebar & circular photo)
  if (template === 'executive') {
    return (
      <div
        className="font-resume"
        style={{
          width: '794px',
          minHeight: '1123px',
          backgroundColor: '#FFFFFF',
          color: '#1E293B',
          display: 'flex',
          flexDirection: 'row',
          boxSizing: 'border-box',
          overflow: 'hidden',
        }}
      >
        {/* Left Dark Executive Sidebar */}
        <div
          style={{
            width: '256px',
            flexShrink: 0,
            backgroundColor: theme.dark,
            color: '#F8FAFC',
            padding: '38px 24px',
            boxSizing: 'border-box',
            display: 'flex',
            flexDirection: 'column',
            gap: '24px',
          }}
        >
          {/* Photo / Monogram */}
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            {photo ? (
              <img
                src={photo}
                alt={data.fullName}
                style={{
                  width: '116px',
                  height: '116px',
                  borderRadius: '9999px',
                  objectFit: 'cover',
                  border: '3px solid rgba(255,255,255,0.28)',
                }}
              />
            ) : (
              <div
                style={{
                  width: '106px',
                  height: '106px',
                  borderRadius: '9999px',
                  backgroundColor: 'rgba(255,255,255,0.12)',
                  border: '2px solid rgba(255,255,255,0.28)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '32px',
                  fontWeight: 700,
                  letterSpacing: '0.04em',
                  color: '#FFFFFF',
                }}
              >
                {getInitials(data.fullName)}
              </div>
            )}
          </div>

          {/* Contact */}
          <div>
            <div
              style={{
                fontSize: '11px',
                fontWeight: 700,
                letterSpacing: '0.12em',
                color: '#CBD5E1',
                borderBottom: '1px solid rgba(255,255,255,0.18)',
                paddingBottom: '6px',
                marginBottom: '10px',
              }}
            >
              CONTACT
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', fontSize: '11.5px', lineHeight: 1.45, color: '#E2E8F0' }}>
              {data.phone && (
                <div>
                  <span style={{ color: '#94A3B8', fontWeight: 600 }}>Phone: </span>
                  <span>{data.phone}</span>
                </div>
              )}
              {data.email && (
                <div style={{ wordBreak: 'break-word' }}>
                  <span style={{ color: '#94A3B8', fontWeight: 600 }}>Email: </span>
                  <span>{data.email}</span>
                </div>
              )}
              {data.address && (
                <div>
                  <span style={{ color: '#94A3B8', fontWeight: 600 }}>Location: </span>
                  <span>{data.address}</span>
                </div>
              )}
              {data.linkedin && (
                <div style={{ wordBreak: 'break-word' }}>
                  <span style={{ color: '#94A3B8', fontWeight: 600 }}>Profile: </span>
                  <span>{data.linkedin}</span>
                </div>
              )}
            </div>
          </div>

          {/* Core Skills */}
          {skills.length > 0 && (
            <div>
              <div
                style={{
                  fontSize: '11px',
                  fontWeight: 700,
                  letterSpacing: '0.12em',
                  color: '#CBD5E1',
                  borderBottom: '1px solid rgba(255,255,255,0.18)',
                  paddingBottom: '6px',
                  marginBottom: '10px',
                }}
              >
                CORE SKILLS
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '7px' }}>
                {skills.map((skill, idx) => (
                  <div
                    key={idx}
                    style={{
                      fontSize: '11.5px',
                      lineHeight: 1.4,
                      color: '#F1F5F9',
                      display: 'flex',
                      alignItems: 'flex-start',
                      gap: '7px',
                    }}
                  >
                    <span
                      style={{
                        width: '5px',
                        height: '5px',
                        borderRadius: '9999px',
                        backgroundColor: '#FFFFFF',
                        opacity: 0.75,
                        marginTop: '6px',
                        flexShrink: 0,
                      }}
                    />
                    <span>{skill}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Languages */}
          {languages.length > 0 && (
            <div>
              <div
                style={{
                  fontSize: '11px',
                  fontWeight: 700,
                  letterSpacing: '0.12em',
                  color: '#CBD5E1',
                  borderBottom: '1px solid rgba(255,255,255,0.18)',
                  paddingBottom: '6px',
                  marginBottom: '10px',
                }}
              >
                LANGUAGES
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '5px', fontSize: '11.5px', color: '#E2E8F0', lineHeight: 1.45 }}>
                {languages.map((lang, idx) => (
                  <div key={idx}>{lang}</div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Main Content */}
        <div
          style={{
            flex: 1,
            padding: '40px 36px',
            boxSizing: 'border-box',
            display: 'flex',
            flexDirection: 'column',
            gap: '22px',
          }}
        >
          {/* Name & Title Header */}
          <div style={{ borderBottom: `2px solid ${theme.primary}`, paddingBottom: '16px' }}>
            <h1
              style={{
                margin: 0,
                fontSize: '30px',
                fontWeight: 800,
                letterSpacing: '-0.02em',
                color: '#0F172A',
                lineHeight: 1.18,
              }}
            >
              {data.fullName || 'Your Name'}
            </h1>
            {data.jobTitle && (
              <div
                style={{
                  marginTop: '6px',
                  fontSize: '14px',
                  fontWeight: 600,
                  color: theme.primary,
                  letterSpacing: '0.01em',
                }}
              >
                {data.jobTitle}
              </div>
            )}
          </div>

          {/* Summary */}
          {data.summary && (
            <div>
              <h2
                style={{
                  margin: '0 0 8px 0',
                  fontSize: '12px',
                  fontWeight: 800,
                  letterSpacing: '0.1em',
                  color: theme.primary,
                }}
              >
                {summaryHeading}
              </h2>
              <p
                style={{
                  margin: 0,
                  fontSize: '12.5px',
                  lineHeight: 1.6,
                  color: '#334155',
                }}
              >
                {data.summary}
              </p>
            </div>
          )}

          {/* Experience */}
          {experienceLines.length > 0 && (
            <div>
              <h2
                style={{
                  margin: '0 0 10px 0',
                  fontSize: '12px',
                  fontWeight: 800,
                  letterSpacing: '0.1em',
                  color: theme.primary,
                  borderBottom: '1px solid #E2E8F0',
                  paddingBottom: '5px',
                }}
              >
                {experienceHeading}
              </h2>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '9px' }}>
                {experienceLines.map((line, idx) => (
                  <div
                    key={idx}
                    style={{
                      display: 'flex',
                      alignItems: 'flex-start',
                      gap: '8px',
                      fontSize: '12.5px',
                      lineHeight: 1.55,
                      color: '#1E293B',
                    }}
                  >
                    <span style={{ color: theme.primary, fontWeight: 700 }}>•</span>
                    <span>{line}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Education */}
          {educationLines.length > 0 && (
            <div>
              <h2
                style={{
                  margin: '0 0 10px 0',
                  fontSize: '12px',
                  fontWeight: 800,
                  letterSpacing: '0.1em',
                  color: theme.primary,
                  borderBottom: '1px solid #E2E8F0',
                  paddingBottom: '5px',
                }}
              >
                EDUCATION
              </h2>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '7px' }}>
                {educationLines.map((line, idx) => (
                  <div
                    key={idx}
                    style={{
                      fontSize: '12.5px',
                      lineHeight: 1.5,
                      color: '#1E293B',
                      fontWeight: idx === 0 ? 600 : 400,
                    }}
                  >
                    {line}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Projects & Achievements */}
          {projectLines.length > 0 && (
            <div>
              <h2
                style={{
                  margin: '0 0 10px 0',
                  fontSize: '12px',
                  fontWeight: 800,
                  letterSpacing: '0.1em',
                  color: theme.primary,
                  borderBottom: '1px solid #E2E8F0',
                  paddingBottom: '5px',
                }}
              >
                PROJECTS & CERTIFICATIONS
              </h2>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {projectLines.map((line, idx) => (
                  <div
                    key={idx}
                    style={{
                      display: 'flex',
                      alignItems: 'flex-start',
                      gap: '8px',
                      fontSize: '12.5px',
                      lineHeight: 1.55,
                      color: '#1E293B',
                    }}
                  >
                    <span style={{ color: theme.primary, fontWeight: 700 }}>•</span>
                    <span>{line}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // Template 2: ATS Corporate (Single-column, clean standard typography, no photo for strict ATS parsing)
  if (template === 'ats') {
    const contactParts = [data.phone, data.email, data.address, data.linkedin].filter(Boolean);
    return (
      <div
        className="font-resume"
        style={{
          width: '794px',
          minHeight: '1123px',
          backgroundColor: '#FFFFFF',
          color: '#111827',
          padding: '44px 48px',
          boxSizing: 'border-box',
          display: 'flex',
          flexDirection: 'column',
          gap: '18px',
        }}
      >
        {/* Clean Centered Corporate Header */}
        <div style={{ borderBottom: `2px solid ${theme.primary}`, paddingBottom: '14px', textAlign: 'center' }}>
          <h1
            style={{
              margin: 0,
              fontSize: '28px',
              fontWeight: 800,
              letterSpacing: '0.02em',
              color: '#0F172A',
              textTransform: 'uppercase',
            }}
          >
            {data.fullName || 'Your Name'}
          </h1>
          {data.jobTitle && (
            <div
              style={{
                marginTop: '4px',
                fontSize: '13.5px',
                fontWeight: 600,
                color: theme.primary,
              }}
            >
              {data.jobTitle}
            </div>
          )}
          {contactParts.length > 0 && (
            <div
              style={{
                marginTop: '8px',
                fontSize: '11.5px',
                color: '#374151',
                lineHeight: 1.4,
              }}
            >
              {contactParts.join('  |  ')}
            </div>
          )}
        </div>

        {/* Summary */}
        {data.summary && (
          <div>
            <h2
              style={{
                margin: '0 0 6px 0',
                fontSize: '12.5px',
                fontWeight: 800,
                letterSpacing: '0.08em',
                color: theme.dark,
                borderBottom: '1px solid #CBD5E1',
                paddingBottom: '4px',
              }}
            >
              {summaryHeading}
            </h2>
            <p style={{ margin: 0, fontSize: '12.5px', lineHeight: 1.6, color: '#1F2937' }}>
              {data.summary}
            </p>
          </div>
        )}

        {/* Core Competencies */}
        {skills.length > 0 && (
          <div>
            <h2
              style={{
                margin: '0 0 8px 0',
                fontSize: '12.5px',
                fontWeight: 800,
                letterSpacing: '0.08em',
                color: theme.dark,
                borderBottom: '1px solid #CBD5E1',
                paddingBottom: '4px',
              }}
            >
              CORE COMPETENCIES & SKILLS
            </h2>
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(3, minmax(0, 1fr))',
                gap: '6px 16px',
                fontSize: '12px',
                color: '#1F2937',
              }}
            >
              {skills.map((skill, idx) => (
                <div key={idx} style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <span style={{ color: theme.primary, fontWeight: 700 }}>•</span>
                  <span>{skill}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Experience */}
        {experienceLines.length > 0 && (
          <div>
            <h2
              style={{
                margin: '0 0 8px 0',
                fontSize: '12.5px',
                fontWeight: 800,
                letterSpacing: '0.08em',
                color: theme.dark,
                borderBottom: '1px solid #CBD5E1',
                paddingBottom: '4px',
              }}
            >
              {experienceHeading}
            </h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {experienceLines.map((line, idx) => (
                <div
                  key={idx}
                  style={{
                    display: 'flex',
                    alignItems: 'flex-start',
                    gap: '8px',
                    fontSize: '12.5px',
                    lineHeight: 1.58,
                    color: '#1F2937',
                  }}
                >
                  <span style={{ color: theme.primary, fontWeight: 700 }}>•</span>
                  <span>{line}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Projects */}
        {projectLines.length > 0 && (
          <div>
            <h2
              style={{
                margin: '0 0 8px 0',
                fontSize: '12.5px',
                fontWeight: 800,
                letterSpacing: '0.08em',
                color: theme.dark,
                borderBottom: '1px solid #CBD5E1',
                paddingBottom: '4px',
              }}
            >
              KEY PROJECTS & CERTIFICATIONS
            </h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {projectLines.map((line, idx) => (
                <div
                  key={idx}
                  style={{
                    display: 'flex',
                    alignItems: 'flex-start',
                    gap: '8px',
                    fontSize: '12.5px',
                    lineHeight: 1.58,
                    color: '#1F2937',
                  }}
                >
                  <span style={{ color: theme.primary, fontWeight: 700 }}>•</span>
                  <span>{line}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Education */}
        {educationLines.length > 0 && (
          <div>
            <h2
              style={{
                margin: '0 0 8px 0',
                fontSize: '12.5px',
                fontWeight: 800,
                letterSpacing: '0.08em',
                color: theme.dark,
                borderBottom: '1px solid #CBD5E1',
                paddingBottom: '4px',
              }}
            >
              EDUCATION
            </h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
              {educationLines.map((line, idx) => (
                <div
                  key={idx}
                  style={{
                    fontSize: '12.5px',
                    lineHeight: 1.5,
                    color: '#111827',
                    fontWeight: idx === 0 ? 600 : 400,
                  }}
                >
                  {line}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Languages */}
        {languages.length > 0 && (
          <div>
            <h2
              style={{
                margin: '0 0 6px 0',
                fontSize: '12.5px',
                fontWeight: 800,
                letterSpacing: '0.08em',
                color: theme.dark,
                borderBottom: '1px solid #CBD5E1',
                paddingBottom: '4px',
              }}
            >
              LANGUAGES
            </h2>
            <div style={{ fontSize: '12.5px', color: '#1F2937' }}>{languages.join('  •  ')}</div>
          </div>
        )}
      </div>
    );
  }

  // Template 3: Fresher / Student Smart Resume
  if (template === 'fresher') {
    return (
      <div
        className="font-resume"
        style={{
          width: '794px',
          minHeight: '1123px',
          backgroundColor: '#FFFFFF',
          color: '#1E293B',
          boxSizing: 'border-box',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        {/* Soft Accent Top Header */}
        <div
          style={{
            backgroundColor: theme.soft,
            borderBottom: `3px solid ${theme.primary}`,
            padding: '32px 42px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: '24px',
          }}
        >
          <div style={{ flex: 1 }}>
            <h1
              style={{
                margin: 0,
                fontSize: '29px',
                fontWeight: 800,
                color: '#0F172A',
                letterSpacing: '-0.02em',
              }}
            >
              {data.fullName || 'Your Name'}
            </h1>
            {data.jobTitle && (
              <div
                style={{
                  marginTop: '4px',
                  fontSize: '14px',
                  fontWeight: 700,
                  color: theme.primary,
                }}
              >
                {data.jobTitle}
              </div>
            )}
            <div
              style={{
                marginTop: '10px',
                display: 'flex',
                flexWrap: 'wrap',
                gap: '6px 16px',
                fontSize: '11.5px',
                color: '#334155',
              }}
            >
              {data.phone && <span>Phone: {data.phone}</span>}
              {data.email && <span>Email: {data.email}</span>}
              {data.address && <span>City: {data.address}</span>}
              {data.linkedin && <span>Profile: {data.linkedin}</span>}
            </div>
          </div>

          {photo && (
            <img
              src={photo}
              alt={data.fullName}
              style={{
                width: '92px',
                height: '92px',
                borderRadius: '18px',
                objectFit: 'cover',
                border: `2px solid ${theme.border}`,
                flexShrink: 0,
              }}
            />
          )}
        </div>

        <div
          style={{
            padding: '28px 42px 38px',
            display: 'flex',
            flexDirection: 'column',
            gap: '20px',
          }}
        >
          {/* Career Objective */}
          {data.summary && (
            <div>
              <h2
                style={{
                  margin: '0 0 8px 0',
                  fontSize: '12px',
                  fontWeight: 800,
                  letterSpacing: '0.09em',
                  color: theme.primary,
                }}
              >
                CAREER OBJECTIVE
              </h2>
              <p style={{ margin: 0, fontSize: '12.5px', lineHeight: 1.6, color: '#334155' }}>
                {data.summary}
              </p>
            </div>
          )}

          {/* Education Boxed Highlight for Freshers */}
          {educationLines.length > 0 && (
            <div>
              <h2
                style={{
                  margin: '0 0 10px 0',
                  fontSize: '12px',
                  fontWeight: 800,
                  letterSpacing: '0.09em',
                  color: theme.primary,
                }}
              >
                ACADEMIC QUALIFICATIONS
              </h2>
              <div
                style={{
                  border: `1px solid ${theme.border}`,
                  backgroundColor: '#F8FAFC',
                  borderRadius: '10px',
                  padding: '12px 16px',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '7px',
                }}
              >
                {educationLines.map((line, idx) => (
                  <div
                    key={idx}
                    style={{
                      fontSize: '12.5px',
                      lineHeight: 1.48,
                      color: '#0F172A',
                      fontWeight: idx === 0 ? 700 : 500,
                    }}
                  >
                    {line}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Technical & Computer Skills */}
          {skills.length > 0 && (
            <div>
              <h2
                style={{
                  margin: '0 0 10px 0',
                  fontSize: '12px',
                  fontWeight: 800,
                  letterSpacing: '0.09em',
                  color: theme.primary,
                }}
              >
                TECHNICAL & COMPUTER SKILLS
              </h2>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                {skills.map((skill, idx) => (
                  <span
                    key={idx}
                    style={{
                      backgroundColor: theme.soft,
                      border: `1px solid ${theme.border}`,
                      color: theme.pillText,
                      padding: '5px 11px',
                      borderRadius: '6px',
                      fontSize: '11.5px',
                      fontWeight: 600,
                    }}
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Projects & Certifications (Prominent for Freshers) */}
          {projectLines.length > 0 && (
            <div>
              <h2
                style={{
                  margin: '0 0 8px 0',
                  fontSize: '12px',
                  fontWeight: 800,
                  letterSpacing: '0.09em',
                  color: theme.primary,
                }}
              >
                ACADEMIC PROJECTS & CERTIFICATIONS
              </h2>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {projectLines.map((line, idx) => (
                  <div
                    key={idx}
                    style={{
                      display: 'flex',
                      alignItems: 'flex-start',
                      gap: '8px',
                      fontSize: '12.5px',
                      lineHeight: 1.55,
                      color: '#1E293B',
                    }}
                  >
                    <span style={{ color: theme.primary, fontWeight: 700 }}>•</span>
                    <span>{line}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Internships / Practical Exposure */}
          {experienceLines.length > 0 && (
            <div>
              <h2
                style={{
                  margin: '0 0 8px 0',
                  fontSize: '12px',
                  fontWeight: 800,
                  letterSpacing: '0.09em',
                  color: theme.primary,
                }}
              >
                {experienceHeading}
              </h2>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {experienceLines.map((line, idx) => (
                  <div
                    key={idx}
                    style={{
                      display: 'flex',
                      alignItems: 'flex-start',
                      gap: '8px',
                      fontSize: '12.5px',
                      lineHeight: 1.55,
                      color: '#1E293B',
                    }}
                  >
                    <span style={{ color: theme.primary, fontWeight: 700 }}>•</span>
                    <span>{line}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Languages */}
          {languages.length > 0 && (
            <div style={{ borderTop: '1px solid #E2E8F0', paddingTop: '12px', fontSize: '12px', color: '#334155' }}>
              <strong style={{ color: theme.dark }}>Languages Known: </strong>
              {languages.join(' • ')}
            </div>
          )}
        </div>
      </div>
    );
  }

  // Template 4: Creative & Minimalist (Asymmetric clean modern design with generous whitespace)
  return (
    <div
      className="font-resume"
      style={{
        width: '794px',
        minHeight: '1123px',
        backgroundColor: '#FFFFFF',
        color: '#1E293B',
        padding: '42px 44px',
        boxSizing: 'border-box',
        display: 'flex',
        flexDirection: 'column',
        gap: '24px',
        borderTop: `8px solid ${theme.primary}`,
      }}
    >
      {/* Asymmetric Minimalist Header */}
      <div
        style={{
          display: 'flex',
          alignItems: 'flex-start',
          justifyContent: 'space-between',
          gap: '24px',
          paddingBottom: '20px',
          borderBottom: '1px solid #E2E8F0',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '18px', flex: 1 }}>
          {photo && (
            <img
              src={photo}
              alt={data.fullName}
              style={{
                width: '76px',
                height: '76px',
                borderRadius: '9999px',
                objectFit: 'cover',
                border: `2px solid ${theme.primary}`,
                flexShrink: 0,
              }}
            />
          )}
          <div>
            <h1
              style={{
                margin: 0,
                fontSize: '30px',
                fontWeight: 800,
                letterSpacing: '-0.025em',
                color: '#0F172A',
                lineHeight: 1.15,
              }}
            >
              {data.fullName || 'Your Name'}
            </h1>
            {data.jobTitle && (
              <div
                style={{
                  marginTop: '5px',
                  fontSize: '13.5px',
                  fontWeight: 600,
                  color: theme.primary,
                }}
              >
                {data.jobTitle}
              </div>
            )}
          </div>
        </div>

        <div
          style={{
            textAlign: 'right',
            fontSize: '11.5px',
            lineHeight: 1.55,
            color: '#475569',
            flexShrink: 0,
          }}
        >
          {data.phone && <div>{data.phone}</div>}
          {data.email && <div>{data.email}</div>}
          {data.address && <div>{data.address}</div>}
          {data.linkedin && <div style={{ color: theme.primary }}>{data.linkedin}</div>}
        </div>
      </div>

      {/* Summary */}
      {data.summary && (
        <div style={{ display: 'grid', gridTemplateColumns: '155px 1fr', gap: '20px' }}>
          <div
            style={{
              fontSize: '11px',
              fontWeight: 800,
              letterSpacing: '0.12em',
              color: theme.primary,
              paddingTop: '3px',
            }}
          >
            PROFILE
          </div>
          <p style={{ margin: 0, fontSize: '12.5px', lineHeight: 1.65, color: '#334155' }}>
            {data.summary}
          </p>
        </div>
      )}

      {/* Experience */}
      {experienceLines.length > 0 && (
        <div style={{ display: 'grid', gridTemplateColumns: '155px 1fr', gap: '20px' }}>
          <div
            style={{
              fontSize: '11px',
              fontWeight: 800,
              letterSpacing: '0.12em',
              color: theme.primary,
              paddingTop: '3px',
            }}
          >
            {isFresher ? 'INTERNSHIPS' : 'EXPERIENCE'}
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {experienceLines.map((line, idx) => (
              <div
                key={idx}
                style={{
                  display: 'flex',
                  alignItems: 'flex-start',
                  gap: '8px',
                  fontSize: '12.5px',
                  lineHeight: 1.58,
                  color: '#1E293B',
                }}
              >
                <span style={{ color: theme.primary, fontWeight: 700 }}>—</span>
                <span>{line}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Education */}
      {educationLines.length > 0 && (
        <div style={{ display: 'grid', gridTemplateColumns: '155px 1fr', gap: '20px' }}>
          <div
            style={{
              fontSize: '11px',
              fontWeight: 800,
              letterSpacing: '0.12em',
              color: theme.primary,
              paddingTop: '3px',
            }}
          >
            EDUCATION
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '7px' }}>
            {educationLines.map((line, idx) => (
              <div
                key={idx}
                style={{
                  fontSize: '12.5px',
                  lineHeight: 1.5,
                  color: '#0F172A',
                  fontWeight: idx === 0 ? 600 : 400,
                }}
              >
                {line}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Skills */}
      {skills.length > 0 && (
        <div style={{ display: 'grid', gridTemplateColumns: '155px 1fr', gap: '20px' }}>
          <div
            style={{
              fontSize: '11px',
              fontWeight: 800,
              letterSpacing: '0.12em',
              color: theme.primary,
              paddingTop: '4px',
            }}
          >
            SKILLS
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '7px' }}>
            {skills.map((skill, idx) => (
              <span
                key={idx}
                style={{
                  border: `1px solid ${theme.border}`,
                  backgroundColor: theme.soft,
                  color: theme.pillText,
                  borderRadius: '6px',
                  padding: '4px 10px',
                  fontSize: '11.5px',
                  fontWeight: 600,
                }}
              >
                {skill}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Projects & Achievements */}
      {projectLines.length > 0 && (
        <div style={{ display: 'grid', gridTemplateColumns: '155px 1fr', gap: '20px' }}>
          <div
            style={{
              fontSize: '11px',
              fontWeight: 800,
              letterSpacing: '0.12em',
              color: theme.primary,
              paddingTop: '3px',
            }}
          >
            PROJECTS
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {projectLines.map((line, idx) => (
              <div
                key={idx}
                style={{
                  display: 'flex',
                  alignItems: 'flex-start',
                  gap: '8px',
                  fontSize: '12.5px',
                  lineHeight: 1.55,
                  color: '#1E293B',
                }}
              >
                <span style={{ color: theme.primary, fontWeight: 700 }}>—</span>
                <span>{line}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Languages */}
      {languages.length > 0 && (
        <div style={{ display: 'grid', gridTemplateColumns: '155px 1fr', gap: '20px' }}>
          <div
            style={{
              fontSize: '11px',
              fontWeight: 800,
              letterSpacing: '0.12em',
              color: theme.primary,
              paddingTop: '2px',
            }}
          >
            LANGUAGES
          </div>
          <div style={{ fontSize: '12.5px', color: '#334155' }}>{languages.join('  •  ')}</div>
        </div>
      )}
    </div>
  );
};

export const ResumeModal: React.FC<ResumeModalProps> = ({ isOpen, onClose, darkMode }) => {
  const [template, setTemplate] = useState<TemplateId>('executive');
  const [accent, setAccent] = useState<AccentId>('blue');
  const [isFresher, setIsFresher] = useState<boolean>(false);
  const [aiLanguage, setAiLanguage] = useState<'en' | 'hi'>('en');
  const [photo, setPhoto] = useState<string | null>(null);
  const [formData, setFormData] = useState<ResumeData>(INITIAL_RESUME_DATA);
  const [mobileTab, setMobileTab] = useState<'edit' | 'preview'>('edit');

  const [isEnhancing, setIsEnhancing] = useState(false);
  const [enhanceNotice, setEnhanceNotice] = useState<string | null>(null);
  const [isExporting, setIsExporting] = useState(false);
  const [exportError, setExportError] = useState<string | null>(null);

  const previewContainerRef = useRef<HTMLDivElement | null>(null);
  const exportSheetRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [previewScale, setPreviewScale] = useState<number>(0.58);

  useEffect(() => {
    if (!isOpen) return;
    const container = previewContainerRef.current;
    if (!container) return;

    const updateScale = () => {
      const availableWidth = container.clientWidth - 32;
      if (availableWidth > 0) {
        setPreviewScale(Math.min(0.76, Math.max(0.32, availableWidth / 794)));
      }
    };

    updateScale();
    const observer = new ResizeObserver(updateScale);
    observer.observe(container);
    return () => observer.disconnect();
  }, [isOpen, mobileTab]);

  if (!isOpen) return null;

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 4 * 1024 * 1024) {
      setExportError('फोटो 4 MB से कम साइज का चुनें।');
      return;
    }
    setExportError(null);
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setPhoto(reader.result);
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleAIEnhance = async () => {
    if (isEnhancing) return;
    setIsEnhancing(true);
    setEnhanceNotice(null);
    setExportError(null);

    try {
      const hasDevanagari = /[\u0900-\u097F]/.test(
        `${formData.fullName} ${formData.jobTitle} ${formData.education} ${formData.skills}`
      );
      const langToSend = aiLanguage === 'hi' || hasDevanagari ? 'hi' : 'en';

      const response = await fetch('/api/resume/ai-enhance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fullName: formData.fullName,
          jobTitle: formData.jobTitle,
          education: formData.education,
          skills: formData.skills,
          experience: formData.experience,
          projects: formData.projects,
          isFresher,
          language: langToSend,
        }),
      });

      const result = await response.json();
      if (!response.ok) {
        throw new Error(result?.error || 'AI सुधार करने में त्रुटि हुई।');
      }

      setFormData((prev) => ({
        ...prev,
        summary: result.summary || prev.summary,
        skills: result.skills || prev.skills,
        experience: result.experience || prev.experience,
        projects: result.projects || prev.projects,
      }));
      setEnhanceNotice('AI ने आपकी प्रोफ़ाइल के अनुसार Summary, Skills और बुलेट पॉइंट्स तैयार कर दिए हैं।');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'AI से लाइनें लिखने में समस्या आई।';
      setExportError(msg);
    } finally {
      setIsEnhancing(false);
    }
  };

  const handleDownloadPDF = async () => {
    if (!exportSheetRef.current || isExporting) return;
    setIsExporting(true);
    setExportError(null);

    try {
      if (document.fonts && document.fonts.ready) {
        await document.fonts.ready;
      }

      const canvas = await html2canvas(exportSheetRef.current, {
        scale: 2.5,
        useCORS: true,
        backgroundColor: '#ffffff',
        width: 794,
        windowWidth: 794,
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });

      const pageWidth = 210;
      const pageHeight = 297;
      const renderedHeight = (canvas.height * pageWidth) / canvas.width;

      if (renderedHeight <= pageHeight + 1) {
        pdf.addImage(imgData, 'PNG', 0, 0, pageWidth, Math.min(pageHeight, renderedHeight), undefined, 'FAST');
      } else {
        let heightLeft = renderedHeight;
        let position = 0;
        pdf.addImage(imgData, 'PNG', 0, position, pageWidth, renderedHeight, undefined, 'FAST');
        heightLeft -= pageHeight;
        while (heightLeft > 2) {
          position -= pageHeight;
          pdf.addPage();
          pdf.addImage(imgData, 'PNG', 0, position, pageWidth, renderedHeight, undefined, 'FAST');
          heightLeft -= pageHeight;
        }
      }

      const safeName = (formData.fullName || 'Resume').trim().replace(/\s+/g, '_');
      pdf.save(`${safeName}_CV.pdf`);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'PDF डाउनलोड करने में समस्या आई।';
      setExportError(msg);
    } finally {
      setIsExporting(false);
    }
  };

  const inputClass = `w-full px-3 py-2 rounded-xl border text-xs sm:text-sm outline-none transition-colors ${
    darkMode
      ? 'bg-slate-800/80 border-slate-700 text-slate-100 placeholder:text-slate-500 focus:border-blue-500'
      : 'bg-slate-50 border-slate-200 text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:bg-white'
  }`;

  const labelClass = `block text-xs font-semibold mb-1.5 ${
    darkMode ? 'text-slate-300' : 'text-slate-700'
  }`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/75 backdrop-blur-xs">
      <div
        className={`w-full max-w-6xl h-[94vh] flex flex-col rounded-2xl shadow-2xl border overflow-hidden ${
          darkMode ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        {/* Top Studio Bar */}
        <div
          className={`flex items-center justify-between px-4 sm:px-6 py-3.5 border-b shrink-0 ${
            darkMode ? 'border-slate-800 bg-slate-900' : 'border-slate-200 bg-white'
          }`}
        >
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0">
              <FileText className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h2 className="font-bold text-sm sm:text-base truncate">
                प्रोफेशनल रिज्यूमे और बायोडाटा स्टूडियो
              </h2>
              <p className={`text-xs truncate ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                4 मॉडर्न टेम्पलेट • AI राइटर • बिना वॉटरमार्क HD A4 PDF
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {/* Mobile Edit/Preview Switch */}
            <div
              className={`flex lg:hidden items-center rounded-xl p-1 border ${
                darkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-100 border-slate-200'
              }`}
            >
              <button
                type="button"
                onClick={() => setMobileTab('edit')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                  mobileTab === 'edit'
                    ? darkMode
                      ? 'bg-slate-700 text-white'
                      : 'bg-white text-slate-900 shadow-xs'
                    : darkMode
                      ? 'text-slate-400'
                      : 'text-slate-600'
                }`}
              >
                <PenLine className="w-3.5 h-3.5" />
                <span>भरें</span>
              </button>
              <button
                type="button"
                onClick={() => setMobileTab('preview')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                  mobileTab === 'preview'
                    ? darkMode
                      ? 'bg-slate-700 text-white'
                      : 'bg-white text-slate-900 shadow-xs'
                    : darkMode
                      ? 'text-slate-400'
                      : 'text-slate-600'
                }`}
              >
                <Eye className="w-3.5 h-3.5" />
                <span>A4 प्रीव्यू</span>
              </button>
            </div>

            <button
              type="button"
              onClick={handleDownloadPDF}
              disabled={isExporting}
              className="hidden sm:inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white font-semibold text-xs whitespace-nowrap shrink-0 transition-colors cursor-pointer"
            >
              {isExporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
              <span>{isExporting ? 'PDF बन रहा है...' : '📥 Download HD PDF'}</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              aria-label="Close"
              className={`p-2 rounded-xl transition-colors cursor-pointer ${
                darkMode ? 'hover:bg-slate-800 text-slate-400' : 'hover:bg-slate-100 text-slate-500'
              }`}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Main Workspace Split */}
        <div className="flex-1 min-h-0 flex flex-col lg:flex-row overflow-hidden">
          {/* Left Editor Panel */}
          <div
            className={`w-full lg:w-[46%] xl:w-[44%] overflow-y-auto p-4 sm:p-5 space-y-5 border-b lg:border-b-0 lg:border-r ${
              darkMode ? 'border-slate-800 bg-slate-900' : 'border-slate-200 bg-white'
            } ${mobileTab === 'edit' ? 'block' : 'hidden lg:block'}`}
          >
            {/* Step 1: Template Selector */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className={`text-xs font-bold uppercase tracking-wider ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                  1. डिज़ाइन टेम्पलेट चुनें
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2.5">
                {TEMPLATE_META.map((item) => {
                  const selected = template === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setTemplate(item.id)}
                      className={`text-left p-3 rounded-xl border transition-all cursor-pointer flex items-center gap-3 ${
                        selected
                          ? darkMode
                            ? 'border-blue-500 bg-blue-500/10 text-white'
                            : 'border-blue-600 bg-blue-50/80 text-slate-900'
                          : darkMode
                            ? 'border-slate-800 bg-slate-800/40 hover:border-slate-700 text-slate-300'
                            : 'border-slate-200 bg-slate-50/70 hover:border-slate-300 text-slate-800'
                      }`}
                    >
                      {/* Mini visual layout glyph */}
                      <div
                        className={`w-8 h-10 rounded-md border shrink-0 overflow-hidden flex ${
                          darkMode ? 'border-slate-700 bg-slate-900' : 'border-slate-300 bg-white'
                        }`}
                      >
                        {item.id === 'executive' && (
                          <>
                            <div className="w-3 h-full" style={{ backgroundColor: ACCENT_THEMES[accent].dark }} />
                            <div className="flex-1 p-1 space-y-1">
                              <div className="h-1 w-full rounded bg-slate-300" />
                              <div className="h-0.5 w-3/4 rounded bg-slate-200" />
                              <div className="h-0.5 w-full rounded bg-slate-200" />
                            </div>
                          </>
                        )}
                        {item.id === 'ats' && (
                          <div className="w-full p-1 space-y-1">
                            <div className="h-1 w-4/5 mx-auto rounded" style={{ backgroundColor: ACCENT_THEMES[accent].primary }} />
                            <div className="h-0.5 w-full rounded bg-slate-300" />
                            <div className="h-0.5 w-full rounded bg-slate-200" />
                            <div className="h-0.5 w-3/4 rounded bg-slate-200" />
                          </div>
                        )}
                        {item.id === 'fresher' && (
                          <div className="w-full flex flex-col">
                            <div className="h-3 w-full" style={{ backgroundColor: ACCENT_THEMES[accent].soft }} />
                            <div className="p-1 space-y-1">
                              <div className="h-1 w-full rounded bg-slate-300" />
                              <div className="h-0.5 w-2/3 rounded bg-slate-200" />
                            </div>
                          </div>
                        )}
                        {item.id === 'creative' && (
                          <div className="w-full p-1 space-y-1" style={{ borderTop: `2px solid ${ACCENT_THEMES[accent].primary}` }}>
                            <div className="flex items-center gap-1">
                              <div className="w-2 h-2 rounded-full bg-slate-300" />
                              <div className="h-1 flex-1 rounded bg-slate-300" />
                            </div>
                            <div className="h-0.5 w-full rounded bg-slate-200" />
                            <div className="h-0.5 w-4/5 rounded bg-slate-200" />
                          </div>
                        )}
                      </div>

                      <div className="min-w-0 flex-1">
                        <div className="text-xs font-bold truncate">{item.name}</div>
                        <div className={`text-[11px] truncate ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                          {item.subtitle}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Accent Color & Candidate Mode */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <span className={`block text-xs font-bold uppercase tracking-wider mb-2 ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                  थीम रंग (Color)
                </span>
                <div className="flex items-center gap-2">
                  {(Object.keys(ACCENT_THEMES) as AccentId[]).map((key) => {
                    const t = ACCENT_THEMES[key];
                    const active = accent === key;
                    return (
                      <button
                        key={key}
                        type="button"
                        onClick={() => setAccent(key)}
                        className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                          active
                            ? darkMode
                              ? 'border-blue-400 bg-slate-800 text-white'
                              : 'border-slate-900 bg-slate-100 text-slate-900'
                            : darkMode
                              ? 'border-slate-800 text-slate-400 hover:border-slate-700'
                              : 'border-slate-200 text-slate-600 hover:border-slate-300'
                        }`}
                      >
                        <span
                          className="w-3.5 h-3.5 rounded-full flex items-center justify-center shrink-0"
                          style={{ backgroundColor: t.swatch }}
                        >
                          {active && <Check className="w-2.5 h-2.5 text-white" />}
                        </span>
                        <span>{t.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <span className={`block text-xs font-bold uppercase tracking-wider mb-2 ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                  प्रोफ़ाइल स्तर (Level)
                </span>
                <div
                  className={`inline-flex rounded-xl p-1 border w-full ${
                    darkMode ? 'bg-slate-800/70 border-slate-700' : 'bg-slate-100 border-slate-200'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => setIsFresher(false)}
                    className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                      !isFresher
                        ? darkMode
                          ? 'bg-slate-700 text-white'
                          : 'bg-white text-slate-900 shadow-xs'
                        : darkMode
                          ? 'text-slate-400'
                          : 'text-slate-600'
                    }`}
                  >
                    Experienced
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setIsFresher(true);
                      if (template === 'executive') setTemplate('fresher');
                    }}
                    className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                      isFresher
                        ? darkMode
                          ? 'bg-slate-700 text-white'
                          : 'bg-white text-slate-900 shadow-xs'
                        : darkMode
                          ? 'text-slate-400'
                          : 'text-slate-600'
                    }`}
                  >
                    Fresher / छात्र
                  </button>
                </div>
              </div>
            </div>

            {/* AI Auto-Writer Card */}
            <div
              className={`p-3.5 rounded-xl border ${
                darkMode
                  ? 'bg-slate-800/60 border-slate-700'
                  : 'bg-blue-50/70 border-blue-200'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="text-xs font-bold flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 shrink-0" />
                    <span>AI प्रोफेशनल कंटेंट राइटर</span>
                  </div>
                  <p className={`text-[11px] mt-0.5 ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                    नाम, पद (Role) और शिक्षा लिखकर बटन दबाएं — Summary, Skills और Experience अपने-आप बनेंगे।
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <select
                    value={aiLanguage}
                    onChange={(e) => setAiLanguage(e.target.value as 'en' | 'hi')}
                    aria-label="AI Resume Language"
                    className={`px-2 py-2 rounded-xl border text-xs font-semibold outline-none ${
                      darkMode
                        ? 'bg-slate-900 border-slate-700 text-slate-200'
                        : 'bg-white border-slate-200 text-slate-700'
                    }`}
                  >
                    <option value="en">English</option>
                    <option value="hi">हिंदी</option>
                  </select>

                  <button
                    type="button"
                    onClick={handleAIEnhance}
                    disabled={isEnhancing}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white text-xs font-bold whitespace-nowrap shrink-0 transition-colors cursor-pointer"
                  >
                    {isEnhancing ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Sparkles className="w-3.5 h-3.5" />
                    )}
                    <span>{isEnhancing ? 'AI लिख रहा है...' : '✨ AI से प्रोफेशनल लाइनें लिखें'}</span>
                  </button>
                </div>
              </div>

              {enhanceNotice && (
                <div className="mt-2.5 text-xs font-medium text-emerald-700 dark:text-emerald-400">
                  {enhanceNotice}
                </div>
              )}
              {exportError && (
                <div className="mt-2.5 text-xs font-medium text-rose-600 dark:text-rose-400">
                  {exportError}
                </div>
              )}
            </div>

            {/* Profile Photo + Name & Role */}
            <div className="space-y-3">
              <div className="flex items-center justify-between gap-3 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
                <div className="flex items-center gap-3 min-w-0">
                  {photo ? (
                    <img
                      src={photo}
                      alt="Profile"
                      className="w-12 h-12 rounded-full object-cover border border-slate-300 dark:border-slate-700 shrink-0"
                    />
                  ) : (
                    <div
                      className={`w-12 h-12 rounded-full flex items-center justify-center text-sm font-bold shrink-0 ${
                        darkMode ? 'bg-slate-800 text-slate-300' : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {getInitials(formData.fullName)}
                    </div>
                  )}
                  <div className="min-w-0">
                    <div className="text-xs font-semibold">प्रोफ़ाइल फोटो (वैकल्पिक)</div>
                    <div className={`text-[11px] truncate ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                      {template === 'ats'
                        ? 'ATS Corporate टेम्पलेट में फोटो छिपी रहती है'
                        : 'Executive, Fresher व Creative में दिखती है'}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoUpload}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold whitespace-nowrap cursor-pointer ${
                      darkMode
                        ? 'border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-200'
                        : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>{photo ? 'बदलें' : 'फोटो अपलोड'}</span>
                  </button>
                  {photo && (
                    <button
                      type="button"
                      onClick={() => setPhoto(null)}
                      aria-label="Remove photo"
                      className="p-1.5 rounded-xl border border-rose-200 dark:border-rose-900/50 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className={labelClass}>पूरा नाम (Full Name)</label>
                  <input
                    type="text"
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    placeholder="जैसे: Rahul Sharma / राहुल शर्मा"
                    className={inputClass}
                  />
                </div>
                <div>
                  <label className={labelClass}>लक्ष्य पद / जॉब रोल (Job Title)</label>
                  <input
                    type="text"
                    value={formData.jobTitle}
                    onChange={(e) => setFormData({ ...formData, jobTitle: e.target.value })}
                    placeholder="जैसे: Accountant / Web Developer"
                    className={inputClass}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className={labelClass}>
                    <span className="inline-flex items-center gap-1"><Phone className="w-3 h-3" /> मोबाइल नंबर</span>
                  </label>
                  <input
                    type="text"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className={inputClass}
                  />
                </div>
                <div>
                  <label className={labelClass}>
                    <span className="inline-flex items-center gap-1"><Mail className="w-3 h-3" /> ईमेल (Email)</span>
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className={inputClass}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className={labelClass}>
                    <span className="inline-flex items-center gap-1"><MapPin className="w-3 h-3" /> शहर व राज्य</span>
                  </label>
                  <input
                    type="text"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className={inputClass}
                  />
                </div>
                <div>
                  <label className={labelClass}>
                    <span className="inline-flex items-center gap-1"><Globe className="w-3 h-3" /> LinkedIn / Portfolio</span>
                  </label>
                  <input
                    type="text"
                    value={formData.linkedin}
                    onChange={(e) => setFormData({ ...formData, linkedin: e.target.value })}
                    placeholder="वैकल्पिक"
                    className={inputClass}
                  />
                </div>
              </div>

              <div>
                <label className={labelClass}>
                  <span className="inline-flex items-center gap-1"><UserCheck className="w-3 h-3" /> प्रोफेशनल समरी / उद्देश्य</span>
                </label>
                <textarea
                  rows={3}
                  value={formData.summary}
                  onChange={(e) => setFormData({ ...formData, summary: e.target.value })}
                  className={`${inputClass} resize-y`}
                />
              </div>

              <div>
                <label className={labelClass}>
                  <span className="inline-flex items-center gap-1"><GraduationCap className="w-3 h-3" /> शिक्षा व डिग्री (हर डिग्री नई लाइन में)</span>
                </label>
                <textarea
                  rows={2}
                  value={formData.education}
                  onChange={(e) => setFormData({ ...formData, education: e.target.value })}
                  className={`${inputClass} resize-y`}
                />
              </div>

              <div>
                <label className={labelClass}>कौशल / Skills (कॉमा , से अलग लिखें)</label>
                <input
                  type="text"
                  value={formData.skills}
                  onChange={(e) => setFormData({ ...formData, skills: e.target.value })}
                  className={inputClass}
                />
              </div>

              <div>
                <label className={labelClass}>
                  <span className="inline-flex items-center gap-1">
                    <Briefcase className="w-3 h-3" />
                    {isFresher ? 'इंटर्नशिप / व्यावहारिक प्रशिक्षण' : 'कार्य अनुभव (Work Experience)'}
                  </span>
                </label>
                <textarea
                  rows={3}
                  value={formData.experience}
                  onChange={(e) => setFormData({ ...formData, experience: e.target.value })}
                  className={`${inputClass} resize-y`}
                />
              </div>

              <div>
                <label className={labelClass}>
                  <span className="inline-flex items-center gap-1">
                    <FolderKanban className="w-3 h-3" /> प्रोजेक्ट्स व सर्टिफिकेट (Projects & Achievements)
                  </span>
                </label>
                <textarea
                  rows={2}
                  value={formData.projects}
                  onChange={(e) => setFormData({ ...formData, projects: e.target.value })}
                  className={`${inputClass} resize-y`}
                />
              </div>

              <div>
                <label className={labelClass}>
                  <span className="inline-flex items-center gap-1"><Languages className="w-3 h-3" /> भाषाएं (Languages)</span>
                </label>
                <input
                  type="text"
                  value={formData.languages}
                  onChange={(e) => setFormData({ ...formData, languages: e.target.value })}
                  className={inputClass}
                />
              </div>
            </div>
          </div>

          {/* Right Live A4 Preview Pane */}
          <div
            ref={previewContainerRef}
            className={`flex-1 overflow-y-auto p-4 sm:p-6 flex flex-col items-center ${
              darkMode ? 'bg-slate-950' : 'bg-slate-100'
            } ${mobileTab === 'preview' ? 'flex' : 'hidden lg:flex'}`}
          >
            <div className="w-full max-w-[620px] flex items-center justify-between mb-3 px-1">
              <span className={`text-xs font-semibold ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                लाइव A4 प्रीव्यू ({TEMPLATE_META.find((t) => t.id === template)?.name})
              </span>
              <span className={`text-[11px] ${darkMode ? 'text-slate-500' : 'text-slate-500'}`}>
                A4 (210 × 297 mm) • बिना वॉटरमार्क
              </span>
            </div>

            {/* Scaled A4 Page Wrapper */}
            <div
              style={{
                width: `${Math.round(794 * previewScale)}px`,
                height: `${Math.round(1123 * previewScale)}px`,
                position: 'relative',
                flexShrink: 0,
              }}
            >
              <div
                style={{
                  width: '794px',
                  minHeight: '1123px',
                  transform: `scale(${previewScale})`,
                  transformOrigin: 'top left',
                  boxShadow: '0 18px 45px rgba(15, 23, 42, 0.22)',
                  backgroundColor: '#FFFFFF',
                }}
              >
                <ResumeSheet
                  template={template}
                  accent={accent}
                  data={formData}
                  photo={photo}
                  isFresher={isFresher}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Mobile Action Footer */}
        <div
          className={`sm:hidden flex items-center justify-between gap-2 px-4 py-3 border-t shrink-0 ${
            darkMode ? 'border-slate-800 bg-slate-900' : 'border-slate-200 bg-white'
          }`}
        >
          <button
            type="button"
            onClick={onClose}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold ${
              darkMode ? 'text-slate-400 hover:bg-slate-800' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            बंद करें
          </button>
          <button
            type="button"
            onClick={handleDownloadPDF}
            disabled={isExporting}
            className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white font-bold text-xs whitespace-nowrap cursor-pointer"
          >
            {isExporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
            <span>{isExporting ? 'PDF बन रहा है...' : '📥 Download HD PDF'}</span>
          </button>
        </div>
      </div>

      {/* Offscreen Unscaled Full-Resolution A4 Sheet for Crisp HD PDF Export */}
      <div
        aria-hidden="true"
        style={{
          position: 'fixed',
          left: '-12000px',
          top: 0,
          width: '794px',
          minHeight: '1123px',
          backgroundColor: '#FFFFFF',
          pointerEvents: 'none',
          zIndex: -1,
        }}
      >
        <div ref={exportSheetRef} style={{ width: '794px', minHeight: '1123px', backgroundColor: '#FFFFFF' }}>
          <ResumeSheet
            template={template}
            accent={accent}
            data={formData}
            photo={photo}
            isFresher={isFresher}
          />
        </div>
      </div>
    </div>
  );
};

