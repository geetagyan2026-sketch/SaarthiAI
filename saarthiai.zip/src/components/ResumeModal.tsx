import React, { useState } from 'react';
import { jsPDF } from 'jspdf';
import { FileText, X, Download, Sparkles, User, Phone, Mail, MapPin, Award, BookOpen } from 'lucide-react';

interface ResumeModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
}

export const ResumeModal: React.FC<ResumeModalProps> = ({ isOpen, onClose, darkMode }) => {
  const [formData, setFormData] = useState({
    name: 'राहुल कुमार',
    phone: '+91 98765 43210',
    email: 'rahul.kumar@gmail.com',
    address: 'नयी दिल्ली, भारत',
    objective: 'एक मेहनती और कुशल पेशेवर जो अपनी क्षमताओं से कंपनी की प्रगति में योगदान देना चाहता है।',
    education: 'स्नातक (Graduate) - दिल्ली विश्वविद्यालय, 2024',
    skills: 'कंप्यूटर बेसिक, टैली (Tally), ग्राहक सेवा, डेटा एंट्री, हिंदी और अंग्रेजी टाइपिंग',
    experience: '1 वर्ष कस्टमर सपोर्ट और डेटा एंट्री का अनुभव',
  });

  const [generated, setGenerated] = useState(false);

  if (!isOpen) return null;

  const handleGeneratePDF = () => {
    const doc = new jsPDF();
    
    // Header
    doc.setFillColor(79, 70, 229); // Indigo
    doc.rect(0, 0, 210, 40, 'F');
    
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(22);
    doc.text(formData.name, 20, 22);
    
    doc.setFontSize(11);
    doc.text(`${formData.phone} | ${formData.email} | ${formData.address}`, 20, 32);

    // Body content
    doc.setTextColor(30, 41, 59);
    let y = 55;

    doc.setFontSize(14);
    doc.setTextColor(79, 70, 229);
    doc.text('1. कॅरियर उद्देश्य (Objective)', 20, y);
    y += 8;
    doc.setFontSize(11);
    doc.setTextColor(50, 50, 50);
    doc.text(doc.splitTextToSize(formData.objective, 170), 20, y);

    y += 20;
    doc.setFontSize(14);
    doc.setTextColor(79, 70, 229);
    doc.text('2. शिक्षा (Education)', 20, y);
    y += 8;
    doc.setFontSize(11);
    doc.setTextColor(50, 50, 50);
    doc.text(doc.splitTextToSize(formData.education, 170), 20, y);

    y += 20;
    doc.setFontSize(14);
    doc.setTextColor(79, 70, 229);
    doc.text('3. कौशल व योग्यता (Skills)', 20, y);
    y += 8;
    doc.setFontSize(11);
    doc.setTextColor(50, 50, 50);
    doc.text(doc.splitTextToSize(formData.skills, 170), 20, y);

    y += 20;
    doc.setFontSize(14);
    doc.setTextColor(79, 70, 229);
    doc.text('4. कार्य अनुभव (Experience)', 20, y);
    y += 8;
    doc.setFontSize(11);
    doc.setTextColor(50, 50, 50);
    doc.text(doc.splitTextToSize(formData.experience, 170), 20, y);

    // Footer
    doc.setFontSize(9);
    doc.setTextColor(150, 150, 150);
    doc.text('Generated instantly via SaarthiAI — हर समस्या का हल', 20, 285);

    doc.save(`${formData.name.replace(/\s+/g, '_')}_Resume.pdf`);
    setGenerated(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
      <div className={`w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 rounded-3xl shadow-2xl border transition-all ${
        darkMode ? 'bg-gray-900 border-gray-800 text-white' : 'bg-white border-gray-200 text-gray-900'
      }`}>
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-gray-200 dark:border-gray-800">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-md">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-base sm:text-lg">📄 1-सेकंड रिज्यूमे / बायोडाटा मेकर</h2>
              <p className="text-xs text-gray-400">अपनी जानकारी भरें और तुरंत A4 PDF डाउनलोड करें</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className={`p-1.5 rounded-lg transition-colors ${darkMode ? 'hover:bg-gray-800 text-gray-400' : 'hover:bg-gray-100 text-gray-600'}`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4 text-xs sm:text-sm">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1">पूरा नाम (Full Name)</label>
              <input
                type="text"
                value={formData.name}
                onChange={e => setFormData({ ...formData, name: e.target.value })}
                className={`w-full px-3.5 py-2.5 rounded-xl border outline-none ${
                  darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
                }`}
              />
            </div>
            <div>
              <label className="block font-semibold mb-1">मोबाइल नंबर (Phone)</label>
              <input
                type="text"
                value={formData.phone}
                onChange={e => setFormData({ ...formData, phone: e.target.value })}
                className={`w-full px-3.5 py-2.5 rounded-xl border outline-none ${
                  darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
                }`}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1">ईमेल (Email)</label>
              <input
                type="text"
                value={formData.email}
                onChange={e => setFormData({ ...formData, email: e.target.value })}
                className={`w-full px-3.5 py-2.5 rounded-xl border outline-none ${
                  darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
                }`}
              />
            </div>
            <div>
              <label className="block font-semibold mb-1">शहर / पता (City / Address)</label>
              <input
                type="text"
                value={formData.address}
                onChange={e => setFormData({ ...formData, address: e.target.value })}
                className={`w-full px-3.5 py-2.5 rounded-xl border outline-none ${
                  darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
                }`}
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold mb-1">शिक्षा / योग्यता (Education)</label>
            <input
              type="text"
              value={formData.education}
              onChange={e => setFormData({ ...formData, education: e.target.value })}
              className={`w-full px-3.5 py-2.5 rounded-xl border outline-none ${
                darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
              }`}
            />
          </div>

          <div>
            <label className="block font-semibold mb-1">कौशल / हुनर (Skills)</label>
            <input
              type="text"
              value={formData.skills}
              onChange={e => setFormData({ ...formData, skills: e.target.value })}
              className={`w-full px-3.5 py-2.5 rounded-xl border outline-none ${
                darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
              }`}
            />
          </div>

          <div>
            <label className="block font-semibold mb-1">अनुभव / उद्देश्य (Experience & Objective)</label>
            <textarea
              rows={2}
              value={formData.experience}
              onChange={e => setFormData({ ...formData, experience: e.target.value })}
              className={`w-full px-3.5 py-2.5 rounded-xl border outline-none resize-none ${
                darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
              }`}
            />
          </div>

          {/* A4 Preview Card */}
          <div className="p-4 rounded-2xl bg-white text-gray-900 border border-gray-300 shadow-inner mt-4">
            <div className="bg-indigo-600 text-white p-3 rounded-xl mb-3">
              <h3 className="font-bold text-base">{formData.name}</h3>
              <p className="text-[11px] opacity-90">{formData.phone} | {formData.email} | {formData.address}</p>
            </div>
            <div className="space-y-2 text-xs">
              <div><strong>शिक्षा:</strong> {formData.education}</div>
              <div><strong>कौशल:</strong> {formData.skills}</div>
              <div><strong>अनुभव:</strong> {formData.experience}</div>
            </div>
          </div>

          <div className="pt-3 flex items-center justify-between">
            <button
              onClick={onClose}
              className={`px-4 py-2.5 rounded-xl text-xs font-medium transition-colors ${
                darkMode ? 'hover:bg-gray-800 text-gray-400' : 'hover:bg-gray-100 text-gray-600'
              }`}
            >
              रद्द करें
            </button>
            <button
              onClick={handleGeneratePDF}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white font-bold text-xs sm:text-sm shadow-lg flex items-center gap-2 transition-all active:scale-95"
            >
              <Download className="w-4 h-4" />
              <span>📥 Download A4 PDF</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
