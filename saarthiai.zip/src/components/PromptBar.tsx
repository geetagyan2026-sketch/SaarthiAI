import React, { useState, useRef, useEffect } from 'react';
import { Camera, Mic, MicOff, Send, X } from 'lucide-react';
import { SPEECH_LANG_MAP } from '../lib/regions';

interface PromptBarProps {
  onSendMessage: (prompt: string, image?: string) => void;
  isLoading: boolean;
  language: string;
  darkMode: boolean;
}

export const PromptBar: React.FC<PromptBarProps> = ({ onSendMessage, isLoading, language, darkMode }) => {
  const [prompt, setPrompt] = useState('');
  const [image, setImage] = useState<string | undefined>(undefined);
  const [isListening, setIsListening] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const recognitionRef = useRef<any>(null);

  const langCodeMap = SPEECH_LANG_MAP;

  const quickChips = language === 'en' ? [
    { label: '✍️ Write Email / Letter', prompt: 'Write a formal email/letter for me.' },
    { label: '🌐 Ask Latest News', prompt: 'What are today latest news headlines?' },
    { label: '📸 Analyze Photo', prompt: 'Explain what is in this uploaded photo in detail.' },
    { label: '💡 Business Idea', prompt: 'Give me some great ideas to grow my business.' },
    { label: '🗣️ Learn English', prompt: 'Teach me 10 useful daily English sentences with Hindi/native meanings.' },
  ] : [
    { label: '✍️ ईमेल/पत्र लिखें', prompt: 'मेरे लिए एक औपचारिक पत्र या ईमेल लिखिए।' },
    { label: '🌐 ताज़ा खबर पूछें', prompt: 'आज की ताज़ा मुख्य खबरें और अपडेट बताइए।' },
    { label: '📸 फोटो समझें', prompt: 'इस फोटो में क्या है, इसे विस्तार से समझाइए।' },
    { label: '💡 नया आइडिया दें', prompt: 'मेरे छोटे बिज़नेस को आगे बढ़ाने के लिए कुछ बेहतरीन आइडिया दें।' },
    { label: '🗣️ अंग्रेज़ी सीखें', prompt: 'मुझे रोज़मर्रा में काम आने वाले 10 उपयोगी अंग्रेज़ी वाक्य अर्थ के साथ सिखाएं।' },
  ];

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = langCodeMap[language] || 'hi-IN';

      recognition.onresult = (event: any) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          transcript += event.results[i][0].transcript;
        }
        setPrompt(transcript);
      };

      recognition.onerror = (event: any) => {
        console.error('Speech error', event.error);
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    }
  }, [language]);

  const [voiceNotice, setVoiceNotice] = useState('');

  const toggleListening = () => {
    if (!recognitionRef.current) {
      setVoiceNotice(language === 'en' ? 'Voice typing is not supported in this browser.' : 'इस ब्राउज़र में वॉइस टाइपिंग उपलब्ध नहीं है।');
      setTimeout(() => setVoiceNotice(''), 4000);
      return;
    }
    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      try {
        recognitionRef.current.start();
        setIsListening(true);
      } catch (e) {
        console.error(e);
        setIsListening(false);
      }
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSend = () => {
    if ((!prompt.trim() && !image) || isLoading) return;
    onSendMessage(prompt.trim(), image);
    setPrompt('');
    setImage(undefined);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleInput = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setPrompt(e.target.value);
    e.target.style.height = 'auto';
    e.target.style.height = `${Math.min(e.target.scrollHeight, 120)}px`;
  };

  return (
    <div className={`sticky bottom-0 z-20 px-3 sm:px-6 py-3 backdrop-blur-md transition-colors ${
      darkMode ? 'bg-gray-900/90 border-t border-gray-800' : 'bg-white/90 border-t border-gray-200'
    }`}>
      <div className="max-w-3xl mx-auto">
        <div className="flex gap-2 overflow-x-auto pb-2 mb-1 no-scrollbar">
          {quickChips.map((chip, idx) => (
            <button
              key={idx}
              onClick={() => onSendMessage(chip.prompt)}
              className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all shrink-0 border shadow-2xs ${
                darkMode
                  ? 'bg-gray-800/80 border-gray-700 hover:bg-gray-700 text-gray-200'
                  : 'bg-gray-100 border-gray-200 hover:bg-indigo-50 text-gray-700 hover:text-indigo-700'
              }`}
            >
              {chip.label}
            </button>
          ))}
        </div>

        {voiceNotice && (
          <div className="mb-2 px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs">
            {voiceNotice}
          </div>
        )}

        {image && (
          <div className="mb-2 flex items-center gap-2 p-1.5 pl-3 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800 w-fit">
            <img src={image} alt="Preview" className="w-10 h-10 rounded-lg object-cover" />
            <span className="text-xs font-medium text-indigo-900 dark:text-indigo-200">Image attached</span>
            <button
              onClick={() => setImage(undefined)}
              className="p-1 rounded-full hover:bg-indigo-200 dark:hover:bg-indigo-800 text-indigo-700 dark:text-indigo-300"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        <div className={`flex items-end gap-2 p-2 rounded-2xl sm:rounded-3xl border shadow-lg transition-all ${
          darkMode
            ? 'bg-gray-800/90 border-gray-700 focus-within:border-indigo-500 shadow-black/20'
            : 'bg-white border-gray-200 focus-within:border-indigo-500 shadow-gray-200/50'
        }`}>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleImageChange}
            accept="image/*"
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className={`p-2.5 rounded-xl sm:rounded-2xl transition-colors shrink-0 ${
              darkMode ? 'hover:bg-gray-700 text-gray-300' : 'hover:bg-gray-100 text-gray-600'
            }`}
            title="Upload photo"
          >
            <Camera className="w-5 h-5" />
          </button>

          <button
            onClick={toggleListening}
            className={`p-2.5 rounded-xl sm:rounded-2xl transition-all shrink-0 ${
              isListening
                ? 'bg-red-500 text-white animate-bounce'
                : darkMode ? 'hover:bg-gray-700 text-gray-300' : 'hover:bg-gray-100 text-gray-600'
            }`}
            title={isListening ? 'Listening...' : 'Voice typing'}
          >
            {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          <textarea
            ref={textareaRef}
            rows={1}
            value={prompt}
            onChange={handleInput}
            onKeyDown={handleKeyDown}
            placeholder={isListening ? 'Listening...' : 'Ask anything or type your query...'}
            className={`flex-1 max-h-32 py-2 px-1 text-xs sm:text-sm bg-transparent outline-none resize-none ${
              darkMode ? 'text-white placeholder-gray-500' : 'text-gray-900 placeholder-gray-400'
            }`}
          />

          <button
            onClick={handleSend}
            disabled={(!prompt.trim() && !image) || isLoading}
            className={`p-2.5 sm:px-4 sm:py-2.5 rounded-xl sm:rounded-2xl flex items-center justify-center gap-1.5 font-semibold text-white transition-all shadow-md shrink-0 ${
              (!prompt.trim() && !image) || isLoading
                ? 'bg-gray-400 dark:bg-gray-700 opacity-50 cursor-not-allowed'
                : 'bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 active:scale-95 shadow-indigo-500/20'
            }`}
            title="Send"
          >
            <Send className="w-4 h-4" />
            <span className="hidden sm:inline text-xs">Send</span>
          </button>
        </div>
      </div>
    </div>
  );
};
