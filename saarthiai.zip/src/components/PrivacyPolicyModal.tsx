import React from 'react';
import { Shield, X, CheckCircle } from 'lucide-react';

interface PrivacyPolicyModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
}

export const PrivacyPolicyModal: React.FC<PrivacyPolicyModalProps> = ({ isOpen, onClose, darkMode }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
      <div className={`w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 rounded-3xl shadow-2xl border transition-all ${
        darkMode ? 'bg-gray-900 border-gray-800 text-white' : 'bg-white border-gray-200 text-gray-900'
      }`}>
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-gray-200 dark:border-gray-800">
          <div className="flex items-center gap-2.5">
            <Shield className="w-6 h-6 text-indigo-500" />
            <h2 className="font-bold text-lg">गोपनीयता नीति (Privacy Policy)</h2>
          </div>
          <button
            onClick={onClose}
            className={`p-1.5 rounded-lg transition-colors ${darkMode ? 'hover:bg-gray-800 text-gray-400' : 'hover:bg-gray-100 text-gray-600'}`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className={`space-y-4 text-xs sm:text-sm leading-relaxed ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
          <p>
            <strong>SaarthiAI - हर समस्या का हल</strong> ("हम", "हमारी") आपकी गोपनीयता का सम्मान करती है। यह गोपनीयता नीति बताती है कि हमारी वेबसाइट और मोबाइल ऐप पर आपकी जानकारी कैसे सुरक्षित रखी जाती है।
          </p>

          <h3 className="font-bold text-sm text-indigo-500">1. डेटा संग्रह (Data Collection)</h3>
          <p>
            हम आपके चैट संदेश और प्रश्न केवल आपके ब्राउज़र के <code>localStorage</code> में सुरक्षित रखते हैं। हम आपके व्यक्तिगत डेटा को किसी तीसरे पक्ष के साथ साझा नहीं करते।
          </p>

          <h3 className="font-bold text-sm text-indigo-500">2. Google AdSense & विज्ञापन</h3>
          <p>
            हम वेबसाइट पर Google AdSense विज्ञापनों का उपयोग करते हैं। Google तृतीय-पक्ष विज्ञापनदाता के रूप में विज्ञापनों को दिखाने के लिए कुकीज़ (Cookies) का उपयोग कर सकता है, जिसमें DART कुकी शामिल है, जो उपयोगकर्ताओं को हमारी साइट और इंटरनेट पर अन्य साइटों पर उनकी पिछली मुलाकातों के आधार पर विज्ञापन दिखाने में सक्षम बनाती है।
          </p>

          <h3 className="font-bold text-sm text-indigo-500">3. Google Gemini AI</h3>
          <p>
            आपके द्वारा पूछे गए प्रश्न सीधे Google Gemini AI API को भेजे जाते हैं ताकि आपको उच्च गुणवत्ता वाले उत्तर प्राप्त हो सकें।
          </p>

          <h3 className="font-bold text-sm text-indigo-500">4. संपर्क (Contact)</h3>
          <p>
            यदि इस गोपनीयता नीति के संबंध में कोई प्रश्न हों, तो आप ऐप के माध्यम से संपर्क कर सकते हैं।
          </p>

          <div className="pt-4 flex justify-end">
            <button
              onClick={onClose}
              className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-md transition-all"
            >
              बंद करें
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
