import React, { useState } from 'react';
import { Calendar, X, Volume2, VolumeX, Share2, Sparkles, HeartPulse, Newspaper, Lightbulb, PiggyBank } from 'lucide-react';

interface DailyHelperModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
}

type TabType = 'news' | 'health' | 'quote' | 'saving';

export const DailyHelperModal: React.FC<DailyHelperModalProps> = ({ isOpen, onClose, darkMode }) => {
  const [activeTab, setActiveTab] = useState<TabType>('news');
  const [isSpeaking, setIsSpeaking] = useState(false);

  if (!isOpen) return null;

  const contentMap: Record<TabType, { title: string; icon: any; text: string }> = {
    news: {
      title: 'आज की मुख्य खबरें (News Summary)',
      icon: Newspaper,
      text: 'आज की मुख्य खबरें: देश में डिजिटल गवर्नेंस और ई-governance सेवाओं का विस्तार तेजी से हो रहा है। किसानों के लिए मौसम अनुकूल कृषि सलाह और नई सरकारी योजनाओं के आवेदन शुरू हो गए हैं। टेक्नोलॉजी और शिक्षा क्षेत्र में AI आधारित टूल्स को बढ़ावा दिया जा रहा है।',
    },
    health: {
      title: 'स्वास्थ्य और डाइट टिप (Health Tip)',
      icon: HeartPulse,
      text: 'स्वास्थ्य सुझाव: सुबह खाली पेट गुनगुना पानी पीने से पाचन तंत्र मजबूत होता है। अपने भोजन में ताजे फल, हरी सब्जियां और पर्याप्त मात्रा में पानी शामिल करें। रोजाना कम से कम 30 मिनट टहलना या योग करना सेहत के लिए अत्यंत लाभदायक है।',
    },
    quote: {
      title: 'आज का सुविचार (Motivational Quote)',
      icon: Lightbulb,
      text: '"उठो, जागो और तब तक मत रुको जब तक लक्ष्य प्राप्त न हो जाए।" — स्वामी विवेकानंद। हर दिन एक नई शुरुआत है, अपनी मेहनत और लगन से अपने सपनों को साकार करें।',
    },
    saving: {
      title: 'स्मार्ट बचत सलाह (Money Saving Tip)',
      icon: PiggyBank,
      text: 'बचत सलाह: अपनी मासिक आय का कम से कम 20% हिस्सा भविष्य की सुरक्षा और आपातकालीन फंड के रूप में अलग रखें। अनावश्यक खर्चों से बचें और छोटी-छोटी बचतों को सुरक्षित योजनाओं में निवेश करें।',
    },
  };

  const currentContent = contentMap[activeTab];
  const IconC = currentContent.icon;

  const handleSpeak = () => {
    if (!('speechSynthesis' in window)) return;
    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(currentContent.text);
    utterance.lang = 'hi-IN';
    utterance.rate = 0.95;
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  const handleWhatsAppShare = () => {
    const text = `*SaarthiAI रोज़ाना मददगार - ${currentContent.title}*\n\n${currentContent.text}\n\n- SaarthiAI द्वारा साझा किया गया`;
    const encoded = encodeURIComponent(text);
    window.open(`https://api.whatsapp.com/send?text=${encoded}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
      <div className={`w-full max-w-lg max-h-[90vh] overflow-y-auto p-6 rounded-3xl shadow-2xl border transition-all ${
        darkMode ? 'bg-gray-900 border-gray-800 text-white' : 'bg-white border-gray-200 text-gray-900'
      }`}>
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-gray-200 dark:border-gray-800">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 text-white flex items-center justify-center shadow-md">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-base sm:text-lg">📅 रोज़ाना मददगार (Daily Life Helper)</h2>
              <p className="text-xs text-gray-400">समाचार, स्वास्थ्य सुझाव, सुविचार और बचत सलाह</p>
            </div>
          </div>
          <button
            onClick={() => {
              if (isSpeaking) window.speechSynthesis.cancel();
              onClose();
            }}
            className={`p-1.5 rounded-lg transition-colors ${darkMode ? 'hover:bg-gray-800 text-gray-400' : 'hover:bg-gray-100 text-gray-600'}`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4 text-xs sm:text-sm">
          {/* Tabs */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {[
              { id: 'news', label: 'मुख्य खबरें', icon: Newspaper },
              { id: 'health', label: 'स्वास्थ्य टिप', icon: HeartPulse },
              { id: 'quote', label: 'आज का सुविचार', icon: Lightbulb },
              { id: 'saving', label: 'बचत सलाह', icon: PiggyBank },
            ].map(tab => {
              const TabIcon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    if (isSpeaking) window.speechSynthesis.cancel();
                    setIsSpeaking(false);
                    setActiveTab(tab.id as TabType);
                  }}
                  className={`flex flex-col items-center gap-1 p-2.5 rounded-xl border text-[11px] font-semibold transition-all ${
                    activeTab === tab.id
                      ? 'bg-cyan-600 border-cyan-600 text-white shadow-md'
                      : darkMode ? 'bg-gray-800 border-gray-700 text-gray-300' : 'bg-white border-gray-200 text-gray-700'
                  }`}
                >
                  <TabIcon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Content Card */}
          <div className={`p-5 rounded-2xl border space-y-3 ${darkMode ? 'bg-gray-800/80 border-gray-700' : 'bg-cyan-50/50 border-cyan-200'}`}>
            <div className="flex items-center gap-2">
              <IconC className="w-5 h-5 text-cyan-500" />
              <h3 className="font-bold text-sm">{currentContent.title}</h3>
            </div>
            <p className="text-xs sm:text-sm leading-relaxed opacity-90">
              {currentContent.text}
            </p>
          </div>

          <div className="pt-2 flex items-center justify-between">
            <button
              onClick={handleSpeak}
              className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl border font-semibold text-xs transition-all ${
                isSpeaking
                  ? 'bg-red-500 text-white border-red-600'
                  : darkMode ? 'bg-gray-800 border-gray-700 text-cyan-300 hover:bg-gray-700' : 'bg-cyan-50 border-cyan-200 text-cyan-800 hover:bg-cyan-100'
              }`}
            >
              {isSpeaking ? <VolumeX className="w-4 h-4 animate-pulse" /> : <Volume2 className="w-4 h-4 text-cyan-500" />}
              <span>{isSpeaking ? 'बोलना बंद करें' : '🔊 हिंदी में सुनें'}</span>
            </button>

            <div className="flex gap-2">
              <button
                onClick={handleWhatsAppShare}
                className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs shadow-md flex items-center gap-1.5 transition-all"
              >
                <Share2 className="w-4 h-4" />
                <span>WhatsApp</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
