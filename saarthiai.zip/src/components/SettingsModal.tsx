import React, { useState, useEffect } from 'react';
import { Settings, X, ShieldCheck, Globe, MapPin, Smartphone } from 'lucide-react';
import {
  SUPPORTED_LANGUAGES,
  INDIA_REGIONS,
  GLOBAL_REGIONS,
  findRegionOption,
  RegionScope,
} from '../lib/regions';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: string;
  onLanguageChange: (lang: string) => void;
  location: string;
  onLocationChange: (loc: string) => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  onOpenApkGuide: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  language,
  onLanguageChange,
  location,
  onLocationChange,
  darkMode,
  onToggleDarkMode,
  onOpenApkGuide,
}) => {
  const activeRegion = findRegionOption(location);
  const [scope, setScope] = useState<RegionScope>(activeRegion.scope);

  useEffect(() => {
    setScope(activeRegion.scope);
  }, [activeRegion.scope]);

  if (!isOpen) return null;

  const currentList = scope === 'india' ? INDIA_REGIONS : GLOBAL_REGIONS;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
      <div
        className={`w-full max-w-md max-h-[92dvh] overflow-y-auto p-6 rounded-3xl shadow-2xl border transition-all ${
          darkMode ? 'bg-gray-900 border-gray-800 text-white' : 'bg-white border-gray-200 text-gray-900'
        }`}
      >
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-gray-200 dark:border-gray-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-600/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <Settings className="w-5 h-5" />
            </div>
            <h2 className="font-bold text-base">ऐप सेटिंग्स (Global Settings)</h2>
          </div>
          <button
            onClick={onClose}
            className={`p-1.5 rounded-lg transition-colors ${
              darkMode ? 'hover:bg-gray-800 text-gray-400' : 'hover:bg-gray-100 text-gray-600'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4 text-xs sm:text-sm">
          {/* Language Selector */}
          <div>
            <label className="font-semibold mb-1.5 flex items-center gap-1.5">
              <Globe className="w-4 h-4 text-indigo-500" />
              <span>भाषा चुनें (Language — Auto Reply)</span>
            </label>
            <select
              value={language}
              onChange={(e) => onLanguageChange(e.target.value)}
              className={`w-full px-3.5 py-2.5 rounded-xl border outline-none text-xs cursor-pointer ${
                darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
              }`}
            >
              {SUPPORTED_LANGUAGES.map((l) => (
                <option
                  key={l.code}
                  value={l.code}
                  className="bg-white dark:bg-gray-900 text-gray-900 dark:text-white"
                >
                  {l.label}
                </option>
              ))}
            </select>
          </div>

          {/* Two-Tier Region / Location Selector */}
          <div>
            <label className="font-semibold mb-1.5 flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-emerald-500" />
              <span>क्षेत्र चुनें (🇮🇳 India States / 🌐 Global Countries)</span>
            </label>

            <div className="grid grid-cols-2 gap-1.5 p-1 rounded-xl bg-gray-100 dark:bg-gray-800 mb-2">
              <button
                type="button"
                onClick={() => {
                  setScope('india');
                  if (activeRegion.scope !== 'india') {
                    onLocationChange(INDIA_REGIONS[0].value);
                  }
                }}
                className={`py-1.5 rounded-lg text-xs font-bold transition-all ${
                  scope === 'india' ? 'bg-emerald-600 text-white shadow-xs' : 'text-gray-600 dark:text-gray-300'
                }`}
              >
                🇮🇳 India (All States)
              </button>
              <button
                type="button"
                onClick={() => {
                  setScope('global');
                  if (activeRegion.scope !== 'global') {
                    onLocationChange(GLOBAL_REGIONS[0].value);
                  }
                }}
                className={`py-1.5 rounded-lg text-xs font-bold transition-all ${
                  scope === 'global' ? 'bg-indigo-600 text-white shadow-xs' : 'text-gray-600 dark:text-gray-300'
                }`}
              >
                🌐 Global / World
              </button>
            </div>

            <select
              value={activeRegion.scope === scope ? activeRegion.value : currentList[0].value}
              onChange={(e) => onLocationChange(e.target.value)}
              className={`w-full px-3.5 py-2.5 rounded-xl border outline-none text-xs cursor-pointer ${
                darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
              }`}
            >
              {currentList.map((reg) => (
                <option
                  key={reg.value}
                  value={reg.value}
                  className="bg-white dark:bg-gray-900 text-gray-900 dark:text-white"
                >
                  {reg.label} ({reg.domainHint})
                </option>
              ))}
            </select>
          </div>

          {/* Theme Toggle */}
          <div className="flex items-center justify-between p-3 rounded-2xl border border-gray-200 dark:border-gray-800">
            <span className="font-semibold">डार्क मोड (Dark Theme)</span>
            <button
              onClick={onToggleDarkMode}
              className={`px-4 py-1.5 rounded-xl font-semibold text-xs transition-all ${
                darkMode ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-800'
              }`}
            >
              {darkMode ? 'चालू (On)' : 'बंद (Off)'}
            </button>
          </div>

          {/* APK Guide Trigger */}
          <button
            onClick={() => {
              onClose();
              onOpenApkGuide();
            }}
            className="w-full flex items-center justify-center gap-2 p-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-bold text-xs shadow-md hover:from-emerald-700 hover:to-teal-700 transition-all"
          >
            <Smartphone className="w-4 h-4" />
            <span>Android APK &amp; PWA गाइड देखें</span>
          </button>

          <div
            className={`p-3 rounded-xl border text-[11px] flex items-start gap-2 ${
              darkMode
                ? 'bg-emerald-950/30 border-emerald-900/50 text-emerald-300'
                : 'bg-emerald-50 border-emerald-100 text-emerald-900'
            }`}
          >
            <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-500 mt-0.5" />
            <div>
              <strong>SaarthiAI Global:</strong> चुने हुए देश या राज्य के केवल आधिकारिक सरकारी व यूनिवर्सिटी पोर्टल्स से लाइव डेटा लाता है।
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              onClick={onClose}
              className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-md transition-all"
            >
              सहेजें और बंद करें
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
