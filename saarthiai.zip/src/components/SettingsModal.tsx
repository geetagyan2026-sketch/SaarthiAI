import React, { useState } from 'react';
import { Settings, X, Key, Check, ShieldCheck } from 'lucide-react';
import { getApiKey } from '../lib/geminiService';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, darkMode }) => {
  const [apiKeyInput, setApiKeyInput] = useState(() => getApiKey());
  const [saved, setSaved] = useState(false);

  if (!isOpen) return null;

  const handleSave = () => {
    localStorage.setItem('saarthi_api_key', apiKeyInput.trim());
    setSaved(true);
    setTimeout(() => {
      setSaved(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className={`w-full max-w-md p-6 rounded-3xl shadow-2xl border transition-all ${
        darkMode ? 'bg-gray-900 border-gray-800 text-white' : 'bg-white border-gray-200 text-gray-900'
      }`}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-600/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <Settings className="w-5 h-5" />
            </div>
            <h2 className="font-bold text-lg">ऐप सेटिंग्स & API Key</h2>
          </div>
          <button
            onClick={onClose}
            className={`p-1.5 rounded-lg transition-colors ${darkMode ? 'hover:bg-gray-800 text-gray-400' : 'hover:bg-gray-100 text-gray-600'}`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className={`text-xs mb-4 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
          SaarthiAI में встроенный (Built-in) और सुरक्षित Gemini API key इस्तेमाल होती है। यदि आप अपनी खुद की API Key दर्ज करना चाहें, तो नीचे बदल सकते हैं।
        </p>

        <div className="space-y-4">
          <div>
            <label className="block text-xs font-semibold mb-1.5 flex items-center gap-1.5">
              <Key className="w-3.5 h-3.5 text-indigo-500" />
              <span>Gemini API Key</span>
            </label>
            <input
              type="password"
              value={apiKeyInput}
              onChange={(e) => setApiKeyInput(e.target.value)}
              placeholder="AIzaSy..."
              className={`w-full px-3.5 py-2.5 rounded-xl text-xs outline-none border transition-colors ${
                darkMode ? 'bg-gray-800 border-gray-700 text-white focus:border-indigo-500' : 'bg-gray-50 border-gray-200 text-gray-900 focus:border-indigo-500'
              }`}
            />
          </div>

          <div className={`p-3 rounded-xl border text-xs flex items-start gap-2.5 ${
            darkMode ? 'bg-indigo-950/30 border-indigo-900/50 text-indigo-300' : 'bg-indigo-50/70 border-indigo-100 text-indigo-900'
          }`}>
            <ShieldCheck className="w-4 h-4 shrink-0 text-indigo-500 mt-0.5" />
            <div>
              <span className="font-semibold">सुरक्षा की गारंटी:</span> आपकी API Key आपके ब्राउज़र के LocalStorage में सुरक्षित रहती है और सीधे Google Gemini से बात करती है।
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              onClick={onClose}
              className={`px-4 py-2 rounded-xl text-xs font-medium transition-colors ${
                darkMode ? 'hover:bg-gray-800 text-gray-300' : 'hover:bg-gray-100 text-gray-700'
              }`}
            >
              रद्द करें
            </button>
            <button
              onClick={handleSave}
              className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shadow-md flex items-center gap-1.5 transition-all"
            >
              {saved ? <Check className="w-4 h-4" /> : null}
              <span>{saved ? 'सेव हो गया!' : 'सेव करें'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
