import React, { useState } from 'react';
import { ChatSession } from '../types';
import { History, Trash2, MessageSquare, Plus, X, Smartphone, Globe, Download, Share2, HelpCircle } from 'lucide-react';

interface SidebarHistoryProps {
  isOpen: boolean;
  onClose: () => void;
  sessions: ChatSession[];
  currentSessionId: string;
  onSelectSession: (id: string) => void;
  onDeleteSession: (id: string, e: React.MouseEvent) => void;
  onNewChat: () => void;
  darkMode: boolean;
  onOpenApkGuide: () => void;
}

export const SidebarHistory: React.FC<SidebarHistoryProps> = ({
  isOpen,
  onClose,
  sessions,
  currentSessionId,
  onSelectSession,
  onDeleteSession,
  onNewChat,
  darkMode,
  onOpenApkGuide,
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredSessions = sessions.filter(s =>
    s.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.messages.some(m => m.content.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 z-40 bg-black/50 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Drawer */}
      <aside className={`fixed top-0 left-0 bottom-0 z-50 w-80 sm:w-88 flex flex-col shadow-2xl transition-transform duration-300 ${
        darkMode ? 'bg-gray-900 border-r border-gray-800 text-white' : 'bg-white border-r border-gray-200 text-gray-800'
      }`}>
        {/* Header */}
        <div className={`flex items-center justify-between p-4 border-b ${darkMode ? 'border-gray-800' : 'border-gray-200'}`}>
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-indigo-500" />
            <h2 className="font-bold text-base">चैट इतिहास (History)</h2>
          </div>
          <button
            onClick={onClose}
            className={`p-1.5 rounded-lg transition-colors ${darkMode ? 'hover:bg-gray-800 text-gray-400' : 'hover:bg-gray-100 text-gray-600'}`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Button */}
        <div className="p-3">
          <button
            onClick={() => {
              onNewChat();
              onClose();
            }}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-sm shadow-sm transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>नया चैट शुरू करें</span>
          </button>
        </div>

        {/* Search */}
        <div className="px-3 pb-2">
          <input
            type="text"
            placeholder="पुराने चैट खोजें..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className={`w-full px-3 py-2 rounded-xl text-xs outline-none border transition-colors ${
              darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500 focus:border-indigo-500' : 'bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-400 focus:border-indigo-500'
            }`}
          />
        </div>

        {/* Session List */}
        <div className="flex-1 overflow-y-auto px-3 py-2 space-y-1.5 custom-scrollbar">
          {filteredSessions.length === 0 ? (
            <div className="text-center py-8 text-xs text-gray-400">
              कोई पुराना चैट नहीं मिला
            </div>
          ) : (
            filteredSessions.map((session) => {
              const isActive = session.id === currentSessionId;
              return (
                <div
                  key={session.id}
                  onClick={() => {
                    onSelectSession(session.id);
                    onClose();
                  }}
                  className={`group flex items-center justify-between p-3 rounded-xl cursor-pointer text-xs transition-all ${
                    isActive
                      ? darkMode ? 'bg-indigo-950/60 border border-indigo-800/60 text-indigo-200' : 'bg-indigo-50 border border-indigo-100 text-indigo-900 font-medium'
                      : darkMode ? 'hover:bg-gray-800 text-gray-300' : 'hover:bg-gray-100 text-gray-700'
                  }`}
                >
                  <div className="flex items-center gap-2.5 overflow-hidden">
                    <MessageSquare className={`w-4 h-4 shrink-0 ${isActive ? 'text-indigo-500' : 'text-gray-400'}`} />
                    <span className="truncate">{session.title || 'नई बातचीत'}</span>
                  </div>
                  <button
                    onClick={(e) => onDeleteSession(session.id, e)}
                    className={`opacity-0 group-hover:opacity-100 p-1 rounded transition-opacity ${
                      darkMode ? 'hover:bg-gray-700 text-red-400' : 'hover:bg-gray-200 text-red-600'
                    }`}
                    title="चैट डिलीट करें"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })
          )}
        </div>

        {/* Footer APK / PWA info */}
        <div className={`p-4 border-t ${darkMode ? 'border-gray-800 bg-gray-950/50' : 'border-gray-200 bg-gray-50'}`}>
          <button
            onClick={() => {
              onOpenApkGuide();
              onClose();
            }}
            className="w-full flex items-center justify-between p-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-medium text-xs shadow-md hover:from-emerald-700 hover:to-teal-700 transition-all"
          >
            <div className="flex items-center gap-2">
              <Smartphone className="w-4 h-4" />
              <span>Android APK & PWA गाइड</span>
            </div>
            <Download className="w-4 h-4" />
          </button>
          <div className="mt-3 text-center text-[10px] text-gray-400">
            SaarthiAI v2.4 • Powered by Gemini 3.1 Flash Lite
          </div>
        </div>
      </aside>
    </>
  );
};
