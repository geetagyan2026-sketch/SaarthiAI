import React from 'react';
import {
  Wrench,
  X,
  FileText,
  Camera,
  Sprout,
  BookOpen,
  Smartphone,
  Calculator,
  MessageSquare,
  Pill,
  Receipt,
  GraduationCap,
  Mail,
  Sun,
  Calendar,
  Briefcase,
  Landmark,
} from 'lucide-react';

import { findRegionOption } from '../lib/regions';
import { RegionCardCategory } from '../lib/regionCardGuides';

interface ToolsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenResumeModal: () => void;
  onOpenPhotoStudioModal: () => void;
  onOpenInvitationModal: () => void;
  onOpenPanchangModal: () => void;
  onOpenDailyHelperModal: () => void;
  onSelectSuggestion: (prompt: string) => void;
  onSelectRegionCard?: (category: RegionCardCategory) => void;
  location?: string;
  darkMode: boolean;
}

export const ToolsDrawer: React.FC<ToolsDrawerProps> = ({
  isOpen,
  onClose,
  onOpenResumeModal,
  onOpenPhotoStudioModal,
  onOpenInvitationModal,
  onOpenPanchangModal,
  onOpenDailyHelperModal,
  onSelectSuggestion,
  onSelectRegionCard,
  location = '🌍 Global / World',
  darkMode,
}) => {
  if (!isOpen) return null;
  const activeRegion = findRegionOption(location);

  const toolsList = [
    {
      title: '🏛️ सरकारी नौकरी / भर्ती अलर्ट',
      desc: `${activeRegion.shortName} की ताज़ा भर्तियों की योग्यता, तारीख, फीस और आवेदन विधि`,
      prompt: `${activeRegion.shortName} की ताज़ा सरकारी नौकरी भर्तियों (2026) की योग्यता, अंतिम तारीख, फीस और आवेदन प्रक्रिया बताइए।`,
      icon: Briefcase,
      color: 'from-purple-500 to-indigo-700',
      action: 'region_jobs',
    },
    {
      title: '🎓 स्कूल / कॉलेज एडमिशन',
      desc: `${activeRegion.shortName} एडमिशन डेट, छात्रवृत्ति व परीक्षा फॉर्म जानकारी`,
      prompt: `${activeRegion.shortName} स्कूल और कॉलेज एडमिशन 2026 की प्रवेश प्रक्रिया, जरूरी दस्तावेज़ व छात्रवृत्ति आवेदन कैसे करें, बताइए।`,
      icon: GraduationCap,
      color: 'from-indigo-500 to-blue-600',
      action: 'region_admission',
    },
    {
      title: '🖥️ ई-मित्र और डिजिटल सेवाएं',
      desc: `${activeRegion.shortName} (${activeRegion.citizenGuide?.portalDomain || activeRegion.domainHint}) — जाति, निवास, आय व डिजिटल सेवाएं`,
      prompt: `${activeRegion.shortName} डिजिटल नागरिक पोर्टल (${activeRegion.citizenGuide?.portalDomain || activeRegion.domainHint}) पर जाति, मूल निवास, आय प्रमाण पत्र बनवाने की पात्रता, फीस और आवेदन प्रक्रिया बताइए।`,
      icon: Landmark,
      color: 'from-emerald-500 to-teal-700',
      action: 'region_citizen',
    },
    {
      title: '💊 दवाई की जानकारी',
      desc: 'दवाई का नाम लिखें या पर्चे की फोटो अपलोड करके उपयोग व सावधानियां जानें',
      prompt: 'इस फोटो में दी गई दवाई का नाम, उपयोग, साल्ट और सावधानियां आसान हिंदी में बताइए।',
      icon: Pill,
      color: 'from-rose-500 to-red-600',
      action: 'chat',
    },
    {
      title: '🧾 बिल और रसीद रीडर',
      desc: 'बिजली बिल, राशन पर्ची या अस्पताल के बिल की फोटो समझें',
      prompt: 'इस बिल या रसीद की फोटो में कुल राशि, अंतिम तिथि और छुपे हुए चार्जेस की जांच करके बताइए।',
      icon: Receipt,
      color: 'from-amber-600 to-yellow-600',
      action: 'chat',
    },
    {
      title: '📚 स्कूल होमवर्क और प्रश्न हल',
      desc: 'किताब के सवाल की फोटो खींचें और आसान हल पाएं',
      prompt: 'इस फोटो में दिए गए सवाल को स्टेप-बाय-स्टेप सरल हिंदी में हल करके समझाइए।',
      icon: BookOpen,
      color: 'from-violet-500 to-purple-700',
      action: 'chat',
    },
    {
      title: '🌾 सरकारी योजना और खेती सलाह',
      desc: `${activeRegion.shortName} योजनाएं, PM Kisan, आयुष्मान कार्ड, खाद और फसल बीमा`,
      prompt: `${activeRegion.shortName} की प्रमुख सरकारी योजनाओं व प्रधानमंत्री किसान सम्मान निधि योजना की पात्रता व आवेदन प्रक्रिया बताइए।`,
      icon: Sprout,
      color: 'from-green-500 to-emerald-700',
      action: 'region_schemes',
    },
    {
      title: '📝 सरकारी और बैंक एप्लीकेशन',
      desc: 'बैंक खाता, बिजली बिल, छुट्टी या आरटीआई पत्र',
      prompt: 'बैंक में खाता बंद करवाने या आधार कार्ड सुधार के लिए एक औपचारिक प्रार्थना पत्र लिखिए।',
      icon: MessageSquare,
      color: 'from-purple-500 to-indigo-600',
      action: 'chat',
    },
    {
      title: '📱 Reels स्क्रिप्ट और WhatsApp स्टेटस',
      desc: 'इंस्टाग्राम रील्स स्क्रिप्ट, दुकान के ऑफर मैसेज',
      prompt: 'मेरी दुकान की सेल के लिए एक आकर्षक WhatsApp स्टेटस और Instagram Reels स्क्रिप्ट लिखिए।',
      icon: Smartphone,
      color: 'from-pink-600 to-purple-600',
      action: 'chat',
    },
    {
      title: '💰 ब्याज, EMI और बिज़नेस हिसाब',
      desc: 'साधारण/चक्रवृद्धि ब्याज, लोन EMI कैलकुलेशन',
      prompt: '₹50,000 का 2% मासिक ब्याज की दर से 8 महीने का कुल ब्याज और कुल राशि कितनी होगी, समझाइए।',
      icon: Calculator,
      color: 'from-cyan-600 to-teal-600',
      action: 'chat',
    },
    {
      title: '📄 1-सेकंड रिज्यूमे / बायोडाटा',
      desc: 'तुरंत प्रोफेशनल A4 रिज्यूमे बनाएं और PDF डाउनलोड करें',
      prompt: '',
      icon: FileText,
      color: 'from-blue-500 to-indigo-600',
      action: 'resume',
    },
    {
      title: '📸 ग्लोबल फोटो व साइन रिसाइज़र',
      desc: 'पासपोर्ट, वीज़ा फोटो, इंडियन फॉर्म KB साइज व A4 प्रिंट शीट बनाएं',
      prompt: '',
      icon: Camera,
      color: 'from-orange-500 to-amber-600',
      action: 'photo',
    },
    {
      title: '💌 निमंत्रण और बधाई कार्ड मेकर',
      desc: 'शादी, जन्मदिन या दुकान उद्घाटन का व्हाट्सएप कार्ड बनाएं',
      prompt: '',
      icon: Mail,
      color: 'from-pink-500 to-rose-600',
      action: 'invitation',
    },
    {
      title: '🕉️ आज का पंचांग और शुभ मुहूर्त',
      desc: 'आज का चौघड़िया, राहुकाल और शुभ समय जानें',
      prompt: '',
      icon: Sun,
      color: 'from-amber-500 to-orange-600',
      action: 'panchang',
    },
    {
      title: '📅 रोज़ाना मददगार',
      desc: 'आज की मुख्य खबरें, स्वास्थ्य टिप, सुविचार और बचत सलाह',
      prompt: '',
      icon: Calendar,
      color: 'from-cyan-500 to-blue-600',
      action: 'daily',
    },
  ];

  return (
    <>
      <div className="fixed inset-0 z-40 bg-black/50 backdrop-blur-xs" onClick={onClose} />
      <div
        className={`fixed top-0 right-0 bottom-0 z-50 w-80 sm:w-96 flex flex-col shadow-2xl transition-transform duration-300 ${
          darkMode ? 'bg-gray-900 border-l border-gray-800 text-white' : 'bg-white border-l border-gray-200 text-gray-800'
        }`}
      >
        <div className={`flex items-center justify-between p-4 border-b ${darkMode ? 'border-gray-800' : 'border-gray-200'}`}>
          <div className="flex items-center gap-2">
            <Wrench className="w-5 h-5 text-indigo-500" />
            <h2 className="font-bold text-base">🛠️ सभी टूल्स (15 फीचर्स)</h2>
          </div>
          <button
            onClick={onClose}
            className={`p-1.5 rounded-lg ${darkMode ? 'hover:bg-gray-800 text-gray-400' : 'hover:bg-gray-100 text-gray-600'}`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-3 space-y-2.5 custom-scrollbar">
          {toolsList.map((tool, idx) => {
            const IconComp = tool.icon;
            return (
              <button
                key={idx}
                onClick={() => {
                  onClose();
                  if (tool.action === 'resume') onOpenResumeModal();
                  else if (tool.action === 'photo') onOpenPhotoStudioModal();
                  else if (tool.action === 'invitation') onOpenInvitationModal();
                  else if (tool.action === 'panchang') onOpenPanchangModal();
                  else if (tool.action === 'daily') onOpenDailyHelperModal();
                  else if (tool.action === 'region_citizen' && onSelectRegionCard) onSelectRegionCard('citizen');
                  else if (tool.action === 'region_jobs' && onSelectRegionCard) onSelectRegionCard('jobs');
                  else if (tool.action === 'region_schemes' && onSelectRegionCard) onSelectRegionCard('schemes');
                  else if (tool.action === 'region_admission' && onSelectRegionCard) onSelectRegionCard('admission');
                  else onSelectSuggestion(tool.prompt);
                }}
                className={`w-full flex items-start gap-3 p-3 rounded-2xl border text-left transition-all ${
                  darkMode
                    ? 'bg-gray-800/60 border-gray-700 hover:bg-gray-800 hover:border-indigo-500 text-gray-200'
                    : 'bg-gray-50 border-gray-200 hover:bg-indigo-50/50 hover:border-indigo-300 text-gray-800'
                }`}
              >
                <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${tool.color} flex items-center justify-center text-white shrink-0 shadow-sm mt-0.5`}>
                  <IconComp className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-xs leading-tight mb-1">{tool.title}</h3>
                  <p className="text-[10px] text-gray-400 leading-tight line-clamp-2">{tool.desc}</p>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </>
  );
};
