export const SearchResultCards = () => null;
