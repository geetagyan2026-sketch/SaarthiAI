import React, { useState, useRef } from 'react';
import { Mail, X, Download, Share2, Heart, Gift, Home, ShoppingBag } from 'lucide-react';

interface InvitationModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
}

type OccasionType = 'wedding' | 'birthday' | 'grihapravesh' | 'shop';

export const InvitationModal: React.FC<InvitationModalProps> = ({ isOpen, onClose, darkMode }) => {
  const [occasion, setOccasion] = useState<OccasionType>('wedding');
  const [title, setTitle] = useState('शुभ विवाह निमंत्रण');
  const [hostName, setHostName] = useState('श्री रमेश कुमार एवं परिवार');
  const [guestName, setGuestName] = useState('प्रिय मित्र / सपरिवार');
  const [date, setDate] = useState('25 नवंबर 2026');
  const [time, setTime] = useState('शाम 07:00 बजे');
  const [venue, setVenue] = useState('मैरिज पैलेस, मुख्य मार्ग, नई दिल्ली');
  const [downloadedMsg, setDownloadedMsg] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  if (!isOpen) return null;

  const handleOccasionChange = (occ: OccasionType) => {
    setOccasion(occ);
    if (occ === 'wedding') {
      setTitle('शुभ विवाह निमंत्रण');
      setHostName('श्री रमेश कुमार एवं परिवार');
    } else if (occ === 'birthday') {
      setTitle('जन्मदिन की हार्दिक शुभकामनाएं / पार्टी');
      setHostName('राहुल का जन्मदिन');
    } else if (occ === 'grihapravesh') {
      setTitle('गृह प्रवेश एवं सत्यनारायण कथा');
      setHostName('श्री सुनील वर्मा');
    } else if (occ === 'shop') {
      setTitle('नयी दुकान / प्रतिष्ठान उद्घाटन');
      setHostName('बालाजी ट्रेडर्स');
    }
  };

  const handleDownload = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 900;
    canvas.height = 600;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const grad = ctx.createLinearGradient(0, 0, 900, 600);
    grad.addColorStop(0, '#f59e0b');
    grad.addColorStop(0.5, '#e11d48');
    grad.addColorStop(1, '#312e81');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 900, 600);

    ctx.strokeStyle = '#fcd34d';
    ctx.lineWidth = 12;
    ctx.strokeRect(20, 20, 860, 560);

    ctx.textAlign = 'center';
    ctx.fillStyle = '#fde68a';
    ctx.font = 'bold 22px sans-serif';
    ctx.fillText('✨ सादर आमंत्रण ✨', 450, 85);

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 42px sans-serif';
    ctx.fillText(title, 450, 155);

    ctx.fillStyle = '#fef3c7';
    ctx.font = '24px sans-serif';
    ctx.fillText(`आमंत्रित: ${guestName}`, 450, 215);
    ctx.fillText(`आयोजक: ${hostName}`, 450, 255);

    ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
    ctx.fillRect(90, 295, 720, 165);

    ctx.fillStyle = '#ffffff';
    ctx.font = '24px sans-serif';
    ctx.fillText(`दिनांक: ${date}   |   समय: ${time}`, 450, 355);
    ctx.fillText(`स्थान: ${venue}`, 450, 415);

    ctx.fillStyle = '#fde68a';
    ctx.font = '18px sans-serif';
    ctx.fillText('आपकी उपस्थिति हमारे लिए अत्यंत हर्ष का विषय है! — SaarthiAI', 450, 525);

    const link = document.createElement('a');
    link.download = `SaarthiAI_Invitation_${Date.now()}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();

    setDownloadedMsg(true);
    setTimeout(() => setDownloadedMsg(false), 3000);
  };

  const handleWhatsAppShare = () => {
    const text = `*${title}* 🪔\n\nप्रिय ${guestName},\nआयोजक: ${hostName}\nदिनांक: ${date}\nसमय: ${time}\nस्थान: ${venue}\n\nआप सादर आमंत्रित हैं!\n- SaarthiAI द्वारा निर्मित`;
    const encoded = encodeURIComponent(text);
    window.open(`https://api.whatsapp.com/send?text=${encoded}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
      <div className={`w-full max-w-xl max-h-[95vh] overflow-y-auto p-6 rounded-3xl shadow-2xl border transition-all ${
        darkMode ? 'bg-gray-900 border-gray-800 text-white' : 'bg-white border-gray-200 text-gray-900'
      }`}>
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-gray-200 dark:border-gray-800">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-pink-500 to-rose-600 text-white flex items-center justify-center shadow-md">
              <Mail className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-base sm:text-lg">💌 निमंत्रण और बधाई कार्ड मेकर</h2>
              <p className="text-xs text-gray-400">शादी, जन्मदिन या उद्घाटन का व्हाट्सएप कार्ड बनाएं</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className={`p-1.5 rounded-lg transition-colors ${darkMode ? 'hover:bg-gray-800 text-gray-400' : 'hover:bg-gray-100 text-gray-600'}`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4 text-xs sm:text-sm">
          <div>
            <label className="block font-semibold mb-2">अवसर चुनें (Occasion):</label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: 'wedding', label: 'शादी विवाह', icon: Heart },
                { id: 'birthday', label: 'जन्मदिन', icon: Gift },
                { id: 'grihapravesh', label: 'गृह प्रवेश', icon: Home },
                { id: 'shop', label: 'दुकान उद्घाटन', icon: ShoppingBag },
              ].map(item => {
                const IconComponent = item.icon;
                return (
                  <button
                    type="button"
                    key={item.id}
                    onClick={() => handleOccasionChange(item.id as OccasionType)}
                    className={`flex items-center justify-center gap-1.5 p-2.5 rounded-xl border text-xs font-semibold transition-all ${
                      occasion === item.id
                        ? 'bg-rose-600 border-rose-600 text-white shadow-md'
                        : darkMode ? 'bg-gray-800 border-gray-700 text-gray-300' : 'bg-white border-gray-200 text-gray-700'
                    }`}
                  >
                    <IconComponent className="w-4 h-4" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1">शीर्षक (Card Title)</label>
              <input
                type="text"
                value={title}
                onChange={e => setTitle(e.target.value)}
                className={`w-full px-3.5 py-2.5 rounded-xl border outline-none ${
                  darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
                }`}
              />
            </div>
            <div>
              <label className="block font-semibold mb-1">आयोजक / नाम (Host/Name)</label>
              <input
                type="text"
                value={hostName}
                onChange={e => setHostName(e.target.value)}
                className={`w-full px-3.5 py-2.5 rounded-xl border outline-none ${
                  darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
                }`}
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold mb-1">अतिथि का नाम (Guest Name)</label>
            <input
              type="text"
              value={guestName}
              onChange={e => setGuestName(e.target.value)}
              className={`w-full px-3.5 py-2.5 rounded-xl border outline-none ${
                darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
              }`}
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1">दिनांक (Date)</label>
              <input
                type="text"
                value={date}
                onChange={e => setDate(e.target.value)}
                className={`w-full px-3.5 py-2.5 rounded-xl border outline-none ${
                  darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
                }`}
              />
            </div>
            <div>
              <label className="block font-semibold mb-1">समय (Time)</label>
              <input
                type="text"
                value={time}
                onChange={e => setTime(e.target.value)}
                className={`w-full px-3.5 py-2.5 rounded-xl border outline-none ${
                  darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
                }`}
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold mb-1">स्थान / पता (Venue)</label>
            <input
              type="text"
              value={venue}
              onChange={e => setVenue(e.target.value)}
              className={`w-full px-3.5 py-2.5 rounded-xl border outline-none ${
                darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
              }`}
            />
          </div>

          <div ref={cardRef} className="p-6 rounded-3xl bg-gradient-to-br from-amber-500 via-rose-600 to-indigo-900 text-white text-center shadow-xl border-4 border-amber-300 relative overflow-hidden">
            <div className="absolute top-2 left-2 text-amber-200 text-lg">🪔</div>
            <div className="absolute top-2 right-2 text-amber-200 text-lg">🌸</div>
            <p className="text-[11px] uppercase tracking-widest text-amber-200 font-bold mb-1">✨ सादर आमंत्रण ✨</p>
            <h3 className="font-extrabold text-xl sm:text-2xl mb-1 drop-shadow-md">{title}</h3>
            <p className="text-xs mb-1 text-amber-100">आमंत्रित: {guestName}</p>
            <p className="text-xs mb-3 opacity-90">विशेष उपस्थिति / आयोजक: {hostName}</p>
            <div className="bg-black/30 backdrop-blur-xs p-3 rounded-2xl mb-3 text-xs space-y-1">
              <div>🗓️ <strong>दिनांक:</strong> {date} | ⏰ <strong>समय:</strong> {time}</div>
              <div>📍 <strong>स्थान:</strong> {venue}</div>
            </div>
            <p className="text-[10px] text-amber-200">आपकी उपस्थिति हमारे लिए अत्यंत हर्ष का विषय है!</p>
          </div>

          {downloadedMsg && (
            <p className="text-xs text-emerald-400 text-center font-medium">
              ✅ निमंत्रण कार्ड PNG के रूप में डाउनलोड हो गया!
            </p>
          )}

          <div className="pt-2 flex items-center justify-between flex-wrap gap-2">
            <button
              type="button"
              onClick={onClose}
              className={`px-4 py-2.5 rounded-xl text-xs font-medium transition-colors ${
                darkMode ? 'hover:bg-gray-800 text-gray-400' : 'hover:bg-gray-100 text-gray-600'
              }`}
            >
              रद्द करें
            </button>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={handleDownload}
                className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md flex items-center gap-1.5 transition-all"
              >
                <Download className="w-4 h-4" />
                <span>HD डाउनलोड</span>
              </button>
              <button
                type="button"
                onClick={handleWhatsAppShare}
                className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md flex items-center gap-1.5 transition-all"
              >
                <Share2 className="w-4 h-4" />
                <span>WhatsApp पर भेजें</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
