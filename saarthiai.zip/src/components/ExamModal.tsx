import React, { useState } from 'react';
import { GraduationCap, X, Sparkles, Volume2, VolumeX, CheckCircle, FileText, Search } from 'lucide-react';
import { generateSaarthiResponse } from '../lib/geminiService';

interface ExamModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
}

export const ExamModal: React.FC<ExamModalProps> = ({ isOpen, onClose, darkMode }) => {
  const [category, setCategory] = useState('UPSC / SSC');
  const [examName, setExamName] = useState('UPSC Civil Services (IAS/IPS)');
  const [resultText, setResultText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  if (!isOpen) return null;

  const handleFetchExamInfo = async () => {
    setIsLoading(true);
    const prompt = `मुझे "${examName}" (${category}) परीक्षा के बारे में पूरी जानकारी आसान हिंदी में दीजिए। इसमें निम्नलिखित बिंदुओं को शामिल करें:
1. योग्यता (Eligibility & Age limit)
2. जरूरी दस्तावेज (Required Documents)
3. परीक्षा का पैटर्न और सिलेबस (Syllabus Overview)
4. आवेदन करने की प्रक्रिया (Application Process)`;

    try {
      const res = await generateSaarthiResponse(prompt, []);
      setResultText(res);
    } catch (e) {
      setResultText('जानकारी लोड करने में त्रुटि हुई। कृपया पुनः प्रयास करें।');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSpeak = () => {
    if (!('speechSynthesis' in window) || !resultText) return;
    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(resultText);
    utterance.lang = 'hi-IN';
    utterance.rate = 0.95;
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
      <div className={`w-full max-w-2xl max-h-[92vh] overflow-y-auto p-6 rounded-3xl shadow-2xl border transition-all ${
        darkMode ? 'bg-gray-900 border-gray-800 text-white' : 'bg-white border-gray-200 text-gray-900'
      }`}>
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-gray-200 dark:border-gray-800">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-violet-500 to-purple-700 text-white flex items-center justify-center shadow-md">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-base sm:text-lg">🎓 परीक्षा और फॉर्म अलर्ट (Exam Guide)</h2>
              <p className="text-xs text-gray-400">योग्यता, सिलेबस, और आवेदन प्रक्रिया की पूरी जानकारी</p>
            </div>
          </div>
          <button
            onClick={() => {
              if (isSpeaking) window.speechSynthesis.cancel();
              onClose();
            }}
            className={`p-1.5 rounded-lg transition-colors ${darkMode ? 'hover:bg-gray-800 text-gray-400' : 'hover:bg-gray-100 text-gray-600'}`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4 text-xs sm:text-sm">
          <div>
            <label className="block font-semibold mb-2">श्रेणी चुनें (Category):</label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {['UPSC / SSC', 'NEET / JEE', 'Board Exams', 'State Govt / Police'].map(cat => (
                <button
                  key={cat}
                  onClick={() => {
                    setCategory(cat);
                    if (cat === 'UPSC / SSC') setExamName('UPSC Civil Services (IAS)');
                    if (cat === 'NEET / JEE') setExamName('NEET UG Medical Exam');
                    if (cat === 'Board Exams') setExamName('Class 10th & 12th Board Exams');
                    if (cat === 'State Govt / Police') setExamName('State Police Constable / SI Exam');
                  }}
                  className={`p-2.5 rounded-xl border text-xs font-semibold transition-all ${
                    category === cat
                      ? 'bg-purple-600 border-purple-600 text-white shadow-md'
                      : darkMode ? 'bg-gray-800 border-gray-700 text-gray-300' : 'bg-white border-gray-200 text-gray-700'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block font-semibold mb-1">परीक्षा या फॉर्म का नाम लिखें:</label>
            <div className="flex gap-2">
              <input
                type="text"
                value={examName}
                onChange={e => setExamName(e.target.value)}
                placeholder="परीक्षा का नाम दर्ज करें..."
                className={`flex-1 px-3.5 py-2.5 rounded-xl border outline-none text-xs ${
                  darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
                }`}
              />
              <button
                onClick={handleFetchExamInfo}
                disabled={isLoading || !examName.trim()}
                className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white font-bold text-xs shadow-md flex items-center gap-1.5 shrink-0"
              >
                <Search className="w-4 h-4" />
                <span>{isLoading ? 'खोज रहा है...' : 'जानकारी पाएं'}</span>
              </button>
            </div>
          </div>

          {resultText && (
            <div className={`p-4 rounded-2xl border space-y-3 ${darkMode ? 'bg-gray-800/80 border-gray-700' : 'bg-gray-50 border-gray-200'}`}>
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-purple-400 uppercase tracking-wider">AI परीक्षा मार्गदर्शन</span>
                <button
                  onClick={handleSpeak}
                  className={`flex items-center gap-1 px-3 py-1.5 rounded-xl border font-semibold text-xs transition-all ${
                    isSpeaking ? 'bg-red-500 text-white border-red-600' : 'bg-purple-600 text-white border-purple-700'
                  }`}
                >
                  {isSpeaking ? <VolumeX className="w-3.5 h-3.5 animate-pulse" /> : <Volume2 className="w-3.5 h-3.5" />}
                  <span>{isSpeaking ? 'रुकें' : '🔊 सुनें'}</span>
                </button>
              </div>
              <div className="whitespace-pre-wrap leading-relaxed text-xs sm:text-sm">
                {resultText}
              </div>
            </div>
          )}

          <div className="pt-2 flex justify-end">
            <button
              onClick={() => {
                if (isSpeaking) window.speechSynthesis.cancel();
                onClose();
              }}
              className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-md transition-all"
            >
              बंद करें
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
