import React from 'react';
import { Sparkles, X, CheckCircle, Globe, Smartphone } from 'lucide-react';

interface AboutModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
}

export const AboutModal: React.FC<AboutModalProps> = ({ isOpen, onClose, darkMode }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
      <div className={`w-full max-w-md p-6 rounded-3xl shadow-2xl border text-center transition-all ${
        darkMode ? 'bg-gray-900 border-gray-800 text-white' : 'bg-white border-gray-200 text-gray-900'
      }`}>
        <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-orange-500 via-indigo-600 to-emerald-500 flex items-center justify-center text-white mx-auto mb-4 shadow-xl">
          <Sparkles className="w-8 h-8" />
        </div>

        <h3 className="font-bold text-lg mb-1">SaarthiAI - हर समस्या का हल</h3>
        <p className="text-xs text-indigo-500 font-semibold mb-3">भारत का सबसे तेज़ और स्मार्ट AI असिस्टेंट</p>

        <p className={`text-xs mb-6 leading-relaxed ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
          SaarthiAI को विशेष रूप से भारतीय नागरिकों के लिए डिज़ाइन किया गया है। सरकारी योजनाएं, फॉर्म, आरटीआई, खेती की सलाह, और पढ़ाई के सवालों के जवाब सेकंडों में पाएं।
        </p>

        <div className="space-y-2 mb-6 text-left text-xs bg-gray-100 dark:bg-gray-800 p-3.5 rounded-2xl">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0" />
            <span>Google Gemini 3.1 Flash Lite द्वारा संचालित</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0" />
            <span>वेबसाइट (PWA) और Android APK दोनों पर समर्थित</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0" />
            <span>वॉयस इनपुट और ऑडियो स्पीच सपोर्ट</span>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-md transition-all"
        >
          ठीक है
        </button>
      </div>
    </div>
  );
};
