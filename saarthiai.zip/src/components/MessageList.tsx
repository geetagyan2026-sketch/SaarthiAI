import React, { useState } from 'react';
import { Message } from '../types';
import { Volume2, VolumeX, Copy, Check, Share2, Sparkles, User, RotateCw } from 'lucide-react';
import { AdSenseBanner } from './AdSenseBanner';
import { isAndroidApp } from '../lib/platform';

interface MessageListProps {
  messages: Message[];
  isLoading: boolean;
  onRegenerate: () => void;
  language: string;
  darkMode: boolean;
}

export const MessageList: React.FC<MessageListProps> = ({ messages, isLoading, onRegenerate, language, darkMode }) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const isApp = isAndroidApp();

  const langCodeMap: Record<string, string> = {
    hi: 'hi-IN',
    en: 'en-US',
    ar: 'ar-SA',
    es: 'es-ES',
    fr: 'fr-FR',
    pa: 'pa-IN',
    bn: 'bn-IN',
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSpeak = (text: string, id: string) => {
    if (!('speechSynthesis' in window)) return;
    if (speakingId === id) {
      window.speechSynthesis.cancel();
      setSpeakingId(null);
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = langCodeMap[language] || 'hi-IN';
    utterance.rate = 0.95;
    utterance.onend = () => setSpeakingId(null);
    utterance.onerror = () => setSpeakingId(null);
    setSpeakingId(id);
    window.speechSynthesis.speak(utterance);
  };

  const handleWhatsAppShare = (text: string) => {
    const encoded = encodeURIComponent(`*SaarthiAI Global AI Assistant:*\n\n${text}`);
    window.open(`https://api.whatsapp.com/send?text=${encoded}`, '_blank');
  };

  let modelMessageCount = 0;

  return (
    <div className="flex-1 overflow-y-auto px-4 py-6 space-y-6 max-w-3xl mx-auto w-full custom-scrollbar">
      {messages.map((msg) => {
        const isUser = msg.role === 'user';
        if (!isUser) {
          modelMessageCount++;
        }
        const showAd = !isApp && !isUser && modelMessageCount > 0 && modelMessageCount % 2 === 0;

        return (
          <React.Fragment key={msg.id}>
            <div className={`flex gap-3 sm:gap-4 ${isUser ? 'justify-end' : 'justify-start'}`}>
              {!isUser && (
                <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-2xl bg-gradient-to-tr from-orange-500 via-indigo-600 to-emerald-500 flex items-center justify-center text-white shrink-0 shadow-md">
                  <Sparkles className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
              )}

              <div className={`flex flex-col max-w-[88%] sm:max-w-[80%] ${isUser ? 'items-end' : 'items-start'}`}>
                <div className={`p-4 rounded-2xl sm:rounded-3xl shadow-sm text-xs sm:text-sm leading-relaxed ${
                  isUser
                    ? 'bg-indigo-600 text-white rounded-tr-sm'
                    : darkMode
                      ? 'bg-gray-800 text-gray-100 rounded-tl-sm border border-gray-700/80'
                      : 'bg-white text-gray-800 rounded-tl-sm border border-gray-200/80'
                }`}>
                  {msg.image && (
                    <div className="mb-3">
                      <img src={msg.image} alt="User Upload" className="max-h-60 rounded-xl object-cover shadow-sm" />
                    </div>
                  )}
                  
                  <div className="whitespace-pre-wrap font-sans space-y-2">
                    {msg.content}
                  </div>
                </div>

                {!isUser && (
                  <div className="flex items-center gap-2 mt-2 ml-1 text-xs flex-wrap">
                    <button
                      onClick={() => handleSpeak(msg.content, msg.id)}
                      className={`flex items-center gap-1 px-2.5 py-1 rounded-lg border transition-all ${
                        speakingId === msg.id
                          ? 'bg-red-500 text-white border-red-600'
                          : darkMode
                            ? 'bg-gray-800 border-gray-700 text-gray-300 hover:bg-gray-700'
                            : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-100'
                      }`}
                      title="Listen Audio"
                    >
                      {speakingId === msg.id ? <VolumeX className="w-3.5 h-3.5 animate-pulse" /> : <Volume2 className="w-3.5 h-3.5 text-indigo-500" />}
                      <span>{speakingId === msg.id ? 'Stop' : '🔊 Listen'}</span>
                    </button>

                    <button
                      onClick={() => handleCopy(msg.content, msg.id)}
                      className={`flex items-center gap-1 px-2.5 py-1 rounded-lg border transition-all ${
                        darkMode ? 'bg-gray-800 border-gray-700 text-gray-300 hover:bg-gray-700' : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-100'
                      }`}
                      title="Copy"
                    >
                      {copiedId === msg.id ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5 text-indigo-500" />}
                      <span>{copiedId === msg.id ? 'Copied' : 'Copy'}</span>
                    </button>

                    <button
                      onClick={onRegenerate}
                      className={`flex items-center gap-1 px-2.5 py-1 rounded-lg border transition-all ${
                        darkMode ? 'bg-gray-800 border-gray-700 text-gray-300 hover:bg-gray-700' : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-100'
                      }`}
                      title="Regenerate"
                    >
                      <RotateCw className="w-3.5 h-3.5 text-indigo-500" />
                      <span>Regenerate</span>
                    </button>

                    <button
                      onClick={() => handleWhatsAppShare(msg.content)}
                      className={`flex items-center gap-1 px-2.5 py-1 rounded-lg border transition-all text-emerald-600 dark:text-emerald-400 ${
                        darkMode ? 'bg-gray-800 border-gray-700 hover:bg-gray-700' : 'bg-white border-gray-200 hover:bg-gray-100'
                      }`}
                      title="WhatsApp Share"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                      <span>WhatsApp</span>
                    </button>
                  </div>
                )}
              </div>

              {isUser && (
                <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-2xl bg-indigo-600 flex items-center justify-center text-white shrink-0 shadow-md">
                  <User className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
              )}
            </div>

            {showAd && <AdSenseBanner slotId={`slot-${msg.id}`} />}
          </React.Fragment>
        );
      })}

      {isLoading && (
        <div className="flex gap-4 items-center">
          <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-2xl bg-gradient-to-tr from-orange-500 via-indigo-600 to-emerald-500 flex items-center justify-center text-white shrink-0 shadow-md animate-pulse">
            <Sparkles className="w-5 h-5" />
          </div>
          <div className={`p-4 rounded-2xl sm:rounded-3xl border shadow-sm flex items-center gap-2 ${
            darkMode ? 'bg-gray-800 border-gray-700 text-gray-300' : 'bg-white border-gray-200 text-gray-600'
          }`}>
            <div className="w-2 h-2 rounded-full bg-indigo-600 animate-bounce" />
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-bounce [animation-delay:0.2s]" />
            <div className="w-2 h-2 rounded-full bg-orange-500 animate-bounce [animation-delay:0.4s]" />
            <span className="text-xs font-medium ml-1">SaarthiAI (Google Search Grounding) searching live...</span>
          </div>
        </div>
      )}
    </div>
  );
};
