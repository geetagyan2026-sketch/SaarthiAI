import React, { useState } from 'react';
import { Message, SourceLink } from '../types';
import { Volume2, VolumeX, Copy, Check, Share2, Sparkles, User, RotateCw, CheckCircle2, ExternalLink } from 'lucide-react';
import { AdSenseBanner } from './AdSenseBanner';
import { isAndroidApp } from '../lib/platform';
import { SPEECH_LANG_MAP } from '../lib/regions';

interface MessageListProps {
  messages: Message[];
  isLoading: boolean;
  onRegenerate: () => void;
  onQuickAction?: (prompt: string) => void;
  language: string;
  darkMode: boolean;
}

function isOfficialUrl(uri: string): boolean {
  try {
    const host = new URL(uri).hostname.toLowerCase();
    return /\.(gov\.in|nic\.in|gov|gov\.uk|gc\.ca|gov\.ae|gov\.au|go\.jp|gouv\.fr|gov\.sg|gov\.sa|govt\.nz|ac\.in|edu\.in|edu)$/i.test(
      host
    );
  } catch {
    return false;
  }
}

function getCleanDomain(uri: string, fallbackTitle?: string): string {
  try {
    return new URL(uri).hostname.replace(/^www\./, '');
  } catch {
    return fallbackTitle || uri;
  }
}

function pickTopVerifiedSource(sources?: SourceLink[]): SourceLink | null {
  if (!sources || sources.length === 0) return null;
  const valid = sources.filter((s) => s && typeof s.uri === 'string' && /^https?:\/\//i.test(s.uri));
  if (valid.length === 0) return null;
  const official = valid.find((s) => isOfficialUrl(s.uri));
  return official || valid[0];
}

function renderInlineFormatting(text: string, darkMode: boolean): React.ReactNode[] {
  const tokens = text.split(/(\*\*[^*]+\*\*|\[[^\]]+\]\(https?:\/\/[^)]+\))/g);
  return tokens.map((part, idx) => {
    if (part.startsWith('**') && part.endsWith('**') && part.length > 4) {
      return (
        <strong key={idx} className={darkMode ? 'font-semibold text-white' : 'font-semibold text-gray-950'}>
          {part.slice(2, -2)}
        </strong>
      );
    }
    const linkMatch = part.match(/^\[([^\]]+)\]\((https?:\/\/[^)]+)\)$/);
    if (linkMatch) {
      return (
        <a
          key={idx}
          href={linkMatch[2]}
          target="_blank"
          rel="noopener noreferrer"
          className="text-indigo-500 hover:underline font-medium"
        >
          {linkMatch[1]}
        </a>
      );
    }
    return <React.Fragment key={idx}>{part}</React.Fragment>;
  });
}

function renderFormattedReply(content: string, darkMode: boolean): React.ReactNode {
  const lines = content.split('\n');
  return (
    <div className="space-y-2 text-xs sm:text-sm leading-relaxed break-words">
      {lines.map((rawLine, idx) => {
        const line = rawLine.trim();
        if (!line) {
          return <div key={idx} className="h-1" />;
        }

        if (line.startsWith('### ') || line.startsWith('## ') || line.startsWith('# ')) {
          const headingText = line.replace(/^#{1,4}\s*/, '');
          return (
            <h4
              key={idx}
              className={`font-bold text-xs sm:text-sm pt-1.5 ${
                darkMode ? 'text-indigo-300' : 'text-indigo-700'
              }`}
            >
              {renderInlineFormatting(headingText, darkMode)}
            </h4>
          );
        }

        if (/^(•|-|\*)\s+/.test(line)) {
          const itemText = line.replace(/^(•|-|\*)\s+/, '');
          return (
            <div key={idx} className="flex items-start gap-2 pl-1">
              <span className="text-indigo-500 font-bold shrink-0 mt-0.5">•</span>
              <span className="flex-1">{renderInlineFormatting(itemText, darkMode)}</span>
            </div>
          );
        }

        const numMatch = line.match(/^(\d+[.)])\s+(.+)$/);
        if (numMatch) {
          return (
            <div key={idx} className="flex items-start gap-2 pl-1">
              <span className="text-indigo-500 font-semibold shrink-0">{numMatch[1]}</span>
              <span className="flex-1">{renderInlineFormatting(numMatch[2], darkMode)}</span>
            </div>
          );
        }

        return <p key={idx}>{renderInlineFormatting(line, darkMode)}</p>;
      })}
    </div>
  );
}

export const MessageList: React.FC<MessageListProps> = ({
  messages,
  isLoading,
  onRegenerate,
  onQuickAction,
  language,
  darkMode,
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const isApp = isAndroidApp();

  const langCodeMap = SPEECH_LANG_MAP;

  const getShareableText = (msg: Message): string => {
    const base = msg.content?.trim() || '';
    const topSource = pickTopVerifiedSource(msg.sources);
    if (!topSource) return base;
    const domain = getCleanDomain(topSource.uri, topSource.title);
    return `${base}\n\n✅ Official Source: ${domain} (${topSource.uri})`;
  };

  const handleCopy = (msg: Message) => {
    const text = getShareableText(msg);
    if (!text) return;
    navigator.clipboard.writeText(text);
    setCopiedId(msg.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSpeak = (msg: Message) => {
    const textToSpeak = msg.content?.trim() || '';
    if (!('speechSynthesis' in window) || !textToSpeak) return;
    if (speakingId === msg.id) {
      window.speechSynthesis.cancel();
      setSpeakingId(null);
      return;
    }
    window.speechSynthesis.cancel();
    const cleanSpeechText = textToSpeak.replace(/#{1,4}\s*/g, '').replace(/\*\*/g, '');
    const utterance = new SpeechSynthesisUtterance(cleanSpeechText);
    utterance.lang = langCodeMap[language] || 'hi-IN';
    utterance.rate = 0.95;
    utterance.onend = () => setSpeakingId(null);
    utterance.onerror = () => setSpeakingId(null);
    setSpeakingId(msg.id);
    window.speechSynthesis.speak(utterance);
  };

  let modelMessageCount = 0;

  return (
    <div className="flex-1 overflow-y-auto px-3 sm:px-4 py-4 sm:py-6 space-y-5 sm:space-y-6 max-w-4xl mx-auto w-full custom-scrollbar">
      {messages.map((msg) => {
        const isUser = msg.role === 'user';
        if (!isUser) {
          modelMessageCount++;
        }
        const showAd = !isApp && !isUser && modelMessageCount > 0 && modelMessageCount % 2 === 0;
        const topSource = !isUser ? pickTopVerifiedSource(msg.sources) : null;
        const topDomain = topSource ? getCleanDomain(topSource.uri, topSource.title) : '';
        const whatsappUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(
          `*SaarthiAI:*\n\n${getShareableText(msg)}`
        )}`;

        return (
          <React.Fragment key={msg.id}>
            <div className={`flex gap-2.5 sm:gap-4 ${isUser ? 'justify-end' : 'justify-start'}`}>
              {!isUser && (
                <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-2xl bg-gradient-to-tr from-orange-500 via-indigo-600 to-emerald-500 flex items-center justify-center text-white shrink-0 shadow-md">
                  <Sparkles className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
              )}

              <div className={`flex flex-col ${isUser ? 'max-w-[86%] sm:max-w-[75%] items-end' : 'flex-1 min-w-0 max-w-full sm:max-w-[88%] items-start'}`}>
                <div
                  className={`p-4 rounded-2xl sm:rounded-3xl shadow-sm text-xs sm:text-sm leading-relaxed ${
                    isUser
                      ? 'bg-indigo-600 text-white rounded-tr-sm'
                      : darkMode
                        ? 'bg-gray-800 text-gray-100 rounded-tl-sm border border-gray-700/80'
                        : 'bg-white text-gray-800 rounded-tl-sm border border-gray-200/80'
                  }`}
                >
                  {msg.image && (
                    <div className="mb-3">
                      <img src={msg.image} alt="User Upload" className="max-h-60 rounded-xl object-cover shadow-sm" />
                    </div>
                  )}

                  {isUser ? (
                    <div className="whitespace-pre-wrap font-sans space-y-2">{msg.content}</div>
                  ) : (
                    <>
                      {renderFormattedReply(msg.content, darkMode)}

                      {msg.quickActions && msg.quickActions.length > 0 && onQuickAction && (
                        <div className="mt-3.5 pt-3 border-t border-gray-200/70 dark:border-gray-700/70">
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            {msg.quickActions.map((qa) => (
                              <button
                                key={qa.label}
                                type="button"
                                disabled={isLoading}
                                onClick={() => onQuickAction(qa.prompt)}
                                className={`flex items-center justify-between gap-2 px-3 py-2.5 rounded-xl border text-left text-xs font-semibold transition-all active:scale-[0.99] disabled:opacity-50 ${
                                  darkMode
                                    ? 'bg-gray-900/80 border-gray-700 text-indigo-300 hover:bg-indigo-600 hover:text-white hover:border-indigo-500'
                                    : 'bg-indigo-50/70 border-indigo-200 text-indigo-800 hover:bg-indigo-600 hover:text-white hover:border-indigo-600'
                                }`}
                              >
                                <span className="truncate">{qa.label}</span>
                                <span className="text-[11px] opacity-80 shrink-0">→</span>
                              </button>
                            ))}
                          </div>
                        </div>
                      )}

                      {topSource && (
                        <div
                          className={`mt-3 pt-2.5 border-t flex items-center justify-between gap-2 text-[11px] sm:text-xs flex-wrap ${
                            darkMode ? 'border-gray-700/80 text-emerald-400' : 'border-gray-200 text-emerald-700'
                          }`}
                        >
                          <div className="flex items-center gap-1.5 min-w-0">
                            <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                            <span className="font-semibold shrink-0">Official Source:</span>
                            <a
                              href={topSource.uri}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="underline font-medium hover:opacity-80 truncate"
                            >
                              {topDomain}
                            </a>
                          </div>
                          <a
                            href={topSource.uri}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold shadow-xs transition-all shrink-0"
                          >
                            <span>{language === 'en' ? 'Apply on Official Portal' : 'ऑफिशियल पोर्टल पर फॉर्म भरें'}</span>
                            <ExternalLink className="w-3 h-3 shrink-0" />
                          </a>
                        </div>
                      )}
                    </>
                  )}
                </div>

                {!isUser && (
                  <div className="flex items-center gap-2 mt-2 ml-1 text-xs flex-wrap">
                    <button
                      onClick={() => handleSpeak(msg)}
                      className={`flex items-center gap-1 px-2.5 py-1 rounded-lg border transition-all ${
                        speakingId === msg.id
                          ? 'bg-red-500 text-white border-red-600'
                          : darkMode
                            ? 'bg-gray-800 border-gray-700 text-gray-300 hover:bg-gray-700'
                            : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-100'
                      }`}
                      title="Listen Audio"
                    >
                      {speakingId === msg.id ? <VolumeX className="w-3.5 h-3.5 animate-pulse" /> : <Volume2 className="w-3.5 h-3.5 text-indigo-500" />}
                      <span>{speakingId === msg.id ? 'Stop' : '🔊 Listen'}</span>
                    </button>

                    <button
                      onClick={() => handleCopy(msg)}
                      className={`flex items-center gap-1 px-2.5 py-1 rounded-lg border transition-all ${
                        darkMode ? 'bg-gray-800 border-gray-700 text-gray-300 hover:bg-gray-700' : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-100'
                      }`}
                      title="Copy"
                    >
                      {copiedId === msg.id ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5 text-indigo-500" />}
                      <span>{copiedId === msg.id ? 'Copied' : 'Copy'}</span>
                    </button>

                    <button
                      onClick={onRegenerate}
                      className={`flex items-center gap-1 px-2.5 py-1 rounded-lg border transition-all ${
                        darkMode ? 'bg-gray-800 border-gray-700 text-gray-300 hover:bg-gray-700' : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-100'
                      }`}
                      title="Regenerate"
                    >
                      <RotateCw className="w-3.5 h-3.5 text-indigo-500" />
                      <span>Regenerate</span>
                    </button>

                    <a
                      href={whatsappUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`flex items-center gap-1 px-2.5 py-1 rounded-lg border transition-all text-emerald-600 dark:text-emerald-400 ${
                        darkMode ? 'bg-gray-800 border-gray-700 hover:bg-gray-700' : 'bg-white border-gray-200 hover:bg-gray-100'
                      }`}
                      title="WhatsApp Share"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                      <span>WhatsApp</span>
                    </a>
                  </div>
                )}
              </div>

              {isUser && (
                <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-2xl bg-indigo-600 flex items-center justify-center text-white shrink-0 shadow-md">
                  <User className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
              )}
            </div>

            {showAd && <AdSenseBanner slotId={`slot-${msg.id}`} />}
          </React.Fragment>
        );
      })}

      {isLoading && (
        <div className="flex gap-4 items-center">
          <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-2xl bg-gradient-to-tr from-orange-500 via-indigo-600 to-emerald-500 flex items-center justify-center text-white shrink-0 shadow-md animate-pulse">
            <Sparkles className="w-5 h-5" />
          </div>
          <div
            className={`p-4 rounded-2xl sm:rounded-3xl border shadow-sm flex items-center gap-2 ${
              darkMode ? 'bg-gray-800 border-gray-700 text-gray-300' : 'bg-white border-gray-200 text-gray-600'
            }`}
          >
            <div className="w-2 h-2 rounded-full bg-indigo-600 animate-bounce" />
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-bounce [animation-delay:0.2s]" />
            <div className="w-2 h-2 rounded-full bg-orange-500 animate-bounce [animation-delay:0.4s]" />
            <span className="text-xs font-medium ml-1">SaarthiAI लाइव आधिकारिक पोर्टल पढ़कर उत्तर तैयार कर रहा है...</span>
          </div>
        </div>
      )}
    </div>
  );
};
