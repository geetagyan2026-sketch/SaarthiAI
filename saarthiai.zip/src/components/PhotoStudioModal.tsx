import React, { useState, useRef, useEffect } from 'react';
import { Camera, X, Download, Share2, Sparkles, Image as ImageIcon, Loader2, CheckCircle2, FileText } from 'lucide-react';

interface PhotoStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
}

type PhotoSize = 'passport' | 'signature' | 'us_visa' | 'global_visa' | 'college_job' | 'a4grid';
type BgColor = 'white' | 'blue' | 'grey' | 'original';
type KbLimit = 0 | 20 | 50 | 100 | 240;

const PRESET_META: Record<PhotoSize, { label: string; w: number; h: number; desc: string }> = {
  passport: { label: '🇮🇳 इंडियन पासपोर्ट / फॉर्म (3.5×4.5)', w: 350, h: 450, desc: 'SSC, UPSC, RPSC, NEET, e-Mitra' },
  signature: { label: '✍️ सिग्नेचर रिसाइज़ (Signature)', w: 300, h: 100, desc: 'सरकारी फॉर्म हस्ताक्षर (10–20 KB)' },
  us_visa: { label: '🇺🇸 US Visa / Green Card (2×2 in)', w: 600, h: 600, desc: 'DS-160 / US Visa Square (≤240 KB)' },
  global_visa: { label: '🌐 UK / Schengen / UAE Visa (35×45mm)', w: 413, h: 531, desc: 'UK, Europe, Canada, UAE, Australia' },
  college_job: { label: '🎓 कॉलेज / जॉब एप्लीकेशन', w: 400, h: 520, desc: 'यूनिवर्सिटी व जॉब पोर्टल स्टैंडर्ड' },
  a4grid: { label: '🖨️ A4 प्रिंट शीट (16 फोटो)', w: 800, h: 1100, desc: 'प्रिंटर से तुरंत प्रिंट करने हेतु' },
};

export const PhotoStudioModal: React.FC<PhotoStudioModalProps> = ({ isOpen, onClose, darkMode }) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [sizePreset, setSizePreset] = useState<PhotoSize>('passport');
  const [bgColor, setBgColor] = useState<BgColor>('white');
  const [targetKb, setTargetKb] = useState<KbLimit>(50);
  const [outputDataUrl, setOutputDataUrl] = useState<string>('');
  const [outputInfo, setOutputInfo] = useState<{ kb: number; width: number; height: number; format: string } | null>(null);
  const [aiPrompt, setAiPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!isOpen) {
      setIsGenerating(false);
      setErrorMsg('');
    }
  }, [isOpen]);

  useEffect(() => {
    if (selectedImage && canvasRef.current) {
      renderProcessedPhoto();
    }
  }, [selectedImage, sizePreset, bgColor, targetKb]);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setErrorMsg('');
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGenerateAiImage = async () => {
    if (!aiPrompt.trim() || isGenerating) return;
    setIsGenerating(true);
    setErrorMsg('');

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 90000);

    try {
      const res = await fetch('/api/gemini/generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: aiPrompt.trim() }),
        signal: controller.signal,
      });

      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data?.imageDataUrl) {
        setErrorMsg(data?.error || 'इमेज तैयार नहीं हो सकी। कृपया दूसरा विवरण लिखें या अपनी फोटो अपलोड करें।');
        return;
      }

      setSelectedImage(data.imageDataUrl);
      setAiPrompt('');
    } catch (e: unknown) {
      if (e instanceof Error && e.name === 'AbortError') {
        setErrorMsg('इमेज बनाने में 90 सेकंड से अधिक समय लगा। कृपया पुनः प्रयास करें।');
      } else {
        const msg = e instanceof Error ? e.message : String(e);
        setErrorMsg(`AI इमेज त्रुटि: ${msg}`);
      }
    } finally {
      clearTimeout(timeoutId);
      setIsGenerating(false);
    }
  };

  const encodeWithKbLimit = (canvas: HTMLCanvasElement, limitKb: KbLimit) => {
    if (limitKb === 0) {
      const png = canvas.toDataURL('image/png');
      const approxBytes = Math.round((png.length - 'data:image/png;base64,'.length) * 0.75);
      setOutputDataUrl(png);
      setOutputInfo({
        kb: Number((approxBytes / 1024).toFixed(1)),
        width: canvas.width,
        height: canvas.height,
        format: 'PNG',
      });
      return;
    }

    const targetBytes = limitKb * 1024;
    let low = 0.1;
    let high = 0.96;
    let bestUrl = canvas.toDataURL('image/jpeg', 0.75);

    for (let i = 0; i < 8; i++) {
      const mid = (low + high) / 2;
      const attempt = canvas.toDataURL('image/jpeg', mid);
      const byteSize = Math.round((attempt.length - 'data:image/jpeg;base64,'.length) * 0.75);
      if (byteSize <= targetBytes) {
        bestUrl = attempt;
        low = mid;
      } else {
        high = mid;
      }
    }

    const finalBytes = Math.round((bestUrl.length - 'data:image/jpeg;base64,'.length) * 0.75);
    setOutputDataUrl(bestUrl);
    setOutputInfo({
      kb: Number((finalBytes / 1024).toFixed(1)),
      width: canvas.width,
      height: canvas.height,
      format: 'JPG',
    });
  };

  const renderProcessedPhoto = () => {
    const canvas = canvasRef.current;
    if (!canvas || !selectedImage) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new window.Image();
    img.crossOrigin = 'anonymous';
    img.src = selectedImage;
    img.onload = () => {
      const meta = PRESET_META[sizePreset];
      const width = meta.w;
      const height = meta.h;

      canvas.width = width;
      canvas.height = height;

      // JPEG does not preserve transparency, so default to white if original + KB compression
      if (bgColor === 'white' || (bgColor === 'original' && targetKb > 0)) {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, width, height);
      } else if (bgColor === 'blue') {
        ctx.fillStyle = '#0284c7';
        ctx.fillRect(0, 0, width, height);
      } else if (bgColor === 'grey') {
        ctx.fillStyle = '#e2e8f0';
        ctx.fillRect(0, 0, width, height);
      } else {
        ctx.clearRect(0, 0, width, height);
      }

      if (sizePreset === 'a4grid') {
        const pW = 160;
        const pH = 200;
        const cols = 4;
        const rows = 4;
        const startX = 60;
        const startY = 80;
        const gapX = 30;
        const gapY = 40;

        for (let r = 0; r < rows; r++) {
          for (let c = 0; c < cols; c++) {
            const x = startX + c * (pW + gapX);
            const y = startY + r * (pH + gapY);
            if (bgColor !== 'original') {
              ctx.fillStyle = bgColor === 'blue' ? '#0284c7' : bgColor === 'grey' ? '#e2e8f0' : '#ffffff';
              ctx.fillRect(x, y, pW, pH);
            }
            ctx.drawImage(img, x, y, pW, pH);
            ctx.strokeStyle = '#cbd5e1';
            ctx.lineWidth = 2;
            ctx.strokeRect(x, y, pW, pH);
          }
        }
      } else {
        const ratio = Math.min(width / img.width, height / img.height);
        const w = img.width * ratio;
        const h = img.height * ratio;
        const x = (width - w) / 2;
        const y = (height - h) / 2;

        ctx.drawImage(img, x, y, w, h);

        if (sizePreset === 'passport' || sizePreset === 'signature') {
          ctx.strokeStyle = '#cbd5e1';
          ctx.lineWidth = 2;
          ctx.strokeRect(0, 0, width, height);
        }
      }

      encodeWithKbLimit(canvas, targetKb);
    };
  };

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    try {
      const link = document.createElement('a');
      const ext = targetKb === 0 ? 'png' : 'jpg';
      link.download = `SaarthiAI_${sizePreset}_${targetKb || 'HD'}kb_${Date.now()}.${ext}`;
      link.href = outputDataUrl || canvas.toDataURL('image/png');
      link.click();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      setErrorMsg(`डाउनलोड त्रुटि: ${msg}`);
    }
  };

  const whatsappShareUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(
    `*SaarthiAI Global Form & Photo Hub*\nमैंने अपने डॉक्यूमेंट/पासपोर्ट फोटो (${PRESET_META[sizePreset].label}) को तैयार कर लिया है!`
  )}`;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/70 backdrop-blur-xs">
      <div
        className={`w-full sm:max-w-3xl max-h-[94dvh] overflow-y-auto p-4 sm:p-6 rounded-t-3xl sm:rounded-3xl shadow-2xl border transition-all ${
          darkMode ? 'bg-gray-900 border-gray-800 text-white' : 'bg-white border-gray-200 text-gray-900'
        }`}
      >
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-gray-200 dark:border-gray-800">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-orange-500 to-indigo-600 text-white flex items-center justify-center shadow-md shrink-0">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-sm sm:text-lg">📸 ग्लोबल फोटो, साइन व डॉक्यूमेंट रिसाइज़र</h2>
              <p className="text-[11px] sm:text-xs text-gray-400">
                Indian Govt (KB Resize), US/UK/Schengen Visa Photo &amp; A4 Print Studio
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className={`p-1.5 rounded-lg transition-colors ${
              darkMode ? 'hover:bg-gray-800 text-gray-400' : 'hover:bg-gray-100 text-gray-600'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4 text-xs sm:text-sm">
          {/* Quick Global & Indian Form Standards Guide */}
          <div
            className={`p-3 rounded-2xl border text-[11px] grid grid-cols-1 sm:grid-cols-3 gap-2 ${
              darkMode ? 'bg-indigo-950/30 border-indigo-800/50 text-indigo-200' : 'bg-indigo-50 border-indigo-200 text-indigo-900'
            }`}
          >
            <div className="flex items-start gap-1.5">
              <FileText className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
              <span>
                <strong>🇮🇳 Indian Govt:</strong> Photo 20–50 KB • Sign 10–20 KB
              </span>
            </div>
            <div className="flex items-start gap-1.5">
              <FileText className="w-3.5 h-3.5 text-indigo-400 shrink-0 mt-0.5" />
              <span>
                <strong>🇺🇸 US / 🌍 Global Visa:</strong> 2×2 in / 35×45 mm • White BG
              </span>
            </div>
            <div className="flex items-start gap-1.5">
              <FileText className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
              <span>
                <strong>🎓 College / Jobs:</strong> JPG &lt; 100 KB / PDF Print
              </span>
            </div>
          </div>

          <div className={`p-3.5 rounded-2xl border ${darkMode ? 'bg-gray-800/60 border-gray-700' : 'bg-gray-50 border-gray-200'}`}>
            <label className="font-semibold mb-1.5 flex items-center gap-1.5 text-indigo-500">
              <Sparkles className="w-4 h-4" />
              <span>AI से इमेज बनाएं (Text-to-Image)</span>
            </label>
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleGenerateAiImage();
                  }
                }}
                placeholder="जैसे: Professional studio portrait or shop banner..."
                className={`flex-1 px-3 py-2 rounded-xl border outline-none text-xs ${
                  darkMode ? 'bg-gray-900 border-gray-700 text-white' : 'bg-white border-gray-300 text-gray-900'
                }`}
              />
              <button
                type="button"
                onClick={handleGenerateAiImage}
                disabled={isGenerating || !aiPrompt.trim()}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-xs shadow-sm transition-all shrink-0 flex items-center justify-center gap-1.5"
              >
                {isGenerating && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                <span>{isGenerating ? 'बना रहा है...' : 'AI इमेज बनाएं'}</span>
              </button>
            </div>
            {errorMsg && (
              <p className="mt-2 text-xs text-red-400 bg-red-500/10 border border-red-500/30 rounded-xl px-3 py-2">
                {errorMsg}
              </p>
            )}
          </div>

          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept="image/*"
            className="hidden"
          />

          {!selectedImage ? (
            <div
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-3xl p-8 text-center cursor-pointer transition-all ${
                darkMode
                  ? 'border-gray-700 hover:border-indigo-500 bg-gray-800/30'
                  : 'border-gray-300 hover:border-indigo-500 bg-indigo-50/30'
              }`}
            >
              <div className="w-12 h-12 rounded-2xl bg-indigo-600/10 text-indigo-500 flex items-center justify-center mx-auto mb-3">
                <ImageIcon className="w-6 h-6" />
              </div>
              <p className="font-bold mb-1">अपनी फोटो या सिग्नेचर यहाँ अपलोड करें</p>
              <p className="text-[11px] text-gray-400">
                पासपोर्ट फोटो, वीज़ा फोटो (USA/UK/UAE/Schengen) व हस्ताक्षर रिसाइज़ करें
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {/* International & Indian Size Presets */}
              <div>
                <label className="block font-semibold mb-2">फॉर्म / वीज़ा साइज चुनें (International Presets):</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                  {(Object.keys(PRESET_META) as PhotoSize[]).map((key) => {
                    const preset = PRESET_META[key];
                    const active = sizePreset === key;
                    return (
                      <button
                        type="button"
                        key={key}
                        onClick={() => {
                          setSizePreset(key);
                          if (key === 'signature') setTargetKb(20);
                          else if (key === 'us_visa' || key === 'global_visa') setTargetKb(240);
                          else if (key === 'passport') setTargetKb(50);
                        }}
                        className={`p-2.5 rounded-xl border text-left transition-all ${
                          active
                            ? 'bg-indigo-600 border-indigo-600 text-white shadow-md'
                            : darkMode
                              ? 'bg-gray-800 border-gray-700 text-gray-200 hover:border-indigo-500'
                              : 'bg-white border-gray-200 text-gray-800 hover:border-indigo-400'
                        }`}
                      >
                        <div className="text-xs font-bold leading-snug">{preset.label}</div>
                        <div className={`text-[10px] mt-0.5 ${active ? 'text-indigo-100' : 'text-gray-400'}`}>
                          {preset.desc}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Target KB Compressor */}
              <div>
                <label className="block font-semibold mb-2">फ़ाइल साइज (KB Compression Target):</label>
                <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                  {[
                    { kb: 20 as KbLimit, label: '≤ 20 KB (Sign)' },
                    { kb: 50 as KbLimit, label: '≤ 50 KB (Govt)' },
                    { kb: 100 as KbLimit, label: '≤ 100 KB (Form)' },
                    { kb: 240 as KbLimit, label: '≤ 240 KB (Visa)' },
                    { kb: 0 as KbLimit, label: 'HD PNG (Original)' },
                  ].map((opt) => (
                    <button
                      key={opt.kb}
                      type="button"
                      onClick={() => setTargetKb(opt.kb)}
                      className={`py-2 px-2 rounded-xl border text-[11px] font-semibold transition-all ${
                        targetKb === opt.kb
                          ? 'bg-emerald-600 border-emerald-600 text-white shadow-xs'
                          : darkMode
                            ? 'bg-gray-800 border-gray-700 text-gray-300'
                            : 'bg-white border-gray-200 text-gray-700'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Background Color */}
              <div>
                <label className="block font-semibold mb-2">बैकग्राउंड रंग (Background Color):</label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { id: 'white', label: 'सफेद (White / Visa)', bg: 'bg-white border-gray-300 text-black' },
                    { id: 'blue', label: 'नीला (Passport Blue)', bg: 'bg-sky-600 text-white' },
                    { id: 'grey', label: 'ग्रे (Light Grey)', bg: 'bg-slate-300 text-black' },
                    { id: 'original', label: 'मूल (Original)', bg: 'bg-gradient-to-r from-orange-400 to-indigo-600 text-white' },
                  ].map((col) => (
                    <button
                      type="button"
                      key={col.id}
                      onClick={() => setBgColor(col.id as BgColor)}
                      className={`py-2 px-3 rounded-xl border text-[11px] font-medium transition-all ${col.bg} ${
                        bgColor === col.id ? 'ring-2 ring-indigo-500 scale-[1.02]' : 'opacity-85'
                      }`}
                    >
                      {col.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Output Preview + Exact Size Badge */}
              <div className="flex flex-col items-center p-4 rounded-2xl bg-gray-950/40 border border-gray-800 overflow-hidden gap-2">
                <canvas ref={canvasRef} className="max-h-64 rounded-xl shadow-lg object-contain" />
                {outputInfo && (
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/15 text-emerald-400 text-[11px] font-bold">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>
                      तैयार फ़ाइल: {outputInfo.width}×{outputInfo.height}px • {outputInfo.kb} KB ({outputInfo.format})
                    </span>
                  </div>
                )}
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedImage(null);
                    setOutputInfo(null);
                  }}
                  className={`px-4 py-2.5 rounded-xl text-xs font-medium transition-colors ${
                    darkMode ? 'hover:bg-gray-800 text-gray-400' : 'hover:bg-gray-100 text-gray-600'
                  }`}
                >
                  दूसरी फोटो चुनें
                </button>
                <div className="flex gap-2">
                  <a
                    href={whatsappShareUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs shadow-md flex items-center gap-1.5 transition-all"
                  >
                    <Share2 className="w-4 h-4" />
                    <span>WhatsApp</span>
                  </a>
                  <button
                    type="button"
                    onClick={handleDownload}
                    className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md flex items-center gap-1.5 transition-all"
                  >
                    <Download className="w-4 h-4" />
                    <span>डाउनलोड करें</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
