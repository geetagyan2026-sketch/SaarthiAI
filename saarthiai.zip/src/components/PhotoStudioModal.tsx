import React, { useState, useRef, useEffect } from 'react';
import { Camera, X, Download, Share2, Sparkles, Sliders, Image as ImageIcon, Check } from 'lucide-react';
import { getApiKey } from '../lib/geminiService';
import { GoogleGenAI } from '@google/genai';

interface PhotoStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
}

type PhotoSize = 'passport' | 'full' | 'square' | 'a4grid';
type BgColor = 'white' | 'blue' | 'grey' | 'original';

export const PhotoStudioModal: React.FC<PhotoStudioModalProps> = ({ isOpen, onClose, darkMode }) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [sizePreset, setSizePreset] = useState<PhotoSize>('passport');
  const [bgColor, setBgColor] = useState<BgColor>('white');
  const [aiPrompt, setAiPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (selectedImage && canvasRef.current) {
      renderProcessedPhoto();
    }
  }, [selectedImage, sizePreset, bgColor]);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGenerateAiImage = async () => {
    if (!aiPrompt.trim() || isGenerating) return;
    setIsGenerating(true);

    try {
      const apiKey = getApiKey();
      if (!apiKey) {
        alert('कृपया सेटिंग्स में Gemini API Key दर्ज करें।');
        setIsGenerating(false);
        return;
      }

      const ai = new GoogleGenAI({ apiKey });
      const response = await ai.models.generateImages({
        model: 'imagen-3.0-generate-002',
        prompt: aiPrompt,
        config: {
          numberOfImages: 1,
          outputMimeType: 'image/jpeg',
          aspectRatio: '1:1',
        },
      });

      const base64Bytes = response.generatedImages?.[0]?.image?.imageBytes;
      if (base64Bytes) {
        setSelectedImage(`data:image/jpeg;base64,${base64Bytes}`);
      }
    } catch (e: any) {
        console.error('AI Image Gen Error:', e);
        // Fallback placeholder image if imagen fails
        setSelectedImage('https://images.unsplash.com/photo-1579783902614-a3fb3927b675?w=600&h=600&fit=crop');
    } finally {
      setIsGenerating(false);
      setAiPrompt('');
    }
  };

  const renderProcessedPhoto = () => {
    const canvas = canvasRef.current;
    if (!canvas || !selectedImage) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new window.Image();
    img.crossOrigin = 'anonymous';
    img.src = selectedImage;
    img.onload = () => {
      // Set dimensions based on preset
      let width = 400;
      let height = 500;

      if (sizePreset === 'passport') {
        width = 350;
        height = 450;
      } else if (sizePreset === 'square') {
        width = 500;
        height = 500;
      } else if (sizePreset === 'full') {
        width = 400;
        height = 600;
      } else if (sizePreset === 'a4grid') {
        width = 800;
        height = 1100;
      }

      canvas.width = width;
      canvas.height = height;

      // Background color fill
      if (bgColor === 'white') {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, width, height);
      } else if (bgColor === 'blue') {
        ctx.fillStyle = '#0284c7'; // Passport Blue
        ctx.fillRect(0, 0, width, height);
      } else if (bgColor === 'grey') {
        ctx.fillStyle = '#e2e8f0';
        ctx.fillRect(0, 0, width, height);
      } else {
        ctx.clearRect(0, 0, width, height);
      }

      if (sizePreset === 'a4grid') {
        // Draw 8 passport photos grid on A4 sheet
        const pW = 160;
        const pH = 200;
        const cols = 4;
        const rows = 4;
        const startX = 60;
        const startY = 80;
        const gapX = 30;
        const gapY = 40;

        for (let r = 0; r < rows; r++) {
          for (let c = 0; c < cols; c++) {
            const x = startX + c * (pW + gapX);
            const y = startY + r * (pH + gapY);
            if (bgColor !== 'original') {
              ctx.fillStyle = bgColor === 'blue' ? '#0284c7' : '#ffffff';
              ctx.fillRect(x, y, pW, pH);
            }
            ctx.drawImage(img, x, y, pW, pH);
            ctx.strokeStyle = '#cbd5e1';
            ctx.lineWidth = 2;
            ctx.strokeRect(x, y, pW, pH);
          }
        }
      } else {
        // Single photo centered
        const ratio = Math.min(width / img.width, height / img.height);
        const w = img.width * ratio;
        const h = img.height * ratio;
        const x = (width - w) / 2;
        const y = (height - h) / 2;

        ctx.drawImage(img, x, y, w, h);

        // Add clean border for passport
        if (sizePreset === 'passport') {
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 6;
          ctx.strokeRect(0, 0, width, height);
          ctx.strokeStyle = '#cbd5e1';
          ctx.lineWidth = 2;
          ctx.strokeRect(0, 0, width, height);
        }
      }
    };
  };

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = `SaarthiAI_Photo_${sizePreset}_${Date.now()}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  const handleWhatsAppShare = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dataUrl = canvas.toDataURL('image/png');
    const encoded = encodeURIComponent(`*SaarthiAI Photo Studio से साझा तस्वीर*\n\nनमस्ते! मैंने SaarthiAI ऐप से यह फोटो तैयार की है।`);
    window.open(`https://api.whatsapp.com/send?text=${encoded}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
      <div className={`w-full max-w-2xl max-h-[95vh] overflow-y-auto p-6 rounded-3xl shadow-2xl border transition-all ${
        darkMode ? 'bg-gray-900 border-gray-800 text-white' : 'bg-white border-gray-200 text-gray-900'
      }`}>
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-gray-200 dark:border-gray-800">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-orange-500 to-indigo-600 text-white flex items-center justify-center shadow-md">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-base sm:text-lg">📸 1-सेकंड फोटो स्टूडियो (Passport & Full Photo)</h2>
              <p className="text-xs text-gray-400">पासपोर्ट साइज, फुल फोटो या AI पोस्टर बनाएं</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className={`p-1.5 rounded-lg transition-colors ${darkMode ? 'hover:bg-gray-800 text-gray-400' : 'hover:bg-gray-100 text-gray-600'}`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4 text-xs sm:text-sm">
          {/* AI Image Prompt Bar */}
          <div className={`p-3.5 rounded-2xl border ${darkMode ? 'bg-gray-800/60 border-gray-700' : 'bg-gray-50 border-gray-200'}`}>
            <label className="block font-semibold mb-1.5 flex items-center gap-1.5 text-indigo-500">
              <Sparkles className="w-4 h-4" />
              <span>AI से नया पोस्टर या इमेज बनाएं (Text-to-Image)</span>
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={aiPrompt}
                onChange={e => setAiPrompt(e.target.value)}
                placeholder="जैसे: दुकान के लिए शानदार डिस्काउंट ऑफर पोस्टर..."
                className={`flex-1 px-3 py-2 rounded-xl border outline-none text-xs ${
                  darkMode ? 'bg-gray-900 border-gray-700 text-white' : 'bg-white border-gray-300 text-gray-900'
                }`}
              />
              <button
                onClick={handleGenerateAiImage}
                disabled={isGenerating || !aiPrompt.trim()}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-xs shadow-sm transition-all shrink-0"
              >
                {isGenerating ? 'बना रहा है...' : 'AI इमेज बनाएं'}
              </button>
            </div>
          </div>

          {/* Upload Photo Button */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept="image/*"
            className="hidden"
          />

          {!selectedImage ? (
            <div
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-3xl p-8 text-center cursor-pointer transition-all ${
                darkMode ? 'border-gray-700 hover:border-indigo-500 bg-gray-800/30' : 'border-gray-300 hover:border-indigo-500 bg-indigo-50/30'
              }`}
            >
              <div className="w-12 h-12 rounded-2xl bg-indigo-600/10 text-indigo-500 flex items-center justify-center mx-auto mb-3">
                <ImageIcon className="w-6 h-6" />
              </div>
              <p className="font-bold mb-1">अपनी फोटो यहाँ अपलोड करें या क्लिक करें</p>
              <p className="text-[11px] text-gray-400">कैमरा या गैलरी से सेल्फी चुनें</p>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Size Preset Selector */}
              <div>
                <label className="block font-semibold mb-2">साइज चुनें (Size Presets):</label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { id: 'passport', label: 'पासपोर्ट (3.5×4.5)' },
                    { id: 'full', label: 'फुल फोटो (4×6)' },
                    { id: 'square', label: 'वर्ग / DP (1:1)' },
                    { id: 'a4grid', label: 'A4 प्रिंट शीट (8 फोटो)' },
                  ].map(preset => (
                    <button
                      key={preset.id}
                      onClick={() => setSizePreset(preset.id as PhotoSize)}
                      className={`p-2.5 rounded-xl border text-xs font-semibold transition-all ${
                        sizePreset === preset.id
                          ? 'bg-indigo-600 border-indigo-600 text-white shadow-md'
                          : darkMode ? 'bg-gray-800 border-gray-700 text-gray-300' : 'bg-white border-gray-200 text-gray-700'
                      }`}
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Background Color Selector */}
              <div>
                <label className="block font-semibold mb-2">बैकग्राउंड रंग (Background Color):</label>
                <div className="flex gap-3">
                  {[
                    { id: 'white', label: 'सफेद (White)', bg: 'bg-white border-gray-300 text-black' },
                    { id: 'blue', label: 'नीला (Passport Blue)', bg: 'bg-sky-600 text-white' },
                    { id: 'grey', label: 'ग्रे (Grey)', bg: 'bg-slate-300 text-black' },
                    { id: 'original', label: 'मूल (Original)', bg: 'bg-gradient-to-r from-orange-400 to-indigo-600 text-white' },
                  ].map(col => (
                    <button
                      key={col.id}
                      onClick={() => setBgColor(col.id as BgColor)}
                      className={`flex-1 py-2 px-3 rounded-xl border text-[11px] font-medium transition-all ${col.bg} ${
                        bgColor === col.id ? 'ring-2 ring-indigo-500 scale-105' : 'opacity-80'
                      }`}
                    >
                      {col.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Canvas Preview */}
              <div className="flex justify-center p-4 rounded-2xl bg-gray-950/40 border border-gray-800 overflow-hidden">
                <canvas ref={canvasRef} className="max-h-72 rounded-xl shadow-lg object-contain" />
              </div>

              <div className="flex items-center justify-between pt-2">
                <button
                  onClick={() => setSelectedImage(null)}
                  className={`px-4 py-2.5 rounded-xl text-xs font-medium transition-colors ${
                    darkMode ? 'hover:bg-gray-800 text-gray-400' : 'hover:bg-gray-100 text-gray-600'
                  }`}
                >
                  दूसरी फोटो चुनें
                </button>
                <div className="flex gap-2">
                  <button
                    onClick={handleWhatsAppShare}
                    className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs shadow-md flex items-center gap-1.5 transition-all"
                  >
                    <Share2 className="w-4 h-4" />
                    <span>WhatsApp</span>
                  </button>
                  <button
                    onClick={handleDownload}
                    className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md flex items-center gap-1.5 transition-all"
                  >
                    <Download className="w-4 h-4" />
                    <span>HD डाउनलोड करें</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
