import React, { useState } from 'react';
import { Sparkles, X, Zap, Check, ShieldCheck, Globe, CheckCircle2 } from 'lucide-react';
import { PAYMENT_LINKS } from './RewardedAdModal';
import { findRegionOption } from '../lib/regions';

interface ProPlansModalProps {
  isOpen: boolean;
  onClose: () => void;
  location: string;
  darkMode: boolean;
  onActivatePro: (days: number) => void;
}

export const ProPlansModal: React.FC<ProPlansModalProps> = ({
  isOpen,
  onClose,
  location,
  darkMode,
  onActivatePro,
}) => {
  const [paymentId, setPaymentId] = useState('');
  const [selectedPlanDays, setSelectedPlanDays] = useState<number>(15);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  if (!isOpen) return null;

  const activeRegion = findRegionOption(location);
  const isIndia = activeRegion.scope === 'india';
  const links = isIndia ? PAYMENT_LINKS.india : PAYMENT_LINKS.world;

  const plans = isIndia ? [
    {
      id: 'day1',
      days: 1,
      title: '1 Day Unlimited (No Ads)',
      price: '₹19',
      period: '1 दिन',
      desc: '24 घंटे के लिए सभी विज्ञापन बंद और असीमित सवाल व टूल्स।',
      url: links.day1,
    },
    {
      id: 'days15',
      days: 15,
      title: '15 Days Pro (No Ads)',
      price: '₹49',
      period: '15 दिन',
      desc: '15 दिनों तक बिना किसी रुकावट के सभी सरकारी और एआई सेवाएं।',
      url: links.days15,
      popular: true,
    },
    {
      id: 'month1',
      days: 30,
      title: '1 Month Full Pro (No Ads)',
      price: '₹99',
      period: '1 महीना',
      desc: 'पूरे 30 दिनों के लिए वीआईपी अनलिमिटेड एक्सेस और ज़ीरो ऐड्स।',
      url: links.month1,
    },
  ] : [
    {
      id: 'day1',
      days: 1,
      title: '1 Day Unlimited (No Ads)',
      price: '$1',
      period: '1 Day',
      desc: '24 hours of ad-free unlimited AI assistant & visa/citizen tools.',
      url: links.day1,
    },
    {
      id: 'days15',
      days: 15,
      title: '15 Days Pro (No Ads)',
      price: '$3',
      period: '15 Days',
      desc: '15 days of uninterrupted pro global citizen portal services.',
      url: links.days15,
      popular: true,
    },
    {
      id: 'month1',
      days: 30,
      title: '1 Month Full Pro (No Ads)',
      price: '$5',
      period: '1 Month',
      desc: 'Full 30 days VIP unlimited access with zero ads.',
      url: links.month1,
    },
  ];

  const handleActivate = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    const trimmed = paymentId.trim();
    if (!trimmed.startsWith('pay_') || trimmed.length < 14) {
      setErrorMsg('कृपया वैध Razorpay Payment ID दर्ज करें (जैसे pay_XXXX, कम से कम 14 अक्षर)।');
      return;
    }

    onActivatePro(selectedPlanDays);
    setSuccessMsg('Pro Activated Successfully! 🎉 सभी विज्ञापन हटा दिए गए हैं।');
    setTimeout(() => {
      setSuccessMsg('');
      setPaymentId('');
      onClose();
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div
        className={`w-full max-w-lg max-h-[92vh] overflow-y-auto p-6 rounded-3xl shadow-2xl border transition-all ${
          darkMode ? 'bg-gray-900 border-gray-800 text-white' : 'bg-white border-gray-200 text-gray-900'
        }`}
      >
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-gray-200 dark:border-gray-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-600 text-white flex items-center justify-center shadow-md">
              <Zap className="w-5 h-5 fill-current" />
            </div>
            <div>
              <h2 className="font-bold text-base sm:text-lg">SaarthiAI Pro (Skip All Ads)</h2>
              <p className="text-[10px] text-emerald-500 font-semibold flex items-center gap-1">
                <Globe className="w-3 h-3" />
                <span>Detected Region: {activeRegion.label} ({isIndia ? '₹ INR Plans' : '$ USD Plans'})</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className={`p-1.5 rounded-lg transition-colors ${darkMode ? 'hover:bg-gray-800 text-gray-400' : 'hover:bg-gray-100 text-gray-600'}`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className={`text-xs mb-4 ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
          प्रो प्लान एक्टिवेट करें और बिना कोई विज्ञापन (No Ads) देखे असीमित सवाल पूछें, रिज्यूमे बनाएं और ई-मित्र सेवाओं का लाभ उठाएं।
        </p>

        {/* Plans Grid */}
        <div className="space-y-3 mb-5">
          {plans.map((plan) => (
            <div
              key={plan.id}
              onClick={() => setSelectedPlanDays(plan.days)}
              className={`p-4 rounded-2xl border transition-all relative flex flex-col sm:flex-row sm:items-center justify-between gap-3 cursor-pointer ${
                selectedPlanDays === plan.days
                  ? 'ring-2 ring-indigo-500 ' + (darkMode ? 'bg-indigo-950/40 border-indigo-500' : 'bg-indigo-50/80 border-indigo-400')
                  : plan.popular
                    ? darkMode
                      ? 'bg-gradient-to-r from-amber-950/40 to-indigo-950/40 border-amber-500/50'
                      : 'bg-gradient-to-r from-amber-50 to-indigo-50 border-amber-300'
                    : darkMode
                      ? 'bg-gray-800/60 border-gray-700/80'
                      : 'bg-gray-50 border-gray-200'
              }`}
            >
              {plan.popular && (
                <span className="absolute -top-2.5 right-4 px-2.5 py-0.5 rounded-full bg-gradient-to-r from-amber-500 to-orange-600 text-white text-[10px] font-bold shadow-xs">
                  Most Popular 🔥
                </span>
              )}

              <div className="text-left space-y-1">
                <div className="flex items-center gap-2">
                  <input
                    type="radio"
                    name="proPlanSelect"
                    checked={selectedPlanDays === plan.days}
                    onChange={() => setSelectedPlanDays(plan.days)}
                    className="accent-indigo-600"
                  />
                  <h4 className="font-bold text-xs sm:text-sm">{plan.title}</h4>
                </div>
                <p className={`text-[11px] leading-relaxed pl-5 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  {plan.desc}
                </p>
              </div>

              <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-center gap-2 shrink-0">
                <span className="font-extrabold text-base sm:text-lg text-emerald-500">{plan.price}</span>
                <a
                  href={plan.url}
                  target="_top"
                  rel="noopener noreferrer"
                  onClick={(e) => {
                    e.stopPropagation();
                    try {
                      if (window.top) {
                        window.top.location.href = plan.url;
                      } else {
                        window.location.href = plan.url;
                      }
                    } catch {
                      window.location.href = plan.url;
                    }
                  }}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white text-xs font-bold shadow-sm transition-all active:scale-95 text-center cursor-pointer"
                >
                  Pro खरीदें 🚀
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Already Paid? Activate Pro Section */}
        <div className={`p-4 rounded-2xl border mb-4 ${
          darkMode ? 'bg-gray-800/80 border-gray-700' : 'bg-gray-50 border-gray-200'
        }`}>
          <h4 className="font-bold text-xs sm:text-sm mb-2 flex items-center gap-1.5 text-indigo-500">
            <CheckCircle2 className="w-4 h-4" />
            <span>Already Paid? Activate Pro (भुगतान के बाद एक्टिवेट करें)</span>
          </h4>
          <p className={`text-[11px] mb-3 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
            यदि आपने Razorpay लिंक पर भुगतान कर लिया है, तो अपनी Payment ID (जैसे <code>pay_Nrx8...</code>) नीचे दर्ज करें:
          </p>

          <form onSubmit={handleActivate} className="space-y-2.5">
            <input
              type="text"
              value={paymentId}
              onChange={(e) => setPaymentId(e.target.value)}
              placeholder="Enter Razorpay Payment ID (e.g. pay_XXXXXXXXXXXXXXXX)"
              className={`w-full px-3.5 py-2.5 rounded-xl border outline-none text-xs ${
                darkMode ? 'bg-gray-900 border-gray-700 text-white placeholder-gray-500' : 'bg-white border-gray-300 text-gray-950 placeholder-gray-400'
              }`}
            />

            {errorMsg && (
              <div className="text-[11px] text-rose-500 font-semibold px-1">
                {errorMsg}
              </div>
            )}

            {successMsg && (
              <div className="text-[11px] text-emerald-500 font-bold px-1 bg-emerald-500/10 p-2 rounded-lg">
                {successMsg}
              </div>
            )}

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold text-xs shadow-md transition-all active:scale-95"
            >
              Activate Now (प्रो एक्टिवेट करें)
            </button>
          </form>
        </div>

        <div className="flex items-center gap-2 p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/25 text-emerald-500 text-xs font-medium">
          <ShieldCheck className="w-4 h-4 shrink-0" />
          <span>सुरक्षित भुगतान गेटवे (Secure UPI, Card &amp; NetBanking Checkout)</span>
        </div>
      </div>
    </div>
  );
};
