import React from 'react';
import { FileText, Camera, Sprout, BookOpen, Sparkles, Smartphone, Calculator, MessageSquare, Image as ImageIcon, Pill, Receipt, GraduationCap, Mail, Sun, Calendar, HeartPulse } from 'lucide-react';

interface WelcomeScreenProps {
  onSelectSuggestion: (prompt: string) => void;
  onOpenResumeModal: () => void;
  onOpenPhotoStudioModal: () => void;
  onOpenInvitationModal: () => void;
  onOpenPanchangModal: () => void;
  onOpenExamModal: () => void;
  onOpenDailyHelperModal: () => void;
  darkMode: boolean;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({
  onSelectSuggestion,
  onOpenResumeModal,
  onOpenPhotoStudioModal,
  onOpenInvitationModal,
  onOpenPanchangModal,
  onOpenExamModal,
  onOpenDailyHelperModal,
  darkMode,
}) => {
  const cards = [
    {
      id: '1',
      title: '📄 1-सेकंड रिज्यूमे / बायोडाटा',
      desc: 'तुरंत प्रोफेशनल A4 रिज्यूमे बनाएं और PDF डाउनलोड करें',
      prompt: 'मेरे लिए नौकरी के लिए एक शानदार रिज्यूमे और बायोडाटा बना दीजिए।',
      icon: FileText,
      color: 'from-blue-500 to-indigo-600',
      action: 'resume',
    },
    {
      id: '2',
      title: '🎓 परीक्षा और फॉर्म अलर्ट',
      desc: 'स्कूल, कॉलेज, NEET, JEE और सरकारी परीक्षाओं की जानकारी',
      prompt: 'परीक्षा और फॉर्म अलर्ट गाइड खोलें।',
      icon: GraduationCap,
      color: 'from-purple-500 to-indigo-700',
      action: 'exam',
    },
    {
      id: '3',
      title: '📅 रोज़ाना मददगार',
      desc: 'आज की मुख्य खबरें, स्वास्थ्य टिप, सुविचार और बचत सलाह',
      prompt: 'आज के मुख्य समाचार और स्वास्थ्य सुझाव बताइए।',
      icon: Calendar,
      color: 'from-cyan-500 to-blue-600',
      action: 'daily',
    },
    {
      id: '4',
      title: '💌 निमंत्रण और बधाई कार्ड मेकर',
      desc: 'शादी, जन्मदिन या दुकान उद्घाटन का व्हाट्सएप कार्ड बनाएं',
      prompt: 'शादी या जन्मदिन का निमंत्रण कार्ड बनाने के लिए कार्ड मेकर खोलें।',
      icon: Mail,
      color: 'from-pink-500 to-rose-600',
      action: 'invitation',
    },
    {
      id: '5',
      title: '🕉️ आज का पंचांग और शुभ मुहूर्त',
      desc: 'आज का चौघड़िया, राहुकाल और शुभ समय जानें',
      prompt: 'आज का पंचांग और शुभ मुहूर्त बताइए।',
      icon: Sun,
      color: 'from-amber-500 to-orange-600',
      action: 'panchang',
    },
    {
      id: '6',
      title: '💊 दवाई की जानकारी',
      desc: 'दवाई की पट्टी या पर्चे का फोटो अपलोड करके नाम और सावधानियां जानें',
      prompt: 'इस फोटो में दी गई दवाई का नाम, उपयोग, साल्ट और सावधानियां आसान हिंदी में बताइए।',
      icon: Pill,
      color: 'from-rose-500 to-red-600',
      action: 'chat',
    },
    {
      id: '7',
      title: '🧾 बिल और रसीद रीडर',
      desc: 'बिजली बिल, राशन पर्ची या अस्पताल के बिल की फोटो समझें',
      prompt: 'इस बिल या रसीद की फोटो में कुल राशि, अंतिम तिथि और छुपे हुए चार्जेस की जांच करके बताइए।',
      icon: Receipt,
      color: 'from-amber-600 to-yellow-600',
      action: 'chat',
    },
    {
      id: '8',
      title: '📚 स्कूल होमवर्क और प्रश्न हल',
      desc: 'किताब के सवाल की फोटो खींचें और आसान हल पाएं',
      prompt: 'इस फोटो में दिए गए सवाल को स्टेप-बाय-स्टेप सरल हिंदी में हल करके समझाइए।',
      icon: BookOpen,
      color: 'from-violet-500 to-purple-700',
      action: 'chat',
    },
    {
      id: '9',
      title: '📸 1-सेकंड फोटो स्टूडियो',
      desc: 'पासपोर्ट साइज फोटो, बैकग्राउंड कलर और A4 प्रिंट शीट बनाएं',
      prompt: 'पासपोर्ट साइज फोटो बनाने के लिए फोटो स्टूडियो खोलें।',
      icon: Camera,
      color: 'from-orange-500 to-amber-600',
      action: 'photo',
    },
    {
      id: '10',
      title: '📝 सरकारी और बैंक एप्लीकेशन',
      desc: 'बैंक खाता, बिजली बिल, छुट्टी या आरटीआई पत्र',
      prompt: 'बैंक में खाता बंद करवाने या आधार कार्ड सुधार के लिए एक औपचारिक प्रार्थना पत्र लिखिए।',
      icon: MessageSquare,
      color: 'from-purple-500 to-indigo-600',
      action: 'chat',
    },
    {
      id: '11',
      title: '📱 Reels स्क्रिप्ट और WhatsApp स्टेटस',
      desc: 'इंस्टाग्राम रील्स स्क्रिप्ट, दुकान के ऑफर मैसेज',
      prompt: 'मेरी दुकान की दिवाली सेल के लिए एक आकर्षक WhatsApp स्टेटस और Instagram Reels स्क्रिप्ट लिखिए।',
      icon: Smartphone,
      color: 'from-pink-600 to-purple-600',
      action: 'chat',
    },
    {
      id: '12',
      title: '💰 ब्याज, EMI और बिज़नेस हिसाब',
      desc: 'साधारण/चक्रवृद्धि ब्याज, लोन EMI कैलकुलेशन',
      prompt: '₹50,000 का 2% मासिक ब्याज की दर से 8 महीने का कुल ब्याज और कुल राशि कितनी होगी, समझाइए।',
      icon: Calculator,
      color: 'from-cyan-600 to-teal-600',
      action: 'chat',
    },
    {
      id: '13',
      title: '🌾 सरकारी योजना और खेती सलाह',
      desc: 'PM Kisan, आयुष्मान कार्ड, खाद और फसल बीमा',
      prompt: 'प्रधानमंत्री किसान सम्मान निधि योजना का लाभ लेने के लिए क्या प्रक्रिया है और कौन आवेदन कर सकता है?',
      icon: Sprout,
      color: 'from-green-500 to-emerald-700',
      action: 'chat',
    },
  ];

  return (
    <div className="flex-1 flex flex-col items-center justify-center px-4 py-6 max-w-5xl mx-auto w-full text-center">
      <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-3xl bg-gradient-to-tr from-orange-500 via-indigo-600 to-emerald-500 flex items-center justify-center text-white shadow-xl mb-4 animate-pulse">
        <Sparkles className="w-7 h-7 sm:w-8 sm:h-8" />
      </div>

      <h2 className={`text-xl sm:text-3xl font-extrabold tracking-tight mb-2 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
        नमस्ते! आज मैं आपकी क्या मदद करूँ?
      </h2>

      <p className={`text-xs sm:text-sm max-w-lg mb-6 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
        नीचे दिए गए 13 उपयोगी टूल्स में से चुनें या नीचे प्रॉम्प्ट बार में बोलकर/लिखकर पूछें।
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5 w-full max-w-4xl">
        {cards.map((item) => {
          const IconComponent = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => {
                if (item.action === 'resume') {
                  onOpenResumeModal();
                } else if (item.action === 'photo') {
                  onOpenPhotoStudioModal();
                } else if (item.action === 'invitation') {
                  onOpenInvitationModal();
                } else if (item.action === 'panchang') {
                  onOpenPanchangModal();
                } else if (item.action === 'exam') {
                  onOpenExamModal();
                } else if (item.action === 'daily') {
                  onOpenDailyHelperModal();
                } else {
                  onSelectSuggestion(item.prompt);
                }
              }}
              className={`flex flex-col p-4 rounded-2xl border text-left transition-all duration-200 group hover:scale-[1.02] shadow-xs ${
                darkMode
                  ? 'bg-gray-800/60 border-gray-700/80 hover:bg-gray-800 hover:border-indigo-500 text-gray-200'
                  : 'bg-white border-gray-200/80 hover:bg-indigo-50/50 hover:border-indigo-300 text-gray-800'
              }`}
            >
              <div className="flex items-center gap-3 mb-2">
                <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${item.color} flex items-center justify-center text-white shrink-0 shadow-md group-hover:rotate-6 transition-transform`}>
                  <IconComponent className="w-4 h-4" />
                </div>
                <span className="font-bold text-xs sm:text-sm leading-tight">
                  {item.title}
                </span>
              </div>
              <p className={`text-[11px] leading-relaxed line-clamp-2 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                {item.desc}
              </p>
            </button>
          );
        })}
      </div>
    </div>
  );
};
