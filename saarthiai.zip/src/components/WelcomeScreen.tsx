import React, { useState } from 'react';
import {
  FileText,
  Camera,
  Sprout,
  BookOpen,
  Sparkles,
  Smartphone,
  Calculator,
  MessageSquare,
  Pill,
  Receipt,
  GraduationCap,
  Mail,
  Sun,
  Calendar,
  Search,
  MapPin,
  Landmark,
  Briefcase,
} from 'lucide-react';
import { findRegionOption, isGlobalUnspecifiedLocation } from '../lib/regions';
import { RegionCardCategory } from '../lib/regionCardGuides';

interface WelcomeScreenProps {
  onSelectSuggestion: (prompt: string) => void;
  onSelectRegionCard?: (category: RegionCardCategory) => void;
  onStartOnlineForm?: () => void;
  onOpenResumeModal: () => void;
  onOpenPhotoStudioModal: () => void;
  onOpenInvitationModal: () => void;
  onOpenPanchangModal: () => void;
  onOpenDailyHelperModal: () => void;
  location?: string;
  darkMode: boolean;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({
  onSelectSuggestion,
  onSelectRegionCard,
  onStartOnlineForm,
  onOpenResumeModal,
  onOpenPhotoStudioModal,
  onOpenInvitationModal,
  onOpenPanchangModal,
  onOpenDailyHelperModal,
  location = '🌍 Global / World',
  darkMode,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const activeRegion = findRegionOption(location);

  const handleHeroSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    onSelectSuggestion(searchQuery.trim());
    setSearchQuery('');
  };

  const isGlobalLocation = isGlobalUnspecifiedLocation(location);

  const quickSearches =
    activeRegion.scope === 'india'
      ? [
          {
            label: `${activeRegion.shortName} सरकारी नौकरी 2026`,
            query: `${activeRegion.shortName} में 2026 की ताज़ा सरकारी नौकरी, पात्रता, अंतिम तारीख, फीस और आवेदन प्रक्रिया क्या है?`,
          },
          {
            label: `${activeRegion.shortName} डिजिटल सेवाएं (${activeRegion.citizenGuide?.portalDomain || activeRegion.domainHint})`,
            query: `${activeRegion.shortName} सरकारी नागरिक पोर्टल (${activeRegion.citizenGuide?.portalDomain || activeRegion.domainHint}) पर ऑनलाइन प्रमाण पत्र व डिजिटल सेवाओं की प्रक्रिया व फीस बताएं।`,
          },
          {
            label: 'UPSC / SSC 2026',
            query: 'UPSC और SSC 2026 परीक्षा की योग्यता, तारीख, फीस और आवेदन प्रक्रिया बताएं।',
          },
          {
            label: 'PM किसान योजना',
            query: 'PM किसान सम्मान निधि योजना क्या है, पात्रता, किस्त और आवेदन प्रक्रिया विस्तार से बताएं।',
          },
        ]
      : [
          {
            label: isGlobalLocation ? 'Global / India e-Govt Portals' : `${activeRegion.shortName} Digital Citizen Portal`,
            query: isGlobalLocation
              ? 'ई-मित्र / e-District और विश्व के प्रमुख सरकारी नागरिक पोर्टल पर सेवाओं की जानकारी बताएं।'
              : `Explain ${activeRegion.shortName} official Digital Citizen Portal (${activeRegion.citizenGuide?.portalDomain || activeRegion.domainHint}) services, fees, documents, and step-by-step application process.`,
          },
          {
            label: isGlobalLocation ? 'Visa & Immigration Hub' : `${activeRegion.shortName} Visa & Work Permit`,
            query: isGlobalLocation
              ? 'Explain major global visa, immigration, and citizen portal services (USA, UK, UAE, Saudi Arabia, Canada).'
              : `What are the official government visa, work permit, and public service rules in ${activeRegion.shortName}?`,
          },
          {
            label: isGlobalLocation ? 'Global University Admission' : `${activeRegion.shortName} University Admission`,
            query: `Explain ${activeRegion.shortName} university admission requirements, deadlines, and scholarship steps.`,
          },
          {
            label: '🇮🇳 भारत सरकारी नौकरी 2026',
            query: 'भारत में प्रमुख सरकारी भर्तियां 2026 (UPSC, SSC, Railway) की योग्यता, तारीख व आवेदन प्रक्रिया बताएं।',
          },
        ];

  const citizenCardPrompt = isGlobalLocation
    ? 'ई-मित्र / e-District और विश्व के सरकारी नागरिक पोर्टल पर जाति, मूल निवास, आय प्रमाण पत्र व डिजिटल सेवाएं बनवाने की जानकारी बताइए।'
    : activeRegion.scope === 'india'
      ? `${activeRegion.shortName} के आधिकारिक नागरिक पोर्टल (${activeRegion.citizenGuide?.portalDomain || activeRegion.domainHint}) पर जाति, मूल निवास, आय प्रमाण पत्र और डिजिटल सेवाएं बनवाने की पात्रता, फीस और आवेदन प्रक्रिया बताइए।`
      : `Explain ${activeRegion.shortName} official Digital Citizen Portal (${activeRegion.citizenGuide?.portalDomain || activeRegion.domainHint}) services, ID/certificates, fees, required documents, and step-by-step application process.`;

  const cards = [
    {
      id: 'new-1',
      title: '📝 ऑनलाइन फॉर्म भरें (Apply Job, Admission & Govt Form)',
      desc: 'नौकरी, स्कूल-कॉलेज एडमिशन, ई-मित्र व सभी सरकारी फॉर्म भरने की स्टेप-बाय-स्टेप गाइड और सीधा ऑफिशियल पोर्टल लिंक',
      prompt: 'मैं ऑनलाइन फॉर्म भरना चाहता हूँ। कृपया पूछें कि मैं कौन-सा फॉर्म भरना चाहता हूँ।',
      icon: FileText,
      color: 'from-emerald-500 to-indigo-600',
      action: 'apply_form',
    },
    {
      id: 'new-2',
      title: '📸 1-सेकंड फोटो और साइन मेकर (Form Photo & Sign Resizer)',
      desc: 'ऑनलाइन फॉर्म के लिए 20KB-50KB की पासपोर्ट फोटो और 10KB-20KB के हस्ताक्षर (Signature) तुरंत तैयार करें',
      prompt: '',
      icon: Camera,
      color: 'from-orange-500 to-rose-600',
      action: 'photo',
    },
    {
      id: '1',
      title: '🏛️ सरकारी नौकरी / भर्ती',
      desc: isGlobalLocation
        ? 'ताज़ा सरकारी व ग्लोबल भर्तियों की योग्यता, तारीख, फीस और आवेदन विधि'
        : `${activeRegion.shortName} व केंद्र की ताज़ा भर्तियों की योग्यता, तारीख, फीस और आवेदन विधि`,
      prompt: `${activeRegion.shortName} और भारत की प्रमुख ताज़ा सरकारी नौकरी भर्तियों (2026) की योग्यता, अंतिम तारीख, फीस और आवेदन कैसे करें, आसान भाषा में बताइए।`,
      icon: Briefcase,
      color: 'from-purple-500 to-indigo-700',
      action: 'region_jobs',
    },
    {
      id: '2',
      title: '🎓 स्कूल / कॉलेज एडमिशन',
      desc: isGlobalLocation
        ? 'बोर्ड परीक्षा, यूनिवर्सिटी प्रवेश, छात्रवृत्ति और काउंसलिंग की पूरी जानकारी'
        : `${activeRegion.shortName} स्कूल/कॉलेज प्रवेश, छात्रवृत्ति और काउंसलिंग की पूरी जानकारी`,
      prompt: `${activeRegion.shortName} में स्कूल व कॉलेज एडमिशन 2026 की प्रक्रिया, आवश्यक दस्तावेज़, महत्वपूर्ण तिथियां और छात्रवृत्ति आवेदन कैसे करें, बताइए।`,
      icon: GraduationCap,
      color: 'from-indigo-500 to-blue-600',
      action: 'region_admission',
    },
    {
      id: '3',
      title: '🖥️ ई-मित्र सेवाएं व प्रमाण पत्र',
      desc: isGlobalLocation
        ? 'जाति, मूल निवास, आय प्रमाण पत्र, डिजिटल नागरिक पोर्टल, राशन व पैन सेवाएं'
        : `${activeRegion.shortName} (${activeRegion.citizenGuide?.portalDomain || activeRegion.domainHint}) — जाति, निवास, आय व डिजिटल सेवाएं`,
      prompt: citizenCardPrompt,
      icon: Landmark,
      color: 'from-emerald-500 to-teal-700',
      action: 'region_citizen',
    },
    {
      id: '4',
      title: '💊 दवाई की जानकारी',
      desc: 'दवाई का नाम लिखें या पर्चे की फोटो अपलोड कर उपयोग व सावधानियां जानें',
      prompt: 'किसी दवाई की जानकारी पाने के लिए उसका नाम बताइए या पट्टी/पर्चे की फोटो अपलोड कीजिए — मैं आसान हिंदी में नाम, उपयोग, साल्ट और सावधानियां बताऊंगा।',
      icon: Pill,
      color: 'from-rose-500 to-red-600',
      action: 'chat',
    },
    {
      id: '5',
      title: '🧾 बिल और रसीद रीडर',
      desc: 'बिजली बिल, राशन पर्ची या अस्पताल के बिल की फोटो समझें',
      prompt: 'बिल या रसीद की फोटो अपलोड करें — मैं कुल राशि, अंतिम तिथि और चार्जेस को सरल भाषा में समझा दूंगा।',
      icon: Receipt,
      color: 'from-amber-600 to-yellow-600',
      action: 'chat',
    },
    {
      id: '6',
      title: '📚 स्कूल होमवर्क और प्रश्न हल',
      desc: 'किताब के सवाल की फोटो खींचें या प्रश्न लिखकर आसान हल पाएं',
      prompt: 'कृपया अपना गणित, विज्ञान या किसी भी विषय का प्रश्न लिखें या फोटो अपलोड करें — मैं स्टेप-बाय-स्टेप हल समझा दूंगा।',
      icon: BookOpen,
      color: 'from-violet-500 to-purple-700',
      action: 'chat',
    },
    {
      id: '7',
      title: '🌾 सरकारी योजना और खेती सलाह',
      desc: isGlobalLocation
        ? 'PM Kisan, आयुष्मान कार्ड, सब्सिडी, खाद और फसल बीमा की जानकारी'
        : `${activeRegion.shortName} सरकारी योजनाएं, PM Kisan, आयुष्मान कार्ड व खेती सलाह`,
      prompt: `${activeRegion.shortName} की प्रमुख सरकारी योजनाओं, प्रधानमंत्री किसान सम्मान निधि और आयुष्मान भारत योजना की पात्रता, लाभ, दस्तावेज़ और आवेदन प्रक्रिया विस्तार से बताएं।`,
      icon: Sprout,
      color: 'from-green-500 to-emerald-700',
      action: 'region_schemes',
    },
    {
      id: '8',
      title: '📝 सरकारी और बैंक एप्लीकेशन',
      desc: 'बैंक खाता, बिजली बिल, छुट्टी या आरटीआई प्रार्थना पत्र लिखवाएं',
      prompt: 'बैंक में खाता/केवाईसी अपडेट या किसी सरकारी कार्यालय के लिए एक औपचारिक प्रार्थना पत्र (Application) हिंदी में लिखकर दीजिए।',
      icon: MessageSquare,
      color: 'from-purple-500 to-indigo-600',
      action: 'chat',
    },
    {
      id: '9',
      title: '💰 ब्याज, EMI और बिज़नेस हिसाब',
      desc: 'साधारण/चक्रवृद्धि ब्याज, लोन EMI कैलकुलेशन सरल तरीके से समझें',
      prompt: '₹50,000 का 2% मासिक ब्याज की दर से 8 महीने का कुल ब्याज और कुल राशि कितनी होगी, सरल तरीके से समझाइए।',
      icon: Calculator,
      color: 'from-cyan-600 to-teal-600',
      action: 'chat',
    },
    {
      id: '10',
      title: '📱 Reels स्क्रिप्ट और WhatsApp स्टेटस',
      desc: 'इंस्टाग्राम रील्स स्क्रिप्ट, दुकान के ऑफर मैसेज और पोस्ट',
      prompt: 'मेरी दुकान के नए ऑफर के लिए एक आकर्षक WhatsApp स्टेटस और Instagram Reels स्क्रिप्ट लिखिए।',
      icon: Smartphone,
      color: 'from-pink-600 to-purple-600',
      action: 'chat',
    },
    {
      id: '11',
      title: '📄 1-सेकंड रिज्यूमे / बायोडाटा',
      desc: 'तुरंत प्रोफेशनल A4 रिज्यूमे बनाएं और PDF डाउनलोड करें',
      prompt: '',
      icon: FileText,
      color: 'from-blue-500 to-indigo-600',
      action: 'resume',
    },
    {
      id: '12',
      title: '📸 ग्लोबल फोटो व साइन रिसाइज़र',
      desc: 'पासपोर्ट, वीज़ा फोटो, इंडियन फॉर्म KB साइज व A4 प्रिंट शीट',
      prompt: '',
      icon: Camera,
      color: 'from-orange-500 to-amber-600',
      action: 'photo',
    },
    {
      id: '13',
      title: '💌 निमंत्रण व बधाई कार्ड मेकर',
      desc: 'शादी, जन्मदिन या दुकान उद्घाटन का व्हाट्सएप कार्ड बनाएं',
      prompt: '',
      icon: Mail,
      color: 'from-pink-500 to-rose-600',
      action: 'invitation',
    },
    {
      id: '14',
      title: '🕉️ आज का पंचांग और शुभ मुहूर्त',
      desc: 'आज का चौघड़िया, राहुकाल और शुभ समय जानें',
      prompt: '',
      icon: Sun,
      color: 'from-amber-500 to-orange-600',
      action: 'panchang',
    },
    {
      id: '15',
      title: '📅 रोज़ाना मददगार',
      desc: 'आज की मुख्य खबरें, स्वास्थ्य टिप, सुविचार और बचत सलाह',
      prompt: '',
      icon: Calendar,
      color: 'from-cyan-500 to-blue-600',
      action: 'daily',
    },
  ];

  return (
    <div className="flex-1 flex flex-col items-center justify-center px-3 sm:px-6 py-5 sm:py-8 max-w-5xl mx-auto w-full text-center">
      {/* Brand Emblem + ChatGPT-style Assistant Header */}
      <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl sm:rounded-3xl bg-gradient-to-tr from-orange-500 via-indigo-600 to-emerald-500 flex items-center justify-center text-white shadow-xl mb-3">
        <Sparkles className="w-6 h-6 sm:w-7 sm:h-7" />
      </div>

      <h2 className={`text-xl sm:text-3xl font-extrabold tracking-tight mb-1.5 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
        SaarthiAI — स्मार्ट AI असिस्टेंट
      </h2>

      <p className={`text-xs sm:text-sm max-w-xl mb-3 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
        कोई भी सवाल पूछें या नीचे किसी कार्ड पर क्लिक करें — AI सीधे लाइव सरकारी वेबसाइटों (.gov.in / .gov) से पढ़कर आसान व सटीक जवाब देगा।
      </p>

      <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/25 text-emerald-500 text-[11px] font-semibold mb-4">
        <MapPin className="w-3.5 h-3.5 shrink-0" />
        <span>
          सक्रिय क्षेत्र: {activeRegion.label} ({activeRegion.domainHint})
        </span>
      </div>

      {/* Centered Direct-to-Chat Input Bar */}
      <form onSubmit={handleHeroSearch} className="w-full max-w-2xl mb-4">
        <div
          className={`flex items-center gap-2 p-1.5 pl-4 rounded-2xl sm:rounded-full border shadow-lg transition-all ${
            darkMode
              ? 'bg-gray-900 border-gray-700 focus-within:border-indigo-500'
              : 'bg-white border-gray-300 focus-within:border-indigo-500'
          }`}
        >
          <Search className="w-4 h-4 sm:w-5 sm:h-5 text-indigo-500 shrink-0" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              activeRegion.scope === 'india'
                ? `${activeRegion.shortName} सरकारी नौकरी, योजना, एडमिशन या कोई भी सवाल पूछें...`
                : `Ask about ${activeRegion.shortName} visa, jobs, university, or anything...`
            }
            className={`flex-1 min-w-0 bg-transparent py-2 text-xs sm:text-sm outline-none ${
              darkMode ? 'text-white placeholder-gray-500' : 'text-gray-900 placeholder-gray-400'
            }`}
          />
          <button
            type="submit"
            disabled={!searchQuery.trim()}
            className="px-4 sm:px-6 py-2.5 rounded-xl sm:rounded-full bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 disabled:opacity-50 text-white text-xs sm:text-sm font-bold shadow-sm transition-all active:scale-95 shrink-0"
          >
            पूछें
          </button>
        </div>
      </form>

      {/* Quick Trending Prompts (Direct to Chat) */}
      <div className="flex flex-wrap items-center justify-center gap-2 mb-7 w-full max-w-2xl">
        {quickSearches.map((q) => (
          <button
            key={q.label}
            type="button"
            onClick={() => onSelectSuggestion(q.query)}
            className={`px-3 py-1.5 rounded-full text-[11px] sm:text-xs font-medium border transition-all ${
              darkMode
                ? 'bg-gray-900/80 border-gray-700 text-gray-300 hover:border-indigo-500 hover:text-white'
                : 'bg-white border-gray-200 text-gray-700 hover:border-indigo-400 hover:bg-indigo-50'
            }`}
          >
            ✨ {q.label}
          </button>
        ))}
      </div>

      {/* Smart Cards Grid (All Knowledge Cards Send Directly to Chat) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 w-full max-w-4xl">
        {cards.map((item) => {
          const IconComponent = item.icon;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                if (item.action === 'apply_form') {
                  if (onStartOnlineForm) {
                    onStartOnlineForm();
                  } else {
                    onSelectSuggestion(item.prompt);
                  }
                } else if (item.action === 'region_citizen') {
                  if (onSelectRegionCard) onSelectRegionCard('citizen');
                  else onSelectSuggestion(item.prompt);
                } else if (item.action === 'region_jobs') {
                  if (onSelectRegionCard) onSelectRegionCard('jobs');
                  else onSelectSuggestion(item.prompt);
                } else if (item.action === 'region_schemes') {
                  if (onSelectRegionCard) onSelectRegionCard('schemes');
                  else onSelectSuggestion(item.prompt);
                } else if (item.action === 'region_admission') {
                  if (onSelectRegionCard) onSelectRegionCard('admission');
                  else onSelectSuggestion(item.prompt);
                } else if (item.action === 'resume') {
                  onOpenResumeModal();
                } else if (item.action === 'photo') {
                  onOpenPhotoStudioModal();
                } else if (item.action === 'invitation') {
                  onOpenInvitationModal();
                } else if (item.action === 'panchang') {
                  onOpenPanchangModal();
                } else if (item.action === 'daily') {
                  onOpenDailyHelperModal();
                } else {
                  onSelectSuggestion(item.prompt);
                }
              }}
              className={`flex flex-col p-3.5 sm:p-4 rounded-2xl border text-left transition-all duration-200 group hover:scale-[1.01] shadow-xs ${
                darkMode
                  ? 'bg-gray-800/60 border-gray-700/80 hover:bg-gray-800 hover:border-indigo-500 text-gray-200'
                  : 'bg-white border-gray-200/80 hover:bg-indigo-50/50 hover:border-indigo-300 text-gray-800'
              }`}
            >
              <div className="flex items-center gap-3 mb-1.5">
                <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${item.color} flex items-center justify-center text-white shrink-0 shadow-md group-hover:rotate-6 transition-transform`}>
                  <IconComponent className="w-4 h-4" />
                </div>
                <span className="font-bold text-xs sm:text-sm leading-tight">
                  {item.title}
                </span>
              </div>
              <p className={`text-[11px] leading-relaxed line-clamp-2 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                {item.desc}
              </p>
            </button>
          );
        })}
      </div>
    </div>
  );
};
