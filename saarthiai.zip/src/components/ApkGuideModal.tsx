import React from 'react';
import { Smartphone, X, Download, Globe, CheckCircle, ExternalLink, Code } from 'lucide-react';

interface ApkGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
}

export const ApkGuideModal: React.FC<ApkGuideModalProps> = ({ isOpen, onClose, darkMode }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className={`w-full max-w-xl max-h-[90vh] overflow-y-auto p-6 rounded-3xl shadow-2xl border transition-all ${
        darkMode ? 'bg-gray-900 border-gray-800 text-white' : 'bg-white border-gray-200 text-gray-900'
      }`}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-600 text-white flex items-center justify-center shadow-md">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-base sm:text-lg">Android APK & PWA गाइड</h2>
              <p className="text-xs text-gray-400">SaarthiAI को मोबाइल ऐप में बदलना अत्यंत सरल है</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className={`p-1.5 rounded-lg transition-colors ${darkMode ? 'hover:bg-gray-800 text-gray-400' : 'hover:bg-gray-100 text-gray-600'}`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-5 text-xs sm:text-sm">
          {/* Method 1: PWA Direct Install */}
          <div className={`p-4 rounded-2xl border ${darkMode ? 'bg-gray-800/50 border-gray-700' : 'bg-gray-50 border-gray-200'}`}>
            <h3 className="font-bold text-sm mb-2 flex items-center gap-2 text-indigo-500">
              <Globe className="w-4 h-4" />
              <span>विधि 1: सीधे मोबाइल में ऐप इंस्टॉल करें (PWA)</span>
            </h3>
            <ol className={`list-decimal list-inside space-y-1.5 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
              <li>अपने मोबाइल ब्राउज़र (Chrome या Safari) में इस वेबसाइट को खोलें।</li>
              <li>ब्राउज़र मेनू (⋮ या ⎋) पर क्लिक करें।</li>
              <li><strong>"Add to Home Screen"</strong> या <strong>"Install App"</strong> चुनें।</li>
              <li>अब SaarthiAI आपके मोबाइल होम स्क्रीन पर एक असली ऐप की तरह काम करेगा!</li>
            </ol>
          </div>

          {/* Method 2: Android APK */}
          <div className={`p-4 rounded-2xl border ${darkMode ? 'bg-gray-800/50 border-gray-700' : 'bg-gray-50 border-gray-200'}`}>
            <h3 className="font-bold text-sm mb-2 flex items-center gap-2 text-emerald-500">
              <Download className="w-4 h-4" />
              <span>विधि 2: Android APK (.apk) फ़ाइल बनाएं</span>
            </h3>
            <ol className={`list-decimal list-inside space-y-1.5 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
              <li>इस कोडबेस को GitHub पर पुश करें।</li>
              <li>मुफ्त ऑनलाइन टूल जैसे <a href="https://www.pwabuilder.com" target="_blank" rel="noreferrer" className="text-indigo-400 underline inline-flex items-center gap-1">PWABuilder <ExternalLink className="w-3 h-3" /></a> पर अपनी वेबसाइट का URL डालें।</li>
              <li><strong>"Generate APK"</strong> पर क्लिक करें।</li>
              <li>आपको कुछ ही सेकंड में तैयार `app-release.apk` मिल जाएगी जिसे आप किसी भी Android फ़ोन पर इंस्टॉल कर सकते हैं!</li>
            </ol>
          </div>

          <div className={`p-3 rounded-xl border flex items-center gap-2.5 ${
            darkMode ? 'bg-emerald-950/30 border-emerald-900/50 text-emerald-300' : 'bg-emerald-50 border-emerald-200 text-emerald-900'
          }`}>
            <CheckCircle className="w-5 h-5 shrink-0 text-emerald-500" />
            <div>
              <strong>सुविधाएं:</strong> बिना लॉगिन, बिना किसी रुकावट के, 2 सेकंड में उत्तर देने वाला Gemini 3.1 Flash Lite मॉडल हर जगह काम करता है।
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              onClick={onClose}
              className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-md transition-all"
            >
              समझ गया (Got it)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
