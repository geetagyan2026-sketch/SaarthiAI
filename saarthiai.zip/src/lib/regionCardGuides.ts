import { SourceLink } from '../types';
import { findRegionOption, isGlobalUnspecifiedLocation, RegionOption } from './regions';

export type RegionCardCategory = 'citizen' | 'jobs' | 'schemes' | 'admission';

export interface RegionCardQuickAction {
  label: string;
  prompt: string;
}

export interface SmartRegionCardReply {
  userPrompt: string;
  assistantText: string;
  sources: SourceLink[];
  quickActions: RegionCardQuickAction[];
}

interface StateExtras {
  secondaryPortal?: { name: string; domain: string; url: string };
  citizenButtons: RegionCardQuickAction[];
  recruitmentPortal: { name: string; domain: string; url: string };
  jobButtons: RegionCardQuickAction[];
  schemeHighlightHi: string;
  schemeHighlightEn: string;
  schemePortal: { name: string; domain: string; url: string };
  schemeButtons: RegionCardQuickAction[];
  admissionPortal: { name: string; domain: string; url: string };
  admissionButtons: RegionCardQuickAction[];
}

const STATE_AND_COUNTRY_EXTRAS: Record<string, StateExtras> = {
  '🇮🇳 India - Madhya Pradesh': {
    secondaryPortal: {
      name: 'MPOnline Citizen & Kiosk Portal',
      domain: 'mponline.gov.in',
      url: 'https://www.mponline.gov.in/',
    },
    citizenButtons: [
      {
        label: '🆔 समग्र आईडी (Samagra ID / e-KYC)',
        prompt: 'मध्य प्रदेश समग्र आईडी (Samagra ID) ई-केवाईसी, नया सदस्य जोड़ने व कार्ड प्रिंट करने की प्रक्रिया, फीस और पोर्टल (samagra.gov.in / mpedistrict.gov.in) बताएं',
      },
      {
        label: '📜 MP जाति प्रमाण पत्र (Caste)',
        prompt: 'मध्य प्रदेश डिजिटल जाति प्रमाण पत्र (mpedistrict.gov.in / लोक सेवा केंद्र) बनवाने के दस्तावेज़, ₹20–₹40 फीस और ऑनलाइन प्रक्रिया बताएं',
      },
      {
        label: '🏠 MP मूल निवास प्रमाण पत्र (Domicile)',
        prompt: 'मध्य प्रदेश स्थानीय / मूल निवास प्रमाण पत्र (mpedistrict.gov.in / MPOnline) बनवाने की पात्रता, दस्तावेज़, फीस और स्टेप्स बताएं',
      },
      {
        label: '💰 MP आय प्रमाण पत्र (Income)',
        prompt: 'मध्य प्रदेश आय प्रमाण पत्र (Income Certificate MP — mpedistrict.gov.in) ऑनलाइन आवेदन, स्व-घोषणा और फीस बताएं',
      },
      {
        label: '🍚 MP राशन कार्ड / पात्रता पर्ची',
        prompt: 'मध्य प्रदेश राशन कार्ड (M-Ration Mitra / पात्रता पर्ची / nfsa.gov.in) व आयुष्मान कार्ड बनवाने की प्रक्रिया और दस्तावेज़ बताएं',
      },
      {
        label: '🌐 MPOnline कियोस्क व सेवाएं (mponline.gov.in)',
        prompt: 'MPOnline (mponline.gov.in) पर उपलब्ध प्रमुख सरकारी सेवाएं, परीक्षा फॉर्म और शुल्क भुगतान की जानकारी दें',
      },
    ],
    recruitmentPortal: {
      name: 'MPPSC & MPESB (मध्य प्रदेश कर्मचारी चयन मंडल)',
      domain: 'esb.mp.gov.in',
      url: 'https://esb.mp.gov.in/',
    },
    jobButtons: [
      {
        label: '📋 MPPSC राज्य सेवा 2026 (mppsc.mp.gov.in)',
        prompt: 'मध्य प्रदेश MPPSC राज्य सेवा एवं वन सेवा 2026 की योग्यता, आयु सीमा, तिथियां, फीस और आवेदन प्रक्रिया बताएं',
      },
      {
        label: '📝 MPESB / व्यापम भर्ती 2026 (esb.mp.gov.in)',
        prompt: 'मध्य प्रदेश कर्मचारी चयन मंडल (MPESB / PEB) ग्रुप-2, ग्रुप-4, पटवारी व शिक्षक भर्ती 2026 की जानकारी और आवेदन तरीका बताएं',
      },
      {
        label: '👮 MP पुलिस / वनरक्षक भर्ती 2026',
        prompt: 'मध्य प्रदेश पुलिस कांस्टेबल, SI व वनरक्षक भर्ती 2026 की पात्रता, फिजिकल नियम, फीस और ऑनलाइन फॉर्म (MPOnline) प्रक्रिया बताएं',
      },
      {
        label: '🏛️ SSC / रेलवे / केंद्र सरकार भर्ती 2026',
        prompt: 'मध्य प्रदेश के छात्रों के लिए SSC, रेलवे RRB और केंद्र सरकार की ताज़ा 2026 भर्तियों की जानकारी दें',
      },
    ],
    schemeHighlightHi: 'लाड़ली बहना योजना, मुख्यमंत्री किसान कल्याण योजना, PM-KISAN, संभल 2.0 और आयुष्मान भारत MP',
    schemeHighlightEn: 'Ladli Behna Yojana, CM Kisan Kalyan Yojana, PM-KISAN, Sambal 2.0 & Ayushman Bharat MP',
    schemePortal: {
      name: 'PM-KISAN & MP सरकारी योजना पोर्टल (mpedistrict.gov.in)',
      domain: 'pmkisan.gov.in',
      url: 'https://pmkisan.gov.in/',
    },
    schemeButtons: [
      {
        label: '👩 लाड़ली बहना योजना (MP)',
        prompt: 'मध्य प्रदेश मुख्यमंत्री लाड़ली बहना योजना की पात्रता, किस्त, KYC और आवेदन/स्टेटस जांच प्रक्रिया बताएं',
      },
      {
        label: '🌾 CM किसान कल्याण + PM किसान (MP)',
        prompt: 'मध्य प्रदेश मुख्यमंत्री किसान कल्याण योजना व PM किसान सम्मान निधि की संयुक्त किस्त, e-KYC और पात्रता बताएं',
      },
      {
        label: '🏥 आयुष्मान भारत कार्ड MP',
        prompt: 'मध्य प्रदेश में आयुष्मान भारत कार्ड (PM-JAY) ऑनलाइन आवेदन, पात्रता जांच और डाउनलोड प्रक्रिया बताएं',
      },
      {
        label: '🪪 संभल 2.0 योजना (Sambal MP)',
        prompt: 'मध्य प्रदेश जनकल्याण संभल 2.0 योजना पंजीयन, समग्र आईडी सत्यापन, लाभ और आवेदन प्रक्रिया बताएं',
      },
    ],
    admissionPortal: {
      name: 'MP उच्च शिक्षा e-Pravesh / MPBSE बोर्ड',
      domain: 'epravesh.mponline.gov.in',
      url: 'https://epravesh.mponline.gov.in/',
    },
    admissionButtons: [
      {
        label: '🎓 MP कॉलेज एडमिशन (e-Pravesh MPOnline)',
        prompt: 'मध्य प्रदेश कॉलेज UG/PG एडमिशन (epravesh.mponline.gov.in) रजिस्ट्रेशन, चॉइस फिलिंग, दस्तावेज़ और फीस बताएं',
      },
      {
        label: '📚 MPBSE 10वीं/12वीं बोर्ड व टाइम-टेबल',
        prompt: 'मध्य प्रदेश बोर्ड (mpbse.nic.in) 10वीं व 12वीं परीक्षा फॉर्म, एडमिट कार्ड और रिज़ल्ट की जानकारी दें',
      },
      {
        label: '💰 MP छात्रवृत्ति (MPTAAS / गांव की बेटी)',
        prompt: 'मध्य प्रदेश MPTAAS छात्रवृत्ति, पोस्ट मैट्रिक स्कॉलरशिप, गांव की बेटी व मेधावी विद्यार्थी योजना आवेदन प्रक्रिया बताएं',
      },
    ],
  },

  '🇮🇳 India - Bihar': {
    secondaryPortal: {
      name: 'BPSC & EPDS Bihar Portal',
      domain: 'epds.bihar.gov.in',
      url: 'https://epds.bihar.gov.in/',
    },
    citizenButtons: [
      {
        label: '🏠 बिहार आवासीय / निवास प्रमाण पत्र (RTPS)',
        prompt: 'बिहार RTPS पोर्टल (serviceonline.bihar.gov.in) पर आवासीय (निवास) प्रमाण पत्र ऑनलाइन बनाने की फ्री (₹0) प्रक्रिया और दस्तावेज़ बताएं',
      },
      {
        label: '📜 बिहार जाति प्रमाण पत्र (RTPS Bihar)',
        prompt: 'बिहार जाति प्रमाण पत्र (Caste Certificate RTPS Bihar) ऑनलाइन आवेदन की पूरी प्रक्रिया, दस्तावेज़ और डाउनलोड तरीका बताएं',
      },
      {
        label: '💰 बिहार आय प्रमाण पत्र (Income Bihar)',
        prompt: 'बिहार आय प्रमाण पत्र (serviceonline.bihar.gov.in) अंचल स्तर पर ऑनलाइन बनवाने की प्रक्रिया व समय सीमा बताएं',
      },
      {
        label: '🪪 बिहार OBC नॉन-क्रीमी लेयर (NCL)',
        prompt: 'बिहार नॉन-क्रीमी लेयर प्रमाण पत्र (NCL Bihar / राज्य एवं केंद्र) RTPS से ऑनलाइन आवेदन कैसे करें, दस्तावेज़ बताएं',
      },
      {
        label: '🍚 बिहार राशन कार्ड (epds.bihar.gov.in)',
        prompt: 'बिहार नया राशन कार्ड ऑनलाइन आवेदन (epds.bihar.gov.in / जन परिचय), नाम जोड़ना और दस्तावेज़ बताएं',
      },
    ],
    recruitmentPortal: {
      name: 'BPSC & BSSC (बिहार लोक सेवा / कर्मचारी चयन आयोग)',
      domain: 'bpsc.bihar.gov.in',
      url: 'https://bpsc.bihar.gov.in/',
    },
    jobButtons: [
      {
        label: '📋 BPSC CCE व शिक्षक भर्ती TRE 2026',
        prompt: 'बिहार BPSC सिविल सेवा एवं शिक्षक भर्ती (BPSC TRE 2026) की योग्यता, आयु सीमा, फीस और आवेदन प्रक्रिया बताएं',
      },
      {
        label: '📝 BSSC इंटर स्तरीय / CGL भर्ती 2026',
        prompt: 'बिहार कर्मचारी चयन आयोग (BSSC Inter Level / CGL) भर्ती 2026 की पात्रता, परीक्षा पैटर्न और ऑनलाइन आवेदन प्रक्रिया बताएं',
      },
      {
        label: '👮 बिहार पुलिस कांस्टेबल / दरोगा (CSBC/BPSSC)',
        prompt: 'बिहार पुलिस सिपाही (CSBC) एवं दरोगा (BPSSC) भर्ती 2026 की योग्यता, शारीरिक मापदंड और फॉर्म प्रक्रिया बताएं',
      },
    ],
    schemeHighlightHi: 'मुख्यमंत्री उद्यमी योजना, बिहार छात्र क्रेडिट कार्ड, कन्या उत्थान योजना, PM किसान व आयुष्मान भारत',
    schemeHighlightEn: 'Mukhyamantri Udyami Yojana, Bihar Student Credit Card, Kanya Utthan & PM-KISAN',
    schemePortal: {
      name: 'PM-KISAN & बिहार लोक कल्याण पोर्टल',
      domain: 'pmkisan.gov.in',
      url: 'https://pmkisan.gov.in/',
    },
    schemeButtons: [
      {
        label: '🏭 बिहार मुख्यमंत्री उद्यमी / लघु उद्यमी योजना',
        prompt: 'बिहार मुख्यमंत्री उद्यमी एवं लघु उद्यमी योजना की पात्रता, अनुदान/लोन राशि, दस्तावेज़ और आवेदन प्रक्रिया बताएं',
      },
      {
        label: '🎓 बिहार स्टूडेंट क्रेडिट कार्ड / कन्या उत्थान',
        prompt: 'बिहार स्टूडेंट क्रेडिट कार्ड एवं मुख्यमंत्री कन्या उत्थान योजना (12वीं/स्नातक प्रोत्साहन) की आवेदन प्रक्रिया बताएं',
      },
      {
        label: '🌾 बिहार PM किसान + फसल सहायता योजना',
        prompt: 'बिहार में PM किसान सम्मान निधि व बिहार राज्य फसल सहायता योजना पंजीकरण (DBT Agriculture Bihar) की प्रक्रिया बताएं',
      },
    ],
    admissionPortal: {
      name: 'OFSS Bihar & BSEB (बिहार बोर्ड / कॉलेज प्रवेश)',
      domain: 'ofssbihar.in',
      url: 'https://ofssbihar.in/',
    },
    admissionButtons: [
      {
        label: '🎓 OFSS बिहार 11वीं व कॉलेज एडमिशन',
        prompt: 'बिहार OFSS (ofssbihar.in) व विश्वविद्यालय UG/PG एडमिशन 2026 की प्रक्रिया, दस्तावेज़ और फीस बताएं',
      },
      {
        label: '📚 BSEB बिहार बोर्ड 10वीं/12वीं व छात्रवृत्ति',
        prompt: 'बिहार बोर्ड (BSEB) परीक्षा फॉर्म व पोस्ट मैट्रिक स्कॉलरशिप (pmsonline.bihar.gov.in) आवेदन प्रक्रिया बताएं',
      },
    ],
  },

  '🇮🇳 India - Uttar Pradesh': {
    secondaryPortal: {
      name: 'UP e-Sathi & FCS Ration Portal',
      domain: 'fcs.up.gov.in',
      url: 'https://fcs.up.gov.in/',
    },
    citizenButtons: [
      {
        label: '💰 UP आय प्रमाण पत्र (e-District / e-Sathi)',
        prompt: 'उत्तर प्रदेश आय प्रमाण पत्र (edistrict.up.gov.in ई-साथी) ऑनलाइन आवेदन की ₹15 फीस, स्वप्रमाणित घोषणा पत्र और प्रक्रिया बताएं',
      },
      {
        label: '📜 UP जाति प्रमाण पत्र (Caste UP)',
        prompt: 'उत्तर प्रदेश जाति प्रमाण पत्र (edistrict.up.gov.in) बनवाने के दस्तावेज़, ₹15 ऑनलाइन फीस और स्टेप्स बताएं',
      },
      {
        label: '🏠 UP निवास प्रमाण पत्र (Domicile UP)',
        prompt: 'उत्तर प्रदेश निवास प्रमाण पत्र (Domicile Certificate UP) ऑनलाइन आवेदन प्रक्रिया व आवश्यक दस्तावेज़ बताएं',
      },
      {
        label: '🍚 UP राशन कार्ड (fcs.up.gov.in) व Family ID',
        prompt: 'उत्तर प्रदेश राशन कार्ड (fcs.up.gov.in) व एक परिवार एक पहचान (UP Family ID) आवेदन और यूनिट जोड़ने की प्रक्रिया बताएं',
      },
      {
        label: '🌾 UP भूलेख खतौनी नकल (upbhulekh.gov.in)',
        prompt: 'उत्तर प्रदेश भूलेख (upbhulekh.gov.in) से जमीन की खतौनी की नकल ऑनलाइन देखने और निकालने की प्रक्रिया बताएं',
      },
    ],
    recruitmentPortal: {
      name: 'UPPSC, UPSSSC & UP पुलिस भर्ती बोर्ड',
      domain: 'uppsc.up.nic.in',
      url: 'https://uppsc.up.nic.in/',
    },
    jobButtons: [
      {
        label: '📋 UPPSC / UPPCS व RO-ARO 2026 (OTR)',
        prompt: 'UPPSC UPPCS व RO-ARO 2026 के लिए OTR पंजीकरण, योग्यता, आयु सीमा, फीस और आवेदन प्रक्रिया बताएं',
      },
      {
        label: '👮 UP पुलिस कांस्टेबल व SI भर्ती (uppbpb.gov.in)',
        prompt: 'उत्तर प्रदेश पुलिस कांस्टेबल एवं सब-इंस्पेक्टर (UPPBPB) भर्ती 2026 की पात्रता, फिजिकल और फॉर्म प्रक्रिया बताएं',
      },
      {
        label: '📝 UPSSSC PET / लेखपाल / VDO भर्ती 2026',
        prompt: 'UPSSSC PET, लेखपाल व ग्राम विकास अधिकारी भर्ती 2026 (upsssc.gov.in) की योग्यता व आवेदन प्रक्रिया बताएं',
      },
    ],
    schemeHighlightHi: 'कन्या सुमंगला योजना, UP वृद्धावस्था/विधवा पेंशन, PM-KISAN, फ्री टैबलेट/स्मार्टफोन (स्वामी विवेकानंद युवा सशक्तिकरण)',
    schemeHighlightEn: 'Kanya Sumangala Yojana, UP Pension, PM-KISAN & UP Youth Empowerment Scheme',
    schemePortal: {
      name: 'PM-KISAN & UP सरकारी योजना पोर्टल',
      domain: 'pmkisan.gov.in',
      url: 'https://pmkisan.gov.in/',
    },
    schemeButtons: [
      {
        label: '👧 मुख्यमंत्री कन्या सुमंगला योजना (UP)',
        prompt: 'उत्तर प्रदेश मुख्यमंत्री कन्या सुमंगला योजना की पात्रता, ₹25,000 सहायता राशि और ऑनलाइन आवेदन प्रक्रिया बताएं',
      },
      {
        label: '🌾 UP किसान सम्मान निधि व खाद सब्सिडी',
        prompt: 'उत्तर प्रदेश में PM किसान सम्मान निधि, किसान पंजीकरण व UP कृषि पोर्टल पर सब्सिडी की जानकारी दें',
      },
      {
        label: '🏥 UP आयुष्मान कार्ड व राशन कार्ड लाभ',
        prompt: 'उत्तर प्रदेश में आयुष्मान भारत कार्ड व राशन कार्ड ऑनलाइन आवेदन/डाउनलोड की प्रक्रिया बताएं',
      },
    ],
    admissionPortal: {
      name: 'UP Scholarship & UPMSP (माध्यमिक शिक्षा परिषद)',
      domain: 'scholarship.up.gov.in',
      url: 'https://scholarship.up.gov.in/',
    },
    admissionButtons: [
      {
        label: '💰 UP छात्रवृत्ति (scholarship.up.gov.in)',
        prompt: 'उत्तर प्रदेश छात्रवृत्ति (UP Post/Pre Matric Scholarship) आवेदन, रिन्यूअल और स्टेटस जांच की प्रक्रिया बताएं',
      },
      {
        label: '🎓 UP कॉलेज एडमिशन व UPMSP 10वीं/12वीं',
        prompt: 'उत्तर प्रदेश बोर्ड (upmsp.edu.in) एवं राज्य विश्वविद्यालय UG/PG एडमिशन 2026 की जानकारी दें',
      },
    ],
  },

  '🇮🇳 India - Rajasthan': {
    secondaryPortal: {
      name: 'Jan Aadhaar & Rajasthan Food Portal',
      domain: 'janaadhaar.rajasthan.gov.in',
      url: 'https://janaadhaar.rajasthan.gov.in/',
    },
    citizenButtons: [
      {
        label: '🆔 जन आधार कार्ड (Jan Aadhaar / E-Mitra)',
        prompt: 'राजस्थान जन आधार कार्ड (Jan Aadhaar — sso.rajasthan.gov.in) नया पंजीयन, सदस्य जोड़ना, e-KYC और फीस बताएं',
      },
      {
        label: '🏠 राजस्थान मूल निवास प्रमाण पत्र (Bonafide)',
        prompt: 'राजस्थान मूल निवास प्रमाण पत्र (E-Mitra / SSO Rajasthan) बनवाने के दस्तावेज़, ₹30–₹50 फीस और प्रक्रिया बताएं',
      },
      {
        label: '📜 राजस्थान जाति प्रमाण पत्र (OBC/SC/ST/EWS)',
        prompt: 'राजस्थान जाति प्रमाण पत्र (E-Mitra / sso.rajasthan.gov.in) बनवाने की पात्रता, दस्तावेज़ और डिजिटल डाउनलोड प्रक्रिया बताएं',
      },
      {
        label: '💰 राजस्थान आय प्रमाण पत्र व शपथ पत्र',
        prompt: 'राजस्थान आय प्रमाण पत्र (Income Certificate E-Mitra) फॉर्म, दस्तावेज़ और फीस बताएं',
      },
      {
        label: '🍚 राजस्थान राशन कार्ड (food.rajasthan.gov.in)',
        prompt: 'राजस्थान राशन कार्ड (NFSA) नया आवेदन, नाम जुड़वाना और ई-मित्र प्रक्रिया बताएं',
      },
    ],
    recruitmentPortal: {
      name: 'RPSC & RSSB (राजस्थान लोक सेवा / कर्मचारी चयन बोर्ड)',
      domain: 'rpsc.rajasthan.gov.in',
      url: 'https://rpsc.rajasthan.gov.in/',
    },
    jobButtons: [
      {
        label: '📋 RPSC RAS / 1st & 2nd Grade शिक्षक भर्ती 2026',
        prompt: 'राजस्थान RPSC RAS, 1st Grade, 2nd Grade व SI भर्ती 2026 की योग्यता, SSO OTR और आवेदन प्रक्रिया बताएं',
      },
      {
        label: '📝 RSSB CET / पटवारी / VDO / LDC भर्ती 2026',
        prompt: 'राजस्थान कर्मचारी चयन बोर्ड (RSSB) CET, पटवारी, VDO व चतुर्थ श्रेणी भर्ती 2026 की जानकारी और आवेदन प्रक्रिया बताएं',
      },
      {
        label: '👮 राजस्थान पुलिस कांस्टेबल व REET 2026',
        prompt: 'राजस्थान पुलिस कांस्टेबल एवं REET पात्रता परीक्षा 2026 की योग्यता, तिथियां और फॉर्म प्रक्रिया बताएं',
      },
    ],
    schemeHighlightHi: 'लाडो प्रोत्साहन योजना, मुख्यमंत्री किसान सम्मान निधि राजस्थान, मुख्यमंत्री आयुष्मान आरोग्य योजना, कालीबाई भील स्कूटी योजना',
    schemeHighlightEn: 'Lado Protsahan Yojana, CM Kisan Samman Nidhi Rajasthan & Mukhyamantri Ayushman Arogya',
    schemePortal: {
      name: 'राजस्थान जन कल्याण व किसान पोर्टल (sso.rajasthan.gov.in)',
      domain: 'sso.rajasthan.gov.in',
      url: 'https://sso.rajasthan.gov.in/',
    },
    schemeButtons: [
      {
        label: '🌾 राजस्थान CM किसान + PM किसान निधि',
        prompt: 'राजस्थान मुख्यमंत्री किसान सम्मान निधि व PM किसान योजना की संयुक्त किस्त, जन आधार लिंक और आवेदन प्रक्रिया बताएं',
      },
      {
        label: '🏥 मुख्यमंत्री आयुष्मान आरोग्य योजना (MAA)',
        prompt: 'राजस्थान मुख्यमंत्री आयुष्मान आरोग्य (MAA) स्वास्थ्य बीमा योजना पंजीकरण, जन आधार पात्रता और लाभ बताएं',
      },
      {
        label: '👧 राजस्थान लाडो प्रोत्साहन व स्कूटी योजना',
        prompt: 'राजस्थान लाडो प्रोत्साहन योजना एवं कालीबाई भील मेधावी छात्रा स्कूटी योजना की पात्रता और आवेदन बताएं',
      },
    ],
    admissionPortal: {
      name: 'राजस्थान कॉलेज DCE (hte.rajasthan.gov.in) व RBSE',
      domain: 'hte.rajasthan.gov.in',
      url: 'https://hte.rajasthan.gov.in/',
    },
    admissionButtons: [
      {
        label: '🎓 राजस्थान सरकारी कॉलेज एडमिशन (DCE)',
        prompt: 'राजस्थान सरकारी कॉलेज UG/PG एडमिशन (hte.rajasthan.gov.in) SSO से फॉर्म भरने की प्रक्रिया, दस्तावेज़ और तिथियां बताएं',
      },
      {
        label: '💰 राजस्थान उत्तर मैट्रिक छात्रवृत्ति (SJE)',
        prompt: 'राजस्थान समाज कल्याण (SJE) उत्तर मैट्रिक छात्रवृत्ति की पात्रता, जन आधार आवश्यक नियम और आवेदन प्रक्रिया बताएं',
      },
    ],
  },

  '🇦🇪 United Arab Emirates (UAE)': {
    secondaryPortal: {
      name: 'UAE Government Official Portal (U.AE)',
      domain: 'u.ae',
      url: 'https://u.ae/',
    },
    citizenButtons: [
      {
        label: '🪪 Emirates ID Application & Renewal (ICP)',
        prompt: 'Explain UAE Emirates ID new application & renewal on icp.gov.ae / u.ae with AED fees, biometrics, and required documents.',
      },
      {
        label: '🌟 UAE Golden Visa (10-Year Residency)',
        prompt: 'Explain UAE 10-Year Golden Visa eligibility, AED fee breakdown, required documents, and official application on icp.gov.ae / gdrfad.gov.ae.',
      },
      {
        label: '💼 MOHRE Work Permit & Labour Contract',
        prompt: 'Explain UAE MOHRE work permit, labour card, and employment visa rules on mohre.gov.ae.',
      },
      {
        label: '🔐 UAE Pass Digital Identity Setup',
        prompt: 'How to register and verify UAE Pass app (uaepass.ae) for UAE government services using Emirates ID?',
      },
    ],
    recruitmentPortal: {
      name: 'MOHRE & Nafis UAE Employment Portal',
      domain: 'mohre.gov.ae',
      url: 'https://www.mohre.gov.ae/',
    },
    jobButtons: [
      {
        label: '💼 UAE Work Visa & MOHRE Labour Rules 2026',
        prompt: 'Explain UAE employment visa rules, skill levels, MOHRE work permit verification, and labour rights on mohre.gov.ae.',
      },
      {
        label: '🌟 UAE Jobseeker & Freelance / Green Visa',
        prompt: 'Explain UAE 60/90/120-day Jobseeker Visa & 5-Year Green Visa requirements and AED fees on icp.gov.ae.',
      },
    ],
    schemeHighlightHi: 'UAE सोशल सपोर्ट, फेडरल बेनिफिट्स (u.ae), ILOE जॉब लॉस इंश्योरेंस और गोल्डन वीज़ा सुविधाएं',
    schemeHighlightEn: 'UAE ILOE Involuntary Loss of Employment Insurance, Social Support & Federal Benefits (u.ae)',
    schemePortal: {
      name: 'U.AE Official Federal Services & Benefits',
      domain: 'u.ae',
      url: 'https://u.ae/',
    },
    schemeButtons: [
      {
        label: '🛡️ UAE ILOE Unemployment Insurance',
        prompt: 'Explain mandatory UAE ILOE (Involuntary Loss of Employment) insurance registration, AED 5/10 monthly plans, and claim process.',
      },
      {
        label: '🚗 UAE Driving Licence & RTA Services',
        prompt: 'Explain how to apply for a UAE Driving Licence (RTA Dubai / TAMM Abu Dhabi), AED fees, eye test, and road test steps.',
      },
    ],
    admissionPortal: {
      name: 'UAE Ministry of Education (MOE) Higher Education',
      domain: 'moe.gov.ae',
      url: 'https://www.moe.gov.ae/',
    },
    admissionButtons: [
      {
        label: '🎓 UAE University Admission & Student Visa',
        prompt: 'Explain UAE university admission, degree equivalency (moe.gov.ae), and UAE Student Visa requirements.',
      },
    ],
  },
};

function buildGenericRegionExtras(region: RegionOption): StateExtras {
  const guide = region.citizenGuide;
  const portalUrl = guide?.portalUrl || region.portals[0]?.url || 'https://services.india.gov.in/';
  const portalDomain = guide?.portalDomain || region.portals[0]?.domain || region.domainHint;
  const portalName = guide?.portalName || region.portals[0]?.name || `${region.shortName} Official Portal`;
  const recPortal =
    region.portals.find((p) => /recruit|psc|ssb|visa|immigration|labour|work/i.test(p.category)) ||
    region.portals[1] ||
    region.portals[0] || {
      name: portalName,
      domain: portalDomain,
      url: portalUrl,
    };

  if (region.scope === 'india') {
    return {
      citizenButtons: [
        {
          label: `🏠 ${region.shortName} मूल निवास प्रमाण पत्र (Domicile)`,
          prompt: `${region.shortName} के आधिकारिक पोर्टल (${portalDomain}) पर मूल निवास प्रमाण पत्र (Domicile Certificate) बनवाने की फीस, दस्तावेज़ और प्रक्रिया बताएं`,
        },
        {
          label: `📜 ${region.shortName} जाति प्रमाण पत्र (Caste)`,
          prompt: `${region.shortName} के आधिकारिक पोर्टल (${portalDomain}) पर जाति प्रमाण पत्र (Caste Certificate) बनवाने की फीस, दस्तावेज़ और प्रक्रिया बताएं`,
        },
        {
          label: `💰 ${region.shortName} आय प्रमाण पत्र (Income)`,
          prompt: `${region.shortName} के आधिकारिक पोर्टल (${portalDomain}) पर आय प्रमाण पत्र (Income Certificate) बनवाने की फीस, दस्तावेज़ और प्रक्रिया बताएं`,
        },
        {
          label: `🍚 ${region.shortName} राशन कार्ड व आयुष्मान कार्ड`,
          prompt: `${region.shortName} में राशन कार्ड और आयुष्मान भारत कार्ड ऑनलाइन आवेदन की प्रक्रिया, फीस और दस्तावेज़ बताएं`,
        },
      ],
      recruitmentPortal: recPortal,
      jobButtons: [
        {
          label: `📋 ${region.shortName} राज्य सरकारी भर्ती 2026 (${recPortal.domain})`,
          prompt: `${region.shortName} राज्य लोक सेवा आयोग / भर्ती पोर्टल (${recPortal.domain}) पर 2026 की ताज़ा सरकारी भर्तियों की योग्यता, तिथियां और आवेदन प्रक्रिया बताएं`,
        },
        {
          label: '🏛️ SSC / UPSC / रेलवे 2026 भर्ती',
          prompt: `${region.shortName} के अभ्यर्थियों के लिए SSC, UPSC और रेलवे RRB 2026 की प्रमुख भर्तियों की जानकारी बताएं`,
        },
      ],
      schemeHighlightHi: `${region.shortName} राज्य की प्रमुख कल्याणकारी योजनाएं, PM किसान निधि, आयुष्मान भारत व छात्रवृत्ति`,
      schemeHighlightEn: `${region.shortName} State Welfare Schemes, PM-KISAN & Ayushman Bharat`,
      schemePortal: {
        name: `${region.shortName} नागरिक व कल्याण पोर्टल`,
        domain: portalDomain,
        url: portalUrl,
      },
      schemeButtons: [
        {
          label: `🌾 ${region.shortName} सरकारी योजनाएं 2026`,
          prompt: `${region.shortName} की प्रमुख राज्य सरकारी योजनाओं, पात्रता, लाभ और आवेदन प्रक्रिया (${portalDomain}) की पूरी जानकारी बताएं`,
        },
        {
          label: '🌾 PM किसान + आयुष्मान भारत योजना',
          prompt: 'प्रधानमंत्री किसान सम्मान निधि और आयुष्मान भारत योजना की पात्रता, किस्त, दस्तावेज़ और आवेदन प्रक्रिया बताएं',
        },
      ],
      admissionPortal: {
        name: `${region.shortName} शिक्षा व प्रवेश पोर्टल`,
        domain: portalDomain,
        url: portalUrl,
      },
      admissionButtons: [
        {
          label: `🎓 ${region.shortName} स्कूल व कॉलेज एडमिशन 2026`,
          prompt: `${region.shortName} में स्कूल व कॉलेज एडमिशन 2026, छात्रवृत्ति और आवश्यक दस्तावेज़ों की जानकारी दें`,
        },
      ],
    };
  }

  return {
    citizenButtons: [
      {
        label: `🪪 ${region.shortName} Citizen ID & Certificates (${portalDomain})`,
        prompt: `Explain how to apply for citizen ID, civil certificates, and digital login on ${region.shortName} official portal (${portalDomain}) with fees and documents.`,
      },
      {
        label: `🛂 ${region.shortName} Visa & Residency Rules`,
        prompt: `Explain ${region.shortName} official visa, residency permit, local currency fees, and document checklist on ${recPortal.domain}.`,
      },
      {
        label: `🚗 ${region.shortName} Driving Licence & Tax ID`,
        prompt: `Explain how residents apply for a Driving Licence and Tax ID in ${region.shortName} (${portalDomain}) with fees.`,
      },
    ],
    recruitmentPortal: recPortal,
    jobButtons: [
      {
        label: `💼 ${region.shortName} Work Visa & Skilled Jobs`,
        prompt: `Explain ${region.shortName} skilled worker visa, work permit rules, and public job portals (${recPortal.domain}).`,
      },
      {
        label: `🏛️ ${region.shortName} Public Sector & Official Portal`,
        prompt: `How to search government and licensed employment services in ${region.shortName} via ${portalDomain}?`,
      },
    ],
    schemeHighlightHi: `${region.shortName} की प्रमुख सरकारी नागरिक सुविधाएं, हेल्थकेयर, टैक्स क्रेडिट और सामाजिक सुरक्षा योजनाएं (${portalDomain})`,
    schemeHighlightEn: `${region.shortName} public benefits, healthcare, tax credits & social security on ${portalDomain}`,
    schemePortal: {
      name: portalName,
      domain: portalDomain,
      url: portalUrl,
    },
    schemeButtons: [
      {
        label: `🏛️ ${region.shortName} Public Benefits & Healthcare`,
        prompt: `Explain major public benefits, healthcare coverage, and tax/family support programs in ${region.shortName} on ${portalDomain}.`,
      },
    ],
    admissionPortal: {
      name: `${region.shortName} Higher Education & Student Visa`,
      domain: recPortal.domain,
      url: recPortal.url,
    },
    admissionButtons: [
      {
        label: `🎓 ${region.shortName} University Admission & Student Visa`,
        prompt: `Explain ${region.shortName} university admission requirements, tuition/visa fees, and scholarships for international & domestic students.`,
      },
    ],
  };
}

export function buildSmartRegionCardReply(
  category: RegionCardCategory,
  locationValue: string,
  language: string
): SmartRegionCardReply {
  const isEnglish = language === 'en';
  const region = findRegionOption(locationValue);
  const isGlobalUnset = isGlobalUnspecifiedLocation(locationValue);
  const isAllIndia = region.value === '🇮🇳 India - All India (Central)';

  // 1. Only ask to pick a State/Country if the Header is literally on Global / World OR All India (for state-specific citizen certs)
  if (isGlobalUnset && category === 'citizen') {
    return {
      userPrompt: isEnglish
        ? '🖥️ Digital Citizen Services & Certificates (e-Mitra / e-District / Global Portals)'
        : '🖥️ ई-मित्र / e-District व सरकारी प्रमाण पत्र सेवाएं',
      assistantText: isEnglish
        ? [
            `### 🌍 Select Your State (India) or Country`,
            `Your active header region is currently **Global / World**. Please tap one of the quick buttons below or type your state/country name in chat (or pick it from the top **Region Selector**) to open its exact official portal, fees, and services:`,
          ].join('\n')
        : [
            `### 🌍 कृपया अपना राज्य (भारत) या देश चुनें`,
            `अभी हेडर में **Global / World** सेट है। नीचे अपने राज्य या देश के बटन पर क्लिक करें (या चैट में नाम लिखें / ऊपर **Region Selector** से चुनें) — मैं तुरंत उसी राज्य का असली पोर्टल, फीस और सेवाएं खोल दूंगा:`,
          ].join('\n'),
      sources: [],
      quickActions: [
        {
          label: '🇮🇳 मध्य प्रदेश (MPOnline / e-District MP)',
          prompt: 'मध्य प्रदेश (MPOnline / mpedistrict.gov.in) पर समग्र, जाति, मूल निवास, आय प्रमाण पत्र की फीस, दस्तावेज़ और प्रक्रिया बताएं',
        },
        {
          label: '🇮🇳 बिहार (RTPS Bihar)',
          prompt: 'बिहार RTPS (serviceonline.bihar.gov.in) पर आवासीय, जाति और आय प्रमाण पत्र बनवाने की फीस, दस्तावेज़ और प्रक्रिया बताएं',
        },
        {
          label: '🇮🇳 उत्तर प्रदेश (e-District UP)',
          prompt: 'उत्तर प्रदेश e-District (edistrict.up.gov.in) पर आय, जाति व निवास प्रमाण पत्र की फीस, दस्तावेज़ और प्रक्रिया बताएं',
        },
        {
          label: '🇮🇳 राजस्थान (E-Mitra / SSO)',
          prompt: 'राजस्थान ई-मित्र / SSO (sso.rajasthan.gov.in) पर जन आधार, मूल निवास, जाति व आय प्रमाण पत्र की फीस और प्रक्रिया बताएं',
        },
        {
          label: '🇮🇳 महाराष्ट्र (Aaple Sarkar)',
          prompt: 'महाराष्ट्र आपले सरकार (aaplesarkar.mahaonline.gov.in) पर रहिवासी, जात व उत्पन्न प्रमाण पत्र की फीस और प्रक्रिया बताएं',
        },
        {
          label: '🇦🇪 UAE (UAE Pass / Emirates ID)',
          prompt: 'UAE official portal (u.ae / icp.gov.ae) Emirates ID, Golden Visa & citizen services fees, documents and steps',
        },
      ],
    };
  }

  const extras = STATE_AND_COUNTRY_EXTRAS[region.value] || buildGenericRegionExtras(region);
  const guide = region.citizenGuide;

  // 2. Citizen Services & Certificates (e-Mitra / MPOnline / RTPS / e-District / Global IDs)
  if (category === 'citizen') {
    const portalUrl = guide?.portalUrl || region.portals[0]?.url || 'https://services.india.gov.in/';
    const portalDomain = guide?.portalDomain || region.portals[0]?.domain || region.domainHint;
    const portalName = guide?.portalName || region.portals[0]?.name || region.label;

    const secondaryLineHi = extras.secondaryPortal
      ? `\n• **अतिरिक्त आधिकारिक पोर्टल:** **${extras.secondaryPortal.name}** (**${extras.secondaryPortal.domain}**)`
      : '';
    const secondaryLineEn = extras.secondaryPortal
      ? `\n• **Additional Official Portal:** **${extras.secondaryPortal.name}** (**${extras.secondaryPortal.domain}**)`
      : '';

    const stepsListHi = (guide?.stepsHi || []).map((s, i) => `  ${i + 1}. ${s}`);
    const stepsListEn = (guide?.stepsEn || []).map((s, i) => `  ${i + 1}. ${s}`);

    const userPrompt = isEnglish
      ? `🖥️ ${region.shortName} Digital Citizen Services & Certificates (${portalDomain})`
      : `🖥️ ${region.shortName} नागरिक सेवाएं व प्रमाण पत्र (${portalDomain})`;

    const assistantText = isEnglish
      ? [
          `### 🏛️ ${region.label} — Official Citizen Services Portal`,
          ``,
          `• **Primary Official Portal:** **${portalName}** (**${portalDomain}**)${secondaryLineEn}`,
          `• **Official Government Fees:** ${guide?.feeSummaryEn || 'Verified portal rates'}`,
          `• **Required Documents:** ${guide?.documentsEn || 'Government Photo ID & Address Proof'}`,
          `• **Step-by-Step Application Process:**`,
          ...stepsListEn,
          ``,
          `👇 **Tap any service below for instant step-by-step details:**`,
        ].join('\n')
      : [
          `### 🏛️ ${region.label} — आधिकारिक डिजिटल नागरिक सेवाएं व प्रमाण पत्र`,
          ``,
          `• **प्रमुख आधिकारिक पोर्टल:** **${portalName}** (**${portalDomain}**)${secondaryLineHi}`,
          `• **असली सरकारी फीस:** ${guide?.feeSummaryHi || 'पोर्टल के निर्धारित सरकारी शुल्क के अनुसार'}`,
          `• **ज़रूरी डॉक्यूमेंट:** ${guide?.documentsHi || 'आधार कार्ड, निवास व आय प्रमाण और फोटो'}`,
          `• **स्टेप-बाय-स्टेप आवेदन प्रक्रिया:**`,
          ...stepsListHi,
          ``,
          `👇 **नीचे ${region.shortName} की प्रमुख सेवाओं पर सीधे क्लिक करें:**`,
        ].join('\n');

    return {
      userPrompt,
      assistantText,
      sources: [{ title: portalDomain, uri: portalUrl }],
      quickActions: isAllIndia
        ? [
            {
              label: '🇮🇳 मध्य प्रदेश (MPOnline / e-District MP)',
              prompt: 'मध्य प्रदेश (mpedistrict.gov.in / mponline.gov.in) पर समग्र, जाति, निवास, आय प्रमाण पत्र की फीस और प्रक्रिया बताएं',
            },
            {
              label: '🇮🇳 बिहार (RTPS Bihar)',
              prompt: 'बिहार RTPS (serviceonline.bihar.gov.in) आवासीय, जाति, आय प्रमाण पत्र की फीस व प्रक्रिया बताएं',
            },
            {
              label: '🇮🇳 उत्तर प्रदेश (e-District UP)',
              prompt: 'उत्तर प्रदेश e-District (edistrict.up.gov.in) आय, जाति, निवास प्रमाण पत्र की फीस व प्रक्रिया बताएं',
            },
            {
              label: '🇮🇳 राजस्थान (E-Mitra / SSO)',
              prompt: 'राजस्थान ई-मित्र / SSO (sso.rajasthan.gov.in) जन आधार, मूल निवास, जाति प्रमाण पत्र प्रक्रिया बताएं',
            },
            ...extras.citizenButtons.slice(0, 2),
          ]
        : extras.citizenButtons,
    };
  }

  // 3. Govt Jobs / Recruitment
  if (category === 'jobs') {
    const rec = extras.recruitmentPortal;
    if (isGlobalUnset) {
      return {
        userPrompt: '🏛️ सरकारी नौकरी / भर्ती अलर्ट 2026',
        assistantText: [
          `### 💼 सरकारी नौकरी व करियर पोर्टल (Global & India)`,
          `ऊपर अभी **Global / World** चुना हुआ है — नीचे अपना राज्य या देश चुनकर सीधे ताज़ा भर्तियां, योग्यता व आवेदन लिंक देखें:`,
        ].join('\n'),
        sources: [{ title: 'ssc.gov.in', uri: 'https://ssc.gov.in/' }],
        quickActions: [
          {
            label: '🇮🇳 मध्य प्रदेश भर्ती (MPPSC / MPESB)',
            prompt: 'मध्य प्रदेश की 2026 की ताज़ा सरकारी नौकरी भर्तियां (MPPSC, MPESB, पुलिस, शिक्षक) योग्यता, तिथियां और आवेदन प्रक्रिया बताएं',
          },
          {
            label: '🇮🇳 बिहार भर्ती (BPSC / BSSC / पुलिस)',
            prompt: 'बिहार की 2026 की ताज़ा सरकारी नौकरी भर्तियां (BPSC, BSSC, CSBC) योग्यता, तिथियां और आवेदन प्रक्रिया बताएं',
          },
          {
            label: '🇮🇳 उत्तर प्रदेश भर्ती (UPPSC / UP Police)',
            prompt: 'उत्तर प्रदेश की 2026 की ताज़ा सरकारी नौकरी भर्तियां (UPPSC, UPSSSC, UP Police) योग्यता और आवेदन प्रक्रिया बताएं',
          },
          {
            label: '🇮🇳 राजस्थान भर्ती (RPSC / RSSB)',
            prompt: 'राजस्थान की 2026 की ताज़ा सरकारी नौकरी भर्तियां (RPSC, RSSB, REET) योग्यता, तिथियां और आवेदन प्रक्रिया बताएं',
          },
          {
            label: '🇮🇳 UPSC / SSC / Railway 2026',
            prompt: 'केंद्र सरकार की UPSC, SSC और रेलवे RRB 2026 की ताज़ा भर्तियों की योग्यता, फीस और आवेदन प्रक्रिया बताएं',
          },
          {
            label: '🇦🇪 UAE Jobs & Work Visa (MOHRE)',
            prompt: 'Explain UAE Work Permit, Jobseeker Visa, and employment rules on mohre.gov.ae and icp.gov.ae.',
          },
        ],
      };
    }

    return {
      userPrompt: isEnglish
        ? `🏛️ ${region.shortName} Official Jobs & Recruitment 2026`
        : `🏛️ ${region.shortName} सरकारी नौकरी / भर्ती 2026`,
      assistantText: isEnglish
        ? [
            `### 💼 ${region.label} — Official Jobs & Recruitment Hub`,
            ``,
            `• **Primary Recruitment Portal:** **${rec.name}** (**${rec.domain}**)`,
            `• **Active Scope:** Showing verified portals and career guides specifically for **${region.shortName}**.`,
            `• **Important Tip:** Always verify official notification PDF, eligibility, age limits, and fee directly on **${rec.domain}** via the green button below.`,
            ``,
            `👇 **Select a recruitment category for ${region.shortName}:**`,
          ].join('\n')
        : [
            `### 💼 ${region.label} — आधिकारिक सरकारी नौकरी व भर्ती केंद्र`,
            ``,
            `• **प्रमुख भर्ती पोर्टल:** **${rec.name}** (**${rec.domain}**)`,
            `• **सक्रिय क्षेत्र:** **${region.shortName}** के लिए चयनित आधिकारिक भर्ती जानकारी व पोर्टल लिंक।`,
            `• **आवेदन टिप:** फॉर्म भरने से पहले नीचे दिए हरे बटन से **${rec.domain}** पर ताज़ा नोटिफिकेशन, आयु सीमा और अंतिम तारीख अवश्य जांचें।`,
            ``,
            `👇 **${region.shortName} की प्रमुख भर्तियां देखने के लिए नीचे क्लिक करें:**`,
          ].join('\n'),
      sources: [{ title: rec.domain, uri: rec.url }],
      quickActions: extras.jobButtons,
    };
  }

  // 4. Govt Schemes & Farming
  if (category === 'schemes') {
    const sch = extras.schemePortal;
    return {
      userPrompt: isEnglish
        ? `🌾 ${region.shortName} Government Schemes & Benefits`
        : `🌾 ${region.shortName} सरकारी योजनाएं और खेती सलाह`,
      assistantText: isEnglish
        ? [
            `### 🌾 ${region.label} — Official Government Schemes & Welfare Guide`,
            ``,
            `• **Key Highlighted Schemes:** ${extras.schemeHighlightEn}`,
            `• **Official Portal:** **${sch.name}** (**${sch.domain}**)`,
            `• **Required Basic IDs:** ${guide?.documentsEn || 'Government ID & Bank Account'}`,
            ``,
            `👇 **Tap any scheme below to check eligibility, benefits & apply steps:**`,
          ].join('\n')
        : [
            `### 🌾 ${region.label} — प्रमुख सरकारी योजनाएं और लाभ गाइड`,
            ``,
            `• **प्रमुख योजनाएं:** ${extras.schemeHighlightHi}`,
            `• **आधिकारिक पोर्टल:** **${sch.name}** (**${sch.domain}**)`,
            `• **सामान्य दस्तावेज़:** ${guide?.documentsHi || 'आधार कार्ड, समग्र/परिवार आईडी, बैंक पासबुक व मोबाइल नंबर'}`,
            ``,
            `👇 **जिस योजना की पूरी पात्रता व फॉर्म प्रक्रिया जाननी है, उस पर क्लिक करें:**`,
          ].join('\n'),
      sources: [{ title: sch.domain, uri: sch.url }],
      quickActions: extras.schemeButtons,
    };
  }

  // 5. School / College Admission & Scholarships
  const adm = extras.admissionPortal;
  return {
    userPrompt: isEnglish
      ? `🎓 ${region.shortName} School, College Admission & Scholarships`
      : `🎓 ${region.shortName} स्कूल / कॉलेज एडमिशन और छात्रवृत्ति`,
    assistantText: isEnglish
      ? [
          `### 🎓 ${region.label} — Admission & Scholarship Portal`,
          ``,
          `• **Official Admission Portal:** **${adm.name}** (**${adm.domain}**)`,
          `• **General Checklist:** Previous Marksheet, Transfer Certificate (TC), ID Card, Category/Domicile/Income certificates, Photo & Signature.`,
          ``,
          `👇 **Select an option below for full eligibility, deadlines & steps:**`,
        ].join('\n')
      : [
          `### 🎓 ${region.label} — स्कूल / कॉलेज एडमिशन व छात्रवृत्ति गाइड`,
          ``,
          `• **प्रमुख प्रवेश पोर्टल:** **${adm.name}** (**${adm.domain}**)`,
          `• **ज़रूरी दस्तावेज़:** पिछली कक्षा की मार्कशीट, TC (स्थानांतरण प्रमाण पत्र), आधार/आईडी, जाति/मूल निवास/आय प्रमाण पत्र, फोटो व साइन।`,
          ``,
          `👇 **नीचे दिए विकल्प चुनें:**`,
        ].join('\n'),
    sources: [{ title: adm.domain, uri: adm.url }],
    quickActions: extras.admissionButtons,
  };
}
