export type RegionScope = 'india' | 'global';

export interface LanguageOption {
  code: string;
  label: string;
  speechCode: string;
}

export interface RegionPortalLink {
  name: string;
  url: string;
  domain: string;
  category: string;
  description: string;
}

export interface CitizenPortalGuide {
  portalName: string;
  portalDomain: string;
  portalUrl: string;
  feeSummaryHi: string;
  feeSummaryEn: string;
  documentsHi: string;
  documentsEn: string;
  stepsHi: string[];
  stepsEn: string[];
}

export interface RegionOption {
  value: string;
  label: string;
  flag: string;
  scope: RegionScope;
  shortName: string;
  domainHint: string;
  portals: RegionPortalLink[];
  citizenGuide?: CitizenPortalGuide;
}

export const SUPPORTED_LANGUAGES: LanguageOption[] = [
  { code: 'hi', label: 'हिंदी (Hindi)', speechCode: 'hi-IN' },
  { code: 'en', label: 'English (Global)', speechCode: 'en-US' },
  { code: 'ar', label: 'العربية (Arabic)', speechCode: 'ar-SA' },
  { code: 'es', label: 'Español (Spanish)', speechCode: 'es-ES' },
  { code: 'fr', label: 'Français (French)', speechCode: 'fr-FR' },
  { code: 'de', label: 'Deutsch (German)', speechCode: 'de-DE' },
  { code: 'ja', label: '日本語 (Japanese)', speechCode: 'ja-JP' },
  { code: 'pa', label: 'ਪੰਜਾਬੀ (Punjabi)', speechCode: 'pa-IN' },
  { code: 'bn', label: 'বাংলা (Bengali)', speechCode: 'bn-IN' },
  { code: 'mr', label: 'मराठी (Marathi)', speechCode: 'mr-IN' },
  { code: 'ta', label: 'தமிழ் (Tamil)', speechCode: 'ta-IN' },
  { code: 'te', label: 'తెలుగు (Telugu)', speechCode: 'te-IN' },
  { code: 'gu', label: 'ગુજરાતી (Gujarati)', speechCode: 'gu-IN' },
  { code: 'ur', label: 'اردو (Urdu)', speechCode: 'ur-PK' },
];

export const SPEECH_LANG_MAP: Record<string, string> = SUPPORTED_LANGUAGES.reduce(
  (acc, item) => {
    acc[item.code] = item.speechCode;
    return acc;
  },
  {} as Record<string, string>
);

export const INDIA_REGIONS: RegionOption[] = [
  {
    value: '🇮🇳 India - All India (Central)',
    label: '🇮🇳 All India (Central Govt)',
    flag: '🇮🇳',
    scope: 'india',
    shortName: 'All India',
    domainHint: 'services.india.gov.in',
    portals: [
      {
        name: 'National Government Services Portal (India)',
        url: 'https://services.india.gov.in/',
        domain: 'services.india.gov.in',
        category: 'Central Citizen Portal',
        description: 'भारत सरकार का राष्ट्रीय नागरिक सेवा पोर्टल — सभी राज्यों के जाति, मूल निवास, आय प्रमाण पत्र, पैन, पासपोर्ट व योजनाओं के लिंक।',
      },
      {
        name: 'National Portal of India — भारत सरकार',
        url: 'https://www.india.gov.in/',
        domain: 'india.gov.in',
        category: 'Central Portal',
        description: 'भारत सरकार की सभी सरकारी योजनाओं, भर्तियों, सेवाओं और विभागों का एकीकृत राष्ट्रीय पोर्टल।',
      },
      {
        name: 'UPSC & SSC Official Recruitment Portals',
        url: 'https://upsc.gov.in/',
        domain: 'upsc.gov.in',
        category: 'Central Jobs',
        description: 'केंद्र सरकार की IAS/UPSC व SSC भर्तियों के आधिकारिक विज्ञापन, परीक्षा तिथि और आवेदन लिंक।',
      },
    ],
    citizenGuide: {
      portalName: 'National Government Services Portal (भारत सरकार)',
      portalDomain: 'services.india.gov.in',
      portalUrl: 'https://services.india.gov.in/',
      feeSummaryHi: 'राज्य व सेवा के अनुसार ₹0 से ₹50 (e-District / CSC / ServicePlus ऑनलाइन शुल्क)',
      feeSummaryEn: '₹0 to ₹50 depending on the state e-District / ServicePlus / CSC service',
      documentsHi: 'आधार कार्ड (मोबाइल लिंक), राशन/परिवार कार्ड, पते व आय का प्रमाण, पासपोर्ट साइज फोटो और स्व-घोषणा पत्र',
      documentsEn: 'Aadhaar Card (mobile-linked), Ration/Family ID, Address & Income proof, Passport photo, and Self-declaration',
      stepsHi: [
        'नीचे दिए हरे बटन से **services.india.gov.in** खोलें और अपना राज्य व आवश्यक नागरिक सेवा (जैसे जाति/निवास/आय प्रमाण पत्र) चुनें।',
        'यह पोर्टल आपको सीधे आपके राज्य के आधिकारिक e-District / ServicePlus / MeeSeva / Aaple Sarkar पोर्टल पर ले जाएगा।',
        'मोबाइल OTP / DigiLocker से लॉगिन कर दस्तावेज़ अपलोड करें, लागू शुल्क जमा करें और डिजिटल प्रमाण पत्र डाउनलोड करें।',
      ],
      stepsEn: [
        'Open **services.india.gov.in** via the button below and select your state and required citizen service.',
        'You will be redirected to your state’s official e-District / ServicePlus / citizen portal.',
        'Sign in with Mobile OTP / DigiLocker, upload documents, pay the applicable fee, and download the signed PDF certificate.',
      ],
    },
  },
  {
    value: '🇮🇳 India - Rajasthan',
    label: '🇮🇳 Rajasthan (राजस्थान)',
    flag: '🇮🇳',
    scope: 'india',
    shortName: 'Rajasthan',
    domainHint: 'sso.rajasthan.gov.in',
    portals: [
      {
        name: 'e-Mitra / SSO Rajasthan — आधिकारिक ई-मित्र पोर्टल',
        url: 'https://sso.rajasthan.gov.in/',
        domain: 'sso.rajasthan.gov.in',
        category: 'e-Mitra & Citizen',
        description: 'राजस्थान SSO व ई-मित्र पोर्टल — जन आधार, मूल निवास, जाति प्रमाण पत्र, छात्रवृत्ति व सभी राज्य सरकारी फॉर्म।',
      },
      {
        name: 'RPSC — राजस्थान लोक सेवा आयोग',
        url: 'https://rpsc.rajasthan.gov.in/',
        domain: 'rpsc.rajasthan.gov.in',
        category: 'State Recruitment',
        description: 'RAS, 1st/2nd Grade Teacher, SI व अन्य RPSC भर्तियों के नोटिफिकेशन, सिलेबस और एडमिट कार्ड।',
      },
    ],
    citizenGuide: {
      portalName: 'Rajasthan E-Mitra / SSO Portal',
      portalDomain: 'sso.rajasthan.gov.in',
      portalUrl: 'https://sso.rajasthan.gov.in/',
      feeSummaryHi: 'ई-मित्र टोकन शुल्क ₹30 से ₹50 (जन आधार, मूल निवास, जाति व आय प्रमाण पत्र)',
      feeSummaryEn: '₹30 to ₹50 E-Mitra token fee for Jan Aadhaar, Domicile, Caste, and Income certificates',
      documentsHi: 'जन आधार कार्ड (Jan Aadhaar), आधार कार्ड, राशन कार्ड, पासपोर्ट साइज फोटो और स्व-घोषणा पत्र (पटवारी/सरपंच सत्यापन)',
      documentsEn: 'Jan Aadhaar Card, Aadhaar Card, Ration Card, Passport Photo, and Self-Declaration Form',
      stepsHi: [
        'नीचे दिए हरे बटन से **sso.rajasthan.gov.in** खोलें और अपनी SSO ID / जन आधार से लॉगिन करें (या नज़दीकी ई-मित्र केंद्र जाएं)।',
        'Citizen Apps में **E-Mitra** चुनकर *Avail Service* से जाति, मूल निवास, आय प्रमाण पत्र या जन आधार सेवा चुनें।',
        'दस्तावेज़ अपलोड कर ₹30–₹50 का टोकन कटवाएं और डिजिटल हस्ताक्षरित सर्टिफिकेट डाउनलोड करें।',
      ],
      stepsEn: [
        'Open **sso.rajasthan.gov.in** using the button below and log in with your Rajasthan SSO ID.',
        'Select **E-Mitra** under Citizen Apps and choose Jan Aadhaar, Domicile, Caste, or Income certificate.',
        'Upload documents, pay the ₹30–₹50 token fee, and download your digitally signed certificate.',
      ],
    },
  },
  {
    value: '🇮🇳 India - Uttar Pradesh',
    label: '🇮🇳 Uttar Pradesh (उत्तर प्रदेश)',
    flag: '🇮🇳',
    scope: 'india',
    shortName: 'Uttar Pradesh',
    domainHint: 'edistrict.up.gov.in',
    portals: [
      {
        name: 'UP e-District / Jan Seva Kendra Portal',
        url: 'https://edistrict.up.gov.in/',
        domain: 'edistrict.up.gov.in',
        category: 'Citizen Services',
        description: 'उत्तर प्रदेश ई-डिस्ट्रिक्ट / जनसेवा केंद्र पोर्टल — आय, जाति, निवास प्रमाण पत्र, राशन कार्ड व सरकारी सेवाएँ।',
      },
      {
        name: 'UPPSC — उत्तर प्रदेश लोक सेवा आयोग',
        url: 'https://uppsc.up.nic.in/',
        domain: 'uppsc.up.nic.in',
        category: 'State Recruitment',
        description: 'UPPCS, RO/ARO, UP Police (uppbpb.gov.in) और सरकारी भर्ती नोटिफिकेशन व आवेदन।',
      },
    ],
    citizenGuide: {
      portalName: 'e-District UP / जनसेवा केंद्र (e-Sathi)',
      portalDomain: 'edistrict.up.gov.in',
      portalUrl: 'https://edistrict.up.gov.in/',
      feeSummaryHi: 'ई-साथी (Citizen Login) ₹15 प्रति प्रमाण पत्र | जनसेवा केंद्र (CSC) शुल्क ₹30',
      feeSummaryEn: '₹15 via Citizen Login (e-Sathi) | ₹30 at Jan Seva Kendra (CSC) for Caste/Income/Domicile certificates',
      documentsHi: 'आधार कार्ड, परिवार आईडी (Family ID) / राशन कार्ड, स्वप्रमाणित घोषणा पत्र (Self-Declaration), पार्षद/प्रधान सत्यापन व पासपोर्ट फोटो',
      documentsEn: 'Aadhaar Card, UP Family ID / Ration Card, Self-Declaration Form, and Passport Photo',
      stepsHi: [
        'नीचे दिए हरे बटन से **edistrict.up.gov.in** खोलें और **सिटीजन लॉगिन (ई-साथी)** से नया यूज़र रजिस्ट्रेशन कर लॉगिन करें।',
        'जाति, आय, निवास या हैसियत प्रमाण पत्र फॉर्म भरें और स्वप्रमाणित घोषणा पत्र व आधार अपलोड करें।',
        '₹15 ऑनलाइन शुल्क जमा करें; लेखपाल/तहसीलदार सत्यापन के बाद पोर्टल से ही डिजिटल प्रमाण पत्र डाउनलोड करें।',
      ],
      stepsEn: [
        'Open **edistrict.up.gov.in** and register/login via **Citizen Login (e-Sathi)**.',
        'Fill the application for Caste, Income, or Domicile certificate and upload your self-declaration and Aadhaar.',
        'Pay ₹15 online; once verified by Tehsil/Lekhpal, download the digitally signed PDF.',
      ],
    },
  },
  {
    value: '🇮🇳 India - Bihar',
    label: '🇮🇳 Bihar (बिहार)',
    flag: '🇮🇳',
    scope: 'india',
    shortName: 'Bihar',
    domainHint: 'serviceonline.bihar.gov.in',
    portals: [
      {
        name: 'RTPS Bihar / ServicePlus बिहार पोर्टल',
        url: 'https://serviceonline.bihar.gov.in/',
        domain: 'serviceonline.bihar.gov.in',
        category: 'Citizen Services',
        description: 'बिहार लोक सेवाओं का अधिकार (RTPS) — आवासीय, जाति, आय प्रमाण पत्र, नॉन-क्रीमी लेयर व नागरिक सेवाएँ।',
      },
      {
        name: 'BPSC — बिहार लोक सेवा आयोग',
        url: 'https://bpsc.bihar.gov.in/',
        domain: 'bpsc.bihar.gov.in',
        category: 'State Recruitment',
        description: 'BPSC CCE, शिक्षक भर्ती (TRE) और बिहार राज्य की सरकारी भर्तियों का आधिकारिक पोर्टल।',
      },
    ],
    citizenGuide: {
      portalName: 'RTPS Bihar / ServicePlus Portal',
      portalDomain: 'serviceonline.bihar.gov.in',
      portalUrl: 'https://serviceonline.bihar.gov.in/',
      feeSummaryHi: 'स्वयं ऑनलाइन आवेदन ₹0 (बिल्कुल मुफ्त) | वसुधा केंद्र / CSC सेवा शुल्क ₹20–₹30',
      feeSummaryEn: '₹0 (Free) via direct online RTPS Bihar portal | ₹20–₹30 at Vasudha Kendra / CSC',
      documentsHi: 'आधार कार्ड (मोबाइल OTP), स्व-अभिप्रमाणित पासपोर्ट फोटो, स्थानीय पता/भूमि प्रमाण (खतियान/रसीद) व आय विवरण',
      documentsEn: 'Aadhaar Card, Self-attested Passport Photo, Residence/Land proof',
      stepsHi: [
        'नीचे दिए हरे बटन से **serviceonline.bihar.gov.in** खोलें और **लोक सेवाओं का अधिकार (RTPS)** में सामान्य प्रशासन विभाग चुनें।',
        'आवासीय (निवास), जाति या आय प्रमाण पत्र (अंचल / अनुमंडल / जिला स्तर) चुनकर फॉर्म भरें व स्व-अभिप्रमाणित फोटो-आधार अपलोड करें।',
        'फ्री सबमिट कर आवेदन रसीद सेव करें और 10–14 कार्य दिवस में OTP/सर्टिफिकेट डाउनलोड करें।',
      ],
      stepsEn: [
        'Open **serviceonline.bihar.gov.in** and choose General Administration Dept under RTPS Services.',
        'Select Residence, Caste, or Income certificate, fill details, and upload self-attested photo & Aadhaar.',
        'Submit for ₹0, save the acknowledgment slip, and download your digitally signed PDF once issued.',
      ],
    },
  },
  {
    value: '🇮🇳 India - Madhya Pradesh',
    label: '🇮🇳 Madhya Pradesh (मध्य प्रदेश)',
    flag: '🇮🇳',
    scope: 'india',
    shortName: 'Madhya Pradesh',
    domainHint: 'mpedistrict.gov.in',
    portals: [
      {
        name: 'MP e-District & MPOnline (मध्य प्रदेश लोक सेवा गारंटी)',
        url: 'https://mpedistrict.gov.in/',
        domain: 'mpedistrict.gov.in',
        category: 'Citizen Services',
        description: 'मध्य प्रदेश ई-डिस्ट्रिक्ट व MPOnline (mponline.gov.in) — मूल निवास, जाति, आय प्रमाण पत्र, समग्र व लाड़ली बहना सेवाएँ।',
      },
      {
        name: 'MPOnline Citizen Portal',
        url: 'https://www.mponline.gov.in/',
        domain: 'mponline.gov.in',
        category: 'Citizen Services',
        description: 'मध्य प्रदेश MPOnline आधिकारिक कियोस्क व नागरिक पोर्टल — परीक्षा फॉर्म, बिजली बिल व सरकारी प्रमाण पत्र।',
      },
      {
        name: 'MPPSC — मध्य प्रदेश लोक सेवा आयोग',
        url: 'https://mppsc.mp.gov.in/',
        domain: 'mppsc.mp.gov.in',
        category: 'State Recruitment',
        description: 'MP राज्य सेवा परीक्षा, MPESB (esb.mp.gov.in) व सरकारी भर्ती विज्ञापन।',
      },
    ],
    citizenGuide: {
      portalName: 'MP e-District / MPOnline (लोक सेवा केंद्र)',
      portalDomain: 'mpedistrict.gov.in',
      portalUrl: 'https://mpedistrict.gov.in/',
      feeSummaryHi: 'लोक सेवा गारंटी / ऑनलाइन शुल्क ₹20 से ₹40 (MPOnline / लोक सेवा केंद्र पर निर्धारित दर)',
      feeSummaryEn: '₹20 to ₹40 official Lok Seva Kendra / MPOnline portal fee',
      documentsHi: 'समग्र आईडी (Samagra ID), आधार कार्ड, राशन कार्ड / वोटर आईडी, स्व-घोषणा पत्र और पासपोर्ट साइज फोटो',
      documentsEn: 'Samagra ID, Aadhaar Card, Ration Card / Voter ID, Self-Declaration Form, and Passport Photo',
      stepsHi: [
        'नीचे दिए हरे बटन से **mpedistrict.gov.in** (या कियोस्क सेवाओं के लिए **mponline.gov.in**) खोलें।',
        'समग्र आईडी व आधार OTP से लॉगिन कर स्थानीय निवासी, आय या डिजिटल जाति प्रमाण पत्र सेवा चुनें।',
        'दस्तावेज़ अपलोड कर निर्धारित ₹20–₹40 शुल्क जमा करें और डिजिटल हस्ताक्षरित सर्टिफिकेट डाउनलोड करें।',
      ],
      stepsEn: [
        'Open **mpedistrict.gov.in** (or **mponline.gov.in** for kiosk/MPOnline services) via the button below.',
        'Select Residence, Caste, or Income certificate and verify using Samagra ID & Aadhaar OTP.',
        'Upload documents, pay the ₹20–₹40 official fee, and download your digitally signed PDF certificate.',
      ],
    },
  },
  {
    value: '🇮🇳 India - Maharashtra',
    label: '🇮🇳 Maharashtra (महाराष्ट्र)',
    flag: '🇮🇳',
    scope: 'india',
    shortName: 'Maharashtra',
    domainHint: 'aaplesarkar.mahaonline.gov.in',
    portals: [
      {
        name: 'Aaple Sarkar — Maharashtra Citizen Portal',
        url: 'https://aaplesarkar.mahaonline.gov.in/',
        domain: 'aaplesarkar.mahaonline.gov.in',
        category: 'Citizen Services',
        description: 'महाराष्ट्र शासन आपले सरकार पोर्टल — रहिवासी, उत्पन्न, जात प्रमाणपत्र, MahaDBT व डिजिटल सेवाएँ।',
      },
      {
        name: 'MPSC — Maharashtra Public Service Commission',
        url: 'https://mpsc.gov.in/',
        domain: 'mpsc.gov.in',
        category: 'State Recruitment',
        description: 'MPSC राजपत्रित/अराजपत्रित परीक्षा विज्ञापन, प्रवेश पत्र व ऑनलाइन आवेदन।',
      },
    ],
    citizenGuide: {
      portalName: 'Aaple Sarkar (आपले सरकार महाराष्ट्र)',
      portalDomain: 'aaplesarkar.mahaonline.gov.in',
      portalUrl: 'https://aaplesarkar.mahaonline.gov.in/',
      feeSummaryHi: '₹33.60 सेवा शुल्क (ऑनलाइन आपले सरकार / MahaOnline) | सेतू केंद्र पर ₹59 तक',
      feeSummaryEn: '₹33.60 online citizen service fee on Aaple Sarkar (up to ₹59 at Setu Kendra)',
      documentsHi: 'आधार कार्ड, रेशन कार्ड, शाळा सोडल्याचा दाखला (LC/TC) किंवा रहिवासी पुरावा, स्व-घोषणापत्र (Self-Declaration) व फोटो',
      documentsEn: 'Aadhaar Card, Ration Card, School Leaving Certificate (LC) or Residence Proof, Self-Declaration, Photo',
      stepsHi: [
        'नीचे दिए हरे बटन से **aaplesarkar.mahaonline.gov.in** खोलें और मोबाइल OTP से Citizen Registration/Login करें।',
        'Revenue Department में Age/Nationality/Domicile, Income या Caste Certificate चुनकर दस्तावेज़ अपलोड करें।',
        '₹33.60 ऑनलाइन भुगतान करें और तहसीलदार अनुमोदन के बाद PDF प्रमाण पत्र डाउनलोड करें।',
      ],
      stepsEn: [
        'Open **aaplesarkar.mahaonline.gov.in** and sign in using mobile OTP citizen login.',
        'Choose Domicile, Income, or Caste Certificate under Revenue Department and upload proofs.',
        'Pay ₹33.60 online and download your digitally signed certificate once approved.',
      ],
    },
  },
  {
    value: '🇮🇳 India - Delhi (NCT)',
    label: '🇮🇳 Delhi (दिल्ली)',
    flag: '🇮🇳',
    scope: 'india',
    shortName: 'Delhi',
    domainHint: 'edistrict.delhigovt.nic.in',
    portals: [
      {
        name: 'e-District Delhi — Govt of NCT of Delhi',
        url: 'https://edistrict.delhigovt.nic.in/',
        domain: 'edistrict.delhigovt.nic.in',
        category: 'Citizen Services',
        description: 'दिल्ली ई-डिस्ट्रिक्ट पोर्टल — प्रमाण पत्र, छात्रवृत्ति, राशन व नागरिक सेवाएँ।',
      },
      {
        name: 'DSSSB — Delhi Subordinate Services Selection Board',
        url: 'https://dsssb.delhi.gov.in/',
        domain: 'dsssb.delhi.gov.in',
        category: 'State Recruitment',
        description: 'दिल्ली शिक्षक (PRT/TGT/PGT), क्लर्क और सरकारी विभाग भर्ती अधिसूचना।',
      },
    ],
    citizenGuide: {
      portalName: 'e-District Delhi (दिल्ली सरकार)',
      portalDomain: 'edistrict.delhigovt.nic.in',
      portalUrl: 'https://edistrict.delhigovt.nic.in/',
      feeSummaryHi: '₹0 (दिल्ली ई-डिस्ट्रिक्ट पोर्टल पर अधिकांश प्रमाण पत्र आवेदन निःशुल्क)',
      feeSummaryEn: '₹0 (Free online citizen application on e-District Delhi for Domicile/Caste/Income certificates)',
      documentsHi: 'आधार कार्ड, दिल्ली में 3 वर्ष के निवास का प्रमाण (बिजली/पानी बिल/बैंक पासबुक), जन्म/आय प्रमाण व स्व-घोषणा पत्र',
      documentsEn: 'Aadhaar Card, 3-year Delhi residence proof (utility bill/passbook), birth/income proof, and self-declaration',
      stepsHi: [
        'नीचे दिए हरे बटन से **edistrict.delhigovt.nic.in** खोलें और आधार/वोटर आईडी से Citizen Registration करें।',
        'लॉगिन कर *Apply Online* -> Revenue Department से Domicile, Caste, Income या OBC प्रमाण पत्र चुनें।',
        'स्कैन किए गए दस्तावेज़ व फोटो अपलोड कर ₹0 में सबमिट करें और SDM कार्यालय सत्यापन के बाद सर्टिफिकेट डाउनलोड करें।',
      ],
      stepsEn: [
        'Open **edistrict.delhigovt.nic.in** and register as a Citizen using your Aadhaar/Voter ID.',
        'Log in and select Domicile, Caste, or Income Certificate under Revenue Department.',
        'Upload documents and submit for ₹0; download your certificate after SDM verification.',
      ],
    },
  },
  {
    value: '🇮🇳 India - Gujarat',
    label: '🇮🇳 Gujarat (गुजरात)',
    flag: '🇮🇳',
    scope: 'india',
    shortName: 'Gujarat',
    domainHint: 'digitalgujarat.gov.in',
    portals: [
      {
        name: 'Digital Gujarat Portal',
        url: 'https://www.digitalgujarat.gov.in/',
        domain: 'digitalgujarat.gov.in',
        category: 'Citizen Services',
        description: 'डिजिटल गुजरात पोर्टल — छात्रवृत्ति, प्रमाण पत्र व राज्य सरकारी सेवाएँ।',
      },
      {
        name: 'GPSC — Gujarat Public Service Commission',
        url: 'https://gpsc.gujarat.gov.in/',
        domain: 'gpsc.gujarat.gov.in',
        category: 'State Recruitment',
        description: 'GPSC एवं GSSSB गुजरात सरकारी परीक्षा विज्ञापन व आवेदन।',
      },
    ],
    citizenGuide: {
      portalName: 'Digital Gujarat Portal (डिजिटल गुजरात)',
      portalDomain: 'digitalgujarat.gov.in',
      portalUrl: 'https://www.digitalgujarat.gov.in/',
      feeSummaryHi: '₹20 से ₹30 सेवा शुल्क (डिजिटल गुजरात / ई-ग्राम या जनसेवा केंद्र)',
      feeSummaryEn: '₹20 to ₹30 official service fee on Digital Gujarat / e-Gram Kendra',
      documentsHi: 'आधार कार्ड, राशन कार्ड, स्कूल लीविंग सर्टिफिकेट (LC), निवास व आय का प्रमाण, पासपोर्ट फोटो',
      documentsEn: 'Aadhaar Card, Ration Card, School Leaving Certificate (LC), Residence & Income Proof, Passport Photo',
      stepsHi: [
        'नीचे दिए हरे बटन से **digitalgujarat.gov.in** खोलें और Citizen Login से अकाउंट बनाएं।',
        '*Services -> Citizen Services* में जाकर Income, Caste, Non-Creamy Layer या Domicile Certificate चुनें।',
        'दस्तावेज़ अपलोड कर ₹20–₹30 ऑनलाइन शुल्क जमा करें और स्वीकृति के बाद सर्टिफिकेट डाउनलोड करें।',
      ],
      stepsEn: [
        'Open **digitalgujarat.gov.in** and sign in via Citizen Login.',
        'Navigate to Citizen Services and choose Income, Caste, Non-Creamy Layer, or Domicile Certificate.',
        'Upload documents, pay ₹20–₹30 online, and download the signed certificate.',
      ],
    },
  },
  {
    value: '🇮🇳 India - Haryana',
    label: '🇮🇳 Haryana (हरियाणा)',
    flag: '🇮🇳',
    scope: 'india',
    shortName: 'Haryana',
    domainHint: 'saralharyana.gov.in',
    portals: [
      {
        name: 'Antyodaya-SARAL Haryana Portal',
        url: 'https://saralharyana.gov.in/',
        domain: 'saralharyana.gov.in',
        category: 'Citizen Services',
        description: 'सरल हरियाणा — परिवार पहचान पत्र (PPP), सरकारी योजनाएँ और प्रमाण पत्र सेवाएँ।',
      },
      {
        name: 'HSSC & HPSC Official Portals',
        url: 'https://www.hssc.gov.in/',
        domain: 'hssc.gov.in',
        category: 'State Recruitment',
        description: 'हरियाणा कर्मचारी चयन आयोग (CET/Group C/D) भर्ती विज्ञापन और परिणाम।',
      },
    ],
    citizenGuide: {
      portalName: 'Antyodaya-SARAL Haryana (सरल हरियाणा)',
      portalDomain: 'saralharyana.gov.in',
      portalUrl: 'https://saralharyana.gov.in/',
      feeSummaryHi: 'सरकारी प्रमाण पत्र ₹10–₹50 (सरल पोर्टल / अटल सेवा केंद्र निर्धारित शुल्क)',
      feeSummaryEn: '₹10 to ₹50 on Saral Haryana / Atal Seva Kendra',
      documentsHi: 'परिवार पहचान पत्र (PPP / Family ID — अनिवार्य), आधार कार्ड, पते का प्रमाण व स्व-घोषणा पत्र',
      documentsEn: 'Parivar Pehchan Patra (PPP / Family ID — mandatory), Aadhaar Card, Address proof, Self-declaration',
      stepsHi: [
        'नीचे दिए हरे बटन से **saralharyana.gov.in** खोलें और जनपरिचय / सरल आईडी से लॉगिन करें।',
        'अपनी **Family ID (PPP)** दर्ज कर OTP से परिवार का विवरण स्वतः सत्यापित करें और जाति/निवास/आय प्रमाण पत्र चुनें।',
        '₹10–₹50 सरकारी शुल्क जमा करें और वेरिफिकेशन होते ही डिजिटल सर्टिफिकेट डाउनलोड करें।',
      ],
      stepsEn: [
        'Open **saralharyana.gov.in** and log in with JanParichay / Saral credentials.',
        'Enter your **Parivar Pehchan Patra (PPP / Family ID)** to auto-fetch verified member data and select the certificate.',
        'Pay the ₹10–₹50 fee and download your digitally signed PDF certificate.',
      ],
    },
  },
  {
    value: '🇮🇳 India - Punjab',
    label: '🇮🇳 Punjab (पंजाब)',
    flag: '🇮🇳',
    scope: 'india',
    shortName: 'Punjab',
    domainHint: 'connect.punjab.gov.in',
    portals: [
      {
        name: 'Digital Punjab / Sewa Connect Portal',
        url: 'https://connect.punjab.gov.in/',
        domain: 'connect.punjab.gov.in',
        category: 'Citizen Services',
        description: 'पंजाब सरकार का डिजिटल नागरिक सेवा और प्रमाण पत्र पोर्टल।',
      },
      {
        name: 'PSSSB & PPSC Official Portals',
        url: 'https://sssb.punjab.gov.in/',
        domain: 'sssb.punjab.gov.in',
        category: 'State Recruitment',
        description: 'पंजाब सरकारी भर्ती बोर्ड विज्ञापन, आवेदन लिंक व एडमिट कार्ड।',
      },
    ],
    citizenGuide: {
      portalName: 'Digital Punjab / e-Sewa (Sewa Kendra)',
      portalDomain: 'connect.punjab.gov.in',
      portalUrl: 'https://connect.punjab.gov.in/',
      feeSummaryHi: '₹50 से ₹100 (सरकारी व सेवा केंद्र सुविधा शुल्क)',
      feeSummaryEn: '₹50 to ₹100 government & Sewa Kendra facilitation fee',
      documentsHi: 'आधार कार्ड, वोटर/राशन कार्ड, सरपंच/पार्षद या पटवारी रिपोर्ट, पासपोर्ट फोटो और स्व-घोषणा',
      documentsEn: 'Aadhaar Card, Voter/Ration Card, Self-declaration & Residence proof, Passport Photo',
      stepsHi: [
        'नीचे दिए हरे बटन से **connect.punjab.gov.in** खोलें और Citizen Login से प्रवेश करें।',
        'Residence, Caste या Income Certificate सेवा चुनकर विवरण और दस्तावेज़ अपलोड करें।',
        'ऑनलाइन शुल्क जमा कर e-Sign युक्त प्रमाण पत्र डाउनलोड करें।',
      ],
      stepsEn: [
        'Open **connect.punjab.gov.in** and log in via Digital Punjab.',
        'Select Residence, Caste, or Income Certificate and upload your verification documents.',
        'Pay the applicable fee and download your digitally signed certificate.',
      ],
    },
  },
  {
    value: '🇮🇳 India - West Bengal',
    label: '🇮🇳 West Bengal (पश्चिम बंगाल)',
    flag: '🇮🇳',
    scope: 'india',
    shortName: 'West Bengal',
    domainHint: 'edistrict.wb.gov.in',
    portals: [
      {
        name: 'e-District West Bengal Portal',
        url: 'https://edistrict.wb.gov.in/',
        domain: 'edistrict.wb.gov.in',
        category: 'Citizen Services',
        description: 'पश्चिम बंगाल ई-डिस्ट्रिक्ट — प्रमाण पत्र, कल्याणकारी योजनाएँ व नागरिक सेवाएँ।',
      },
      {
        name: 'WBPSC — West Bengal Public Service Commission',
        url: 'https://psc.wb.gov.in/',
        domain: 'psc.wb.gov.in',
        category: 'State Recruitment',
        description: 'WBCS और पश्चिम बंगाल राज्य सरकारी भर्ती अधिसूचना।',
      },
    ],
    citizenGuide: {
      portalName: 'e-District West Bengal (बांग्लार सहायता केंद्र)',
      portalDomain: 'edistrict.wb.gov.in',
      portalUrl: 'https://edistrict.wb.gov.in/',
      feeSummaryHi: '₹0 (e-District पोर्टल पर ऑनलाइन प्रमाण पत्र आवेदन निःशुल्क)',
      feeSummaryEn: '₹0 (Free citizen certificate applications on e-District West Bengal)',
      documentsHi: 'आधार कार्ड, वोटर आईडी (EPIC) / राशन कार्ड, आवासीय/आय स्व-घोषणा पत्र और पासपोर्ट फोटो',
      documentsEn: 'Aadhaar Card, Voter ID / Ration Card, Residence/Income declaration, Passport Photo',
      stepsHi: [
        'नीचे दिए हरे बटन से **edistrict.wb.gov.in** खोलें और Citizen Registration से लॉगिन करें।',
        'Certificates -> Income, Domicile या Local Residence सेवा चुनकर फॉर्म भरें व दस्तावेज़ अपलोड करें।',
        '₹0 में सबमिट करें और SDO/BDO अनुमोदन के बाद PDF प्रमाण पत्र डाउनलोड करें।',
      ],
      stepsEn: [
        'Open **edistrict.wb.gov.in** and sign in with Citizen Registration.',
        'Choose Income or Domicile Certificate, attach proofs, and submit for ₹0.',
        'Download the digitally signed certificate upon BDO/SDO approval.',
      ],
    },
  },
  {
    value: '🇮🇳 India - Tamil Nadu',
    label: '🇮🇳 Tamil Nadu (तमिलनाडु)',
    flag: '🇮🇳',
    scope: 'india',
    shortName: 'Tamil Nadu',
    domainHint: 'tnesevai.tn.gov.in',
    portals: [
      {
        name: 'TNeGA / e-Sevai Tamil Nadu',
        url: 'https://www.tnesevai.tn.gov.in/',
        domain: 'tnesevai.tn.gov.in',
        category: 'Citizen Services',
        description: 'तमिलनाडु ई-सेवा पोर्टल — प्रमाण पत्र, छात्रवृत्ति और नागरिक सेवाएँ।',
      },
      {
        name: 'TNPSC — Tamil Nadu Public Service Commission',
        url: 'https://www.tnpsc.gov.in/',
        domain: 'tnpsc.gov.in',
        category: 'State Recruitment',
        description: 'TNPSC Group 1/2/4 परीक्षा अधिसूचना, आवेदन और परिणाम।',
      },
    ],
    citizenGuide: {
      portalName: 'TNeGA / e-Sevai Tamil Nadu',
      portalDomain: 'tnesevai.tn.gov.in',
      portalUrl: 'https://www.tnesevai.tn.gov.in/',
      feeSummaryHi: '₹60 सामान्य प्रमाण पत्र शुल्क (Community / Nativity / Income Certificate)',
      feeSummaryEn: '₹60 standard online fee on e-Sevai Tamil Nadu for Community/Nativity/Income certificates',
      documentsHi: 'Aadhaar Card, Smart Ration Card, Passport Photo, Address Proof, Self-Declaration',
      documentsEn: 'Aadhaar Card, Smart Ration Card, Passport Photo, Address Proof, Self-Declaration',
      stepsHi: [
        'नीचे दिए हरे बटन से **tnesevai.tn.gov.in** खोलें और Citizen Portal (e-Sevai) में लॉगिन करें।',
        'Community, Nativity या Income Certificate चुनें और CAN (Citizen Access Number) रजिस्टर करें।',
        'दस्तावेज़ अपलोड कर ₹60 ऑनलाइन भुगतान करें और VAO/Tahsildar वेरिफिकेशन के बाद सर्टिफिकेट डाउनलोड करें।',
      ],
      stepsEn: [
        'Open **tnesevai.tn.gov.in**, register your CAN (Citizen Access Number), and log in.',
        'Select Community, Nativity, or Income Certificate and upload your proofs.',
        'Pay ₹60 online and download the signed certificate after Tahsildar approval.',
      ],
    },
  },
  {
    value: '🇮🇳 India - Karnataka',
    label: '🇮🇳 Karnataka (कर्नाटक)',
    flag: '🇮🇳',
    scope: 'india',
    shortName: 'Karnataka',
    domainHint: 'sevasindhu.karnataka.gov.in',
    portals: [
      {
        name: 'Seva Sindhu — Karnataka Guarantee Schemes & Services',
        url: 'https://sevasindhu.karnataka.gov.in/',
        domain: 'sevasindhu.karnataka.gov.in',
        category: 'Citizen Services',
        description: 'सेवा सिंधु कर्नाटक — गृह लक्ष्मी, शक्ति, प्रमाण पत्र व सभी नागरिक सेवाएँ।',
      },
      {
        name: 'KPSC — Karnataka Public Service Commission',
        url: 'https://kpsc.kar.nic.in/',
        domain: 'kpsc.kar.nic.in',
        category: 'State Recruitment',
        description: 'कर्नाटक लोक सेवा आयोग भर्ती विज्ञापन और परीक्षा कैलेंडर।',
      },
    ],
    citizenGuide: {
      portalName: 'Seva Sindhu Karnataka (सेवा सिंधु)',
      portalDomain: 'sevasindhu.karnataka.gov.in',
      portalUrl: 'https://sevasindhu.karnataka.gov.in/',
      feeSummaryHi: '₹25 से ₹40 (अटलजी जन स्नेही / ग्राम वन / सेवा सिंधु शुल्क)',
      feeSummaryEn: '₹25 to ₹40 via Seva Sindhu / Nadakacheri / Grama One',
      documentsHi: 'आधार कार्ड, राशन कार्ड / Kutumba ID, पते व आय का स्व-घोषणा पत्र, फोटो',
      documentsEn: 'Aadhaar Card, Ration Card / Kutumba ID, Address & Income Self-Declaration, Photo',
      stepsHi: [
        'नीचे दिए हरे बटन से **sevasindhu.karnataka.gov.in** खोलें और MeriPehchaan / Seva Sindhu से लॉगिन करें।',
        'Caste, Income या Residence Certificate सेवा चुनकर फॉर्म भरें व दस्तावेज़ अपलोड करें।',
        '₹25–₹40 ऑनलाइन भुगतान करें और रसीद नंबर से सर्टिफिकेट डाउनलोड करें।',
      ],
      stepsEn: [
        'Open **sevasindhu.karnataka.gov.in** and sign in with MeriPehchaan.',
        'Select Caste, Income, or Residence Certificate and attach supporting documents.',
        'Pay ₹25–₹40 online and download your certificate once processed.',
      ],
    },
  },
  {
    value: '🇮🇳 India - Kerala',
    label: '🇮🇳 Kerala (केरल)',
    flag: '🇮🇳',
    scope: 'india',
    shortName: 'Kerala',
    domainHint: 'edistrict.kerala.gov.in',
    portals: [
      {
        name: 'e-District Kerala — Govt of Kerala Citizen Portal',
        url: 'https://edistrict.kerala.gov.in/',
        domain: 'edistrict.kerala.gov.in',
        category: 'Citizen Services',
        description: 'केरल ई-डिस्ट्रिक्ट व अक्षय (Akshaya) पोर्टल — जाति, आय, निवास प्रमाण पत्र व नागरिक सेवाएँ।',
      },
      {
        name: 'Kerala PSC Official Portal',
        url: 'https://www.keralapsc.gov.in/',
        domain: 'keralapsc.gov.in',
        category: 'State Recruitment',
        description: 'केरल लोक सेवा आयोग (Thulasi) व राज्य सरकारी भर्ती पोर्टल।',
      },
    ],
    citizenGuide: {
      portalName: 'e-District Kerala / Akshaya',
      portalDomain: 'edistrict.kerala.gov.in',
      portalUrl: 'https://edistrict.kerala.gov.in/',
      feeSummaryHi: '₹15 से ₹35 (e-District ऑनलाइन / अक्षय केंद्र शुल्क)',
      feeSummaryEn: '₹15 to ₹35 on e-District Kerala / Akshaya Centre',
      documentsHi: 'आधार कार्ड, राशन कार्ड, स्कूल सर्टिफिकेट (SSLC), आय/निवास प्रमाण पत्र',
      documentsEn: 'Aadhaar Card, Ration Card, SSLC Certificate, Address & Income Proof',
      stepsHi: [
        'नीचे दिए हरे बटन से **edistrict.kerala.gov.in** खोलें और One Time Registration / Citizen Login करें।',
        'Nativity, Community या Income Certificate चुनें और दस्तावेज़ अपलोड करें।',
        '₹15–₹35 शुल्क जमा करें और Village Officer सत्यापन के बाद सर्टिफिकेट डाउनलोड करें।',
      ],
      stepsEn: [
        'Open **edistrict.kerala.gov.in** and log in as a Citizen.',
        'Apply for Nativity, Community, or Income Certificate and upload scanned proofs.',
        'Pay ₹15–₹35 and download the signed PDF after Village Officer approval.',
      ],
    },
  },
  {
    value: '🇮🇳 India - Telangana',
    label: '🇮🇳 Telangana (तेलंगाना)',
    flag: '🇮🇳',
    scope: 'india',
    shortName: 'Telangana',
    domainHint: 'ts.meeseva.telangana.gov.in',
    portals: [
      {
        name: 'MeeSeva Telangana Citizen Portal',
        url: 'https://ts.meeseva.telangana.gov.in/',
        domain: 'ts.meeseva.telangana.gov.in',
        category: 'Citizen Services',
        description: 'तेलंगाना मीसेवा (MeeSeva) पोर्टल — प्रमाण पत्र, भूमि रिकॉर्ड व राज्य नागरिक सेवाएँ।',
      },
      {
        name: 'TGPSC — Telangana Public Service Commission',
        url: 'https://www.tspsc.gov.in/',
        domain: 'tspsc.gov.in',
        category: 'State Recruitment',
        description: 'तेलंगाना लोक सेवा आयोग (TGPSC) भर्ती पोर्टल।',
      },
    ],
    citizenGuide: {
      portalName: 'MeeSeva Telangana Portal',
      portalDomain: 'ts.meeseva.telangana.gov.in',
      portalUrl: 'https://ts.meeseva.telangana.gov.in/',
      feeSummaryHi: '₹35 से ₹45 (मीसेवा ऑनलाइन / केंद्र सेवा शुल्क)',
      feeSummaryEn: '₹35 to ₹45 via MeeSeva Telangana / T App Folio',
      documentsHi: 'आधार कार्ड, राशन कार्ड / खाद्य सुरक्षा कार्ड, निवास व शैक्षणिक प्रमाण, फोटो',
      documentsEn: 'Aadhaar Card, Ration Card, Residence & Educational Proofs, Photo',
      stepsHi: [
        'नीचे दिए हरे बटन से **ts.meeseva.telangana.gov.in** खोलें (या T App Folio का उपयोग करें)।',
        'Caste, Income या Residence Certificate चुनकर आवेदन फॉर्म भरें।',
        '₹35–₹45 शुल्क जमा करें और Tahsildar स्वीकृति के बाद डिजिटल सर्टिफिकेट प्राप्त करें।',
      ],
      stepsEn: [
        'Open **ts.meeseva.telangana.gov.in** (or use T App Folio / MeeSeva center).',
        'Submit Caste, Income, or Residence certificate details and upload documents.',
        'Pay ₹35–₹45 and download the certificate after Tahsildar approval.',
      ],
    },
  },
  {
    value: '🇮🇳 India - Andhra Pradesh',
    label: '🇮🇳 Andhra Pradesh (आंध्र प्रदेश)',
    flag: '🇮🇳',
    scope: 'india',
    shortName: 'Andhra Pradesh',
    domainHint: 'vsws.ap.gov.in',
    portals: [
      {
        name: 'AP Grama / Ward Sachivalayam & MeeSeva Portal',
        url: 'https://vsws.ap.gov.in/',
        domain: 'vsws.ap.gov.in',
        category: 'Citizen Services',
        description: 'आंध्र प्रदेश ग्राम/वार्ड सचिवालय और मीसेवा नागरिक सेवा पोर्टल।',
      },
      {
        name: 'APPSC — Andhra Pradesh PSC',
        url: 'https://psc.ap.gov.in/',
        domain: 'psc.ap.gov.in',
        category: 'State Recruitment',
        description: 'आंध्र प्रदेश लोक सेवा आयोग आधिकारिक भर्ती पोर्टल।',
      },
    ],
    citizenGuide: {
      portalName: 'AP Grama / Ward Sachivalayam & MeeSeva',
      portalDomain: 'vsws.ap.gov.in',
      portalUrl: 'https://vsws.ap.gov.in/',
      feeSummaryHi: '₹35 से ₹45 (ग्राम/वार्ड सचिवालय व मीसेवा सेवा शुल्क)',
      feeSummaryEn: '₹35 to ₹45 via AP Grama/Ward Sachivalayam or MeeSeva',
      documentsHi: 'आधार कार्ड, राशन कार्ड / राइस कार्ड, पते व आय का प्रमाण, फोटो',
      documentsEn: 'Aadhaar Card, Rice/Ration Card, Address & Income Proof, Photo',
      stepsHi: [
        'नीचे दिए हरे बटन से **vsws.ap.gov.in** (या नज़दीकी ग्राम/वार्ड सचिवालय) पर जाएं।',
        'Integrated Caste, Income या Residence Certificate का आवेदन सबमिट करें।',
        '₹35–₹45 शुल्क जमा कर डिजिटल सर्टिफिकेट डाउनलोड करें।',
      ],
      stepsEn: [
        'Visit **vsws.ap.gov.in** or your nearest Grama/Ward Sachivalayam.',
        'Submit your Caste, Income, or Residence certificate application with proofs.',
        'Pay ₹35–₹45 and download the digitally signed certificate.',
      ],
    },
  },
  {
    value: '🇮🇳 India - Odisha',
    label: '🇮🇳 Odisha (ओडिशा)',
    flag: '🇮🇳',
    scope: 'india',
    shortName: 'Odisha',
    domainHint: 'edistrict.odisha.gov.in',
    portals: [
      {
        name: 'e-District Odisha / Odisha One Portal',
        url: 'https://edistrict.odisha.gov.in/',
        domain: 'edistrict.odisha.gov.in',
        category: 'Citizen Services',
        description: 'ओडिशा ई-डिस्ट्रिक्ट (edistrict.odisha.gov.in) व मो सेवा केंद्र नागरिक पोर्टल।',
      },
      {
        name: 'OPSC Official Portal',
        url: 'https://www.opsc.gov.in/',
        domain: 'opsc.gov.in',
        category: 'State Recruitment',
        description: 'ओडिशा लोक सेवा आयोग (OPSC) व OSSC भर्ती पोर्टल।',
      },
    ],
    citizenGuide: {
      portalName: 'e-District Odisha (ओडिशा ई-डिस्ट्रिक्ट)',
      portalDomain: 'edistrict.odisha.gov.in',
      portalUrl: 'https://edistrict.odisha.gov.in/',
      feeSummaryHi: '₹30 (Mo Seba Kendra / e-District प्रमाण पत्र शुल्क)',
      feeSummaryEn: '₹30 citizen certificate fee on e-District Odisha / Mo Seba Kendra',
      documentsHi: 'आधार कार्ड, ROR (जमीन का पट्टा), राशन कार्ड व स्व-घोषणा पत्र',
      documentsEn: 'Aadhaar Card, Land ROR, Ration Card, Self-Declaration',
      stepsHi: [
        'नीचे दिए हरे बटन से **edistrict.odisha.gov.in** खोलें और Citizen Login करें।',
        'Resident, Caste या Income Certificate चुनें और आधार व ROR अपलोड करें।',
        '₹30 ऑनलाइन शुल्क जमा कर प्रमाण पत्र डाउनलोड करें।',
      ],
      stepsEn: [
        'Open **edistrict.odisha.gov.in** and sign in via Citizen Login.',
        'Select Resident, Caste, or Income Certificate and upload Aadhaar & ROR.',
        'Pay ₹30 online and download your certificate once approved.',
      ],
    },
  },
  {
    value: '🇮🇳 India - Jharkhand',
    label: '🇮🇳 Jharkhand (झारखंड)',
    flag: '🇮🇳',
    scope: 'india',
    shortName: 'Jharkhand',
    domainHint: 'jharsewa.jharkhand.gov.in',
    portals: [
      {
        name: 'JharSewa — झारखंड ई-डिस्ट्रिक्ट नागरिक पोर्टल',
        url: 'https://jharsewa.jharkhand.gov.in/',
        domain: 'jharsewa.jharkhand.gov.in',
        category: 'Citizen Services',
        description: 'झारसेवा पोर्टल — स्थानीय निवासी, जाति, आय प्रमाण पत्र व प्रज्ञा केंद्र सेवाएँ।',
      },
      {
        name: 'JSSC & JPSC Jharkhand Portal',
        url: 'https://jssc.jharkhand.gov.in/',
        domain: 'jssc.jharkhand.gov.in',
        category: 'State Recruitment',
        description: 'झारखंड कर्मचारी चयन आयोग व JPSC भर्ती पोर्टल।',
      },
    ],
    citizenGuide: {
      portalName: 'JharSewa Jharkhand (झारसेवा / प्रज्ञा केंद्र)',
      portalDomain: 'jharsewa.jharkhand.gov.in',
      portalUrl: 'https://jharsewa.jharkhand.gov.in/',
      feeSummaryHi: '₹0 (स्वयं लॉगिन) से ₹30–₹50 (प्रज्ञा केंद्र / CSC शुल्क)',
      feeSummaryEn: '₹0 (self-apply) to ₹30–₹50 (Pragya Kendra / CSC)',
      documentsHi: 'आधार कार्ड, खतियान / वंशावली / आवासीय प्रमाण, स्व-घोषणा पत्र और फोटो',
      documentsEn: 'Aadhaar Card, Khatiyan / Local Residence Proof, Self-declaration, Photo',
      stepsHi: [
        'नीचे दिए हरे बटन से **jharsewa.jharkhand.gov.in** खोलें और Register Yourself से लॉगिन करें।',
        'Local Resident (स्थानीय निवासी), Caste या Income Certificate चुनकर दस्तावेज़ अपलोड करें।',
        'आवेदन सबमिट कर CO/SDO अनुमोदन के बाद झारसेवा से सर्टिफिकेट डाउनलोड करें।',
      ],
      stepsEn: [
        'Open **jharsewa.jharkhand.gov.in** and sign in with your Citizen account.',
        'Select Local Resident, Caste, or Income Certificate and attach documents.',
        'Submit and download the digitally signed PDF after CO/SDO verification.',
      ],
    },
  },
  {
    value: '🇮🇳 India - Chhattisgarh',
    label: '🇮🇳 Chhattisgarh (छत्तीसगढ़)',
    flag: '🇮🇳',
    scope: 'india',
    shortName: 'Chhattisgarh',
    domainHint: 'edistrict.cgstate.gov.in',
    portals: [
      {
        name: 'CG e-District (छत्तीसगढ़ लोक सेवा / चॉइस पोर्टल)',
        url: 'https://edistrict.cgstate.gov.in/',
        domain: 'edistrict.cgstate.gov.in',
        category: 'Citizen Services',
        description: 'छत्तीसगढ़ ई-डिस्ट्रिक्ट पोर्टल — निवास, जाति, आय प्रमाण पत्र और राज्य नागरिक सेवाएँ।',
      },
      {
        name: 'CG Vyapam & CGPSC Official Portal',
        url: 'https://psc.cg.gov.in/',
        domain: 'psc.cg.gov.in',
        category: 'State Recruitment',
        description: 'छत्तीसगढ़ लोक सेवा आयोग, CG Vyapam और राज्य सरकारी भर्ती।',
      },
    ],
    citizenGuide: {
      portalName: 'CG e-District (छत्तीसगढ़ ई-डिस्ट्रिक्ट)',
      portalDomain: 'edistrict.cgstate.gov.in',
      portalUrl: 'https://edistrict.cgstate.gov.in/',
      feeSummaryHi: '₹30 से ₹50 (लोक सेवा केंद्र / चॉइस सेंटर / ऑनलाइन टोकन शुल्क)',
      feeSummaryEn: '₹30 to ₹50 on CG e-District / Lok Seva Kendra (CHOICE)',
      documentsHi: 'आधार कार्ड, राशन कार्ड, बी-1 खसरा / मिसल रिकॉर्ड या निवास प्रमाण, स्व-घोषणा पत्र व फोटो',
      documentsEn: 'Aadhaar Card, Ration Card, B-1/Misal or Residence proof, Self-declaration, Photo',
      stepsHi: [
        'नीचे दिए हरे बटन से **edistrict.cgstate.gov.in** खोलें और **नागरिक (Citizen)** लॉगिन करें।',
        'मूल निवास, जाति या आय प्रमाण पत्र सेवा चुनकर सभी जानकारी और दस्तावेज़ अपलोड करें।',
        '₹30–₹50 शुल्क जमा कर आवेदन नंबर सेव करें और तहसील से जारी सर्टिफिकेट डाउनलोड करें।',
      ],
      stepsEn: [
        'Open **edistrict.cgstate.gov.in** and sign in under Citizen Login.',
        'Choose Domicile, Caste, or Income Certificate and upload your proofs.',
        'Pay ₹30–₹50 and download your digitally signed certificate.',
      ],
    },
  },
  {
    value: '🇮🇳 India - Uttarakhand',
    label: '🇮🇳 Uttarakhand (उत्तराखंड)',
    flag: '🇮🇳',
    scope: 'india',
    shortName: 'Uttarakhand',
    domainHint: 'eservices.uk.gov.in',
    portals: [
      {
        name: 'Apuni Sarkar — अपनी सरकार उत्तराखंड पोर्टल',
        url: 'https://eservices.uk.gov.in/',
        domain: 'eservices.uk.gov.in',
        category: 'Citizen Services',
        description: 'उत्तराखंड अपनी सरकार पोर्टल — स्थायी निवास, जाति, आय, पर्वतीय प्रमाण पत्र व ई-सेवाएँ।',
      },
      {
        name: 'UKPSC Official Portal',
        url: 'https://psc.uk.gov.in/',
        domain: 'psc.uk.gov.in',
        category: 'State Recruitment',
        description: 'उत्तराखंड लोक सेवा आयोग (UKPSC) व UKSSSC सरकारी भर्ती पोर्टल।',
      },
    ],
    citizenGuide: {
      portalName: 'Apuni Sarkar Uttarakhand (अपनी सरकार)',
      portalDomain: 'eservices.uk.gov.in',
      portalUrl: 'https://eservices.uk.gov.in/',
      feeSummaryHi: '₹30 (अपनी सरकार ऑनलाइन / CSC पोर्टल शुल्क)',
      feeSummaryEn: '₹30 official service fee on Apuni Sarkar Uttarakhand',
      documentsHi: 'आधार कार्ड, परिवार रजिस्टर की नकल / राशन कार्ड, 15 वर्ष निवास या भूमि प्रमाण, फोटो',
      documentsEn: 'Aadhaar Card, Pariwar Register / Ration Card, Residence proof, Photo',
      stepsHi: [
        'नीचे दिए हरे बटन से **eservices.uk.gov.in** खोलें और नागरिक लॉगिन करें।',
        'स्थायी निवास (Permanent Resident), जाति, आय या पर्वतीय प्रमाण पत्र चुनें और दस्तावेज़ अपलोड करें।',
        '₹30 ऑनलाइन शुल्क जमा कर डिजिटल सर्टिफिकेट डाउनलोड करें।',
      ],
      stepsEn: [
        'Open **eservices.uk.gov.in** and log in to Apuni Sarkar Citizen portal.',
        'Select Permanent Resident, Caste, Hill, or Income Certificate and upload proofs.',
        'Pay ₹30 online and download your certificate.',
      ],
    },
  },
  {
    value: '🇮🇳 India - Himachal Pradesh',
    label: '🇮🇳 Himachal Pradesh (हिमाचल प्रदेश)',
    flag: '🇮🇳',
    scope: 'india',
    shortName: 'Himachal Pradesh',
    domainHint: 'edistrict.hp.gov.in',
    portals: [
      {
        name: 'e-District Himachal Pradesh (हिमाचल ई-डिस्ट्रिक्ट)',
        url: 'https://edistrict.hp.gov.in/',
        domain: 'edistrict.hp.gov.in',
        category: 'Citizen Services',
        description: 'हिमाचल प्रदेश ई-डिस्ट्रिक्ट — Bonafide Himachali, जाति, आय व चरित्र प्रमाण पत्र।',
      },
      {
        name: 'HPPSC Official Portal',
        url: 'https://www.hppsc.hp.gov.in/',
        domain: 'hppsc.hp.gov.in',
        category: 'State Recruitment',
        description: 'हिमाचल प्रदेश लोक सेवा आयोग आधिकारिक भर्ती पोर्टल।',
      },
    ],
    citizenGuide: {
      portalName: 'e-District Himachal Pradesh',
      portalDomain: 'edistrict.hp.gov.in',
      portalUrl: 'https://edistrict.hp.gov.in/',
      feeSummaryHi: '₹20 से ₹35 (लोकमित्र केंद्र / e-District शुल्क)',
      feeSummaryEn: '₹20 to ₹35 on e-District HP / Lokmitra Kendra',
      documentsHi: 'आधार कार्ड, परिवार रजिस्टर नकल, राशन कार्ड, पटवारी रिपोर्ट व फोटो',
      documentsEn: 'Aadhaar Card, Parivar Register copy, Ration Card, Patwari report, Photo',
      stepsHi: [
        'नीचे दिए हरे बटन से **edistrict.hp.gov.in** खोलें और Citizen Login करें।',
        'Bonafide Himachali, Caste या Income Certificate चुनकर दस्तावेज़ अपलोड करें।',
        'शुल्क जमा कर तहसील से जारी प्रमाण पत्र डाउनलोड करें।',
      ],
      stepsEn: [
        'Open **edistrict.hp.gov.in** and sign in under Citizen Login.',
        'Choose Bonafide Himachali, Caste, or Income Certificate and upload documents.',
        'Pay the fee and download your digitally signed PDF.',
      ],
    },
  },
  {
    value: '🇮🇳 India - Assam',
    label: '🇮🇳 Assam (असम)',
    flag: '🇮🇳',
    scope: 'india',
    shortName: 'Assam',
    domainHint: 'sewasetu.assam.gov.in',
    portals: [
      {
        name: 'Sewa Setu Assam (सेवा सेतु असम नागरिक पोर्टल)',
        url: 'https://sewasetu.assam.gov.in/',
        domain: 'sewasetu.assam.gov.in',
        category: 'Citizen Services',
        description: 'असम सरकार सेवा सेतु पोर्टल — PRC (निवास), जाति, आय प्रमाण पत्र व सभी नागरिक सेवाएँ।',
      },
      {
        name: 'Assam State Portal & APSC',
        url: 'https://assam.gov.in/',
        domain: 'assam.gov.in',
        category: 'State Portal',
        description: 'असम सरकार मुख्य पोर्टल और सरकारी भर्ती जानकारी।',
      },
    ],
    citizenGuide: {
      portalName: 'Sewa Setu Assam (सेवा सेतु)',
      portalDomain: 'sewasetu.assam.gov.in',
      portalUrl: 'https://sewasetu.assam.gov.in/',
      feeSummaryHi: '₹30 से ₹50 (Sewa Setu / RTPS असम ऑनलाइन सेवा शुल्क)',
      feeSummaryEn: '₹30 to ₹50 on Sewa Setu Assam portal',
      documentsHi: 'आधार / वोटर आईडी, भूमि रिकॉर्ड या निवास प्रमाण, स्व-घोषणा पत्र व फोटो',
      documentsEn: 'Aadhaar / Voter ID, Residence or Land Proof, Self-Declaration, Photo',
      stepsHi: [
        'नीचे दिए हरे बटन से **sewasetu.assam.gov.in** खोलें और मोबाइल OTP से लॉगिन करें।',
        'PRC, Caste या Income Certificate सेवा चुनकर आवेदन फॉर्म भरें।',
        '₹30–₹50 शुल्क भुगतान कर डिजिटल सर्टिफिकेट डाउनलोड करें।',
      ],
      stepsEn: [
        'Open **sewasetu.assam.gov.in** and log in with mobile OTP.',
        'Select PRC, Caste, or Income Certificate and attach supporting documents.',
        'Pay the fee and download your digitally signed certificate.',
      ],
    },
  },
  {
    value: '🇮🇳 India - Jammu & Kashmir',
    label: '🇮🇳 Jammu & Kashmir (जम्मू-कश्मीर)',
    flag: '🇮🇳',
    scope: 'india',
    shortName: 'Jammu & Kashmir',
    domainHint: 'serviceonline.gov.in',
    portals: [
      {
        name: 'e-UNNAT / JanSugam J&K Citizen Portal',
        url: 'https://serviceonline.gov.in/',
        domain: 'serviceonline.gov.in',
        category: 'Citizen Services',
        description: 'जम्मू और कश्मीर ई-उन्नत / जनसुगम पोर्टल — Domicile, Category व Income प्रमाण पत्र।',
      },
      {
        name: 'JKSSB & JKPSC Official Portal',
        url: 'https://jkssb.nic.in/',
        domain: 'jkssb.nic.in',
        category: 'UT Recruitment',
        description: 'जम्मू और कश्मीर सेवा चयन बोर्ड भर्ती पोर्टल।',
      },
    ],
    citizenGuide: {
      portalName: 'e-UNNAT / JanSugam J&K (ServicePlus)',
      portalDomain: 'serviceonline.gov.in',
      portalUrl: 'https://serviceonline.gov.in/',
      feeSummaryHi: '₹0 से ₹30 (e-UNNAT / ServicePlus पोर्टल शुल्क)',
      feeSummaryEn: '₹0 to ₹30 on e-UNNAT / JanSugam J&K',
      documentsHi: 'आधार कार्ड, राशन कार्ड, PRC / 15-वर्ष निवास प्रमाण, फोटो',
      documentsEn: 'Aadhaar Card, Ration Card, PRC / 15-Year Residence Proof, Photo',
      stepsHi: [
        'नीचे दिए हरे बटन से **serviceonline.gov.in** (JanSugam J&K) खोलें और MeriPehchaan से लॉगिन करें।',
        'Domicile Certificate (J&K), Category या Income Certificate चुनें और दस्तावेज़ अपलोड करें।',
        'सबमिट कर डिजिटल हस्ताक्षरित सर्टिफिकेट डाउनलोड करें।',
      ],
      stepsEn: [
        'Open **serviceonline.gov.in** (JanSugam J&K) and log in via MeriPehchaan.',
        'Apply for Domicile, Category, or Income Certificate and upload proofs.',
        'Submit and download your digitally signed certificate.',
      ],
    },
  },
  {
    value: '🇮🇳 India - Goa & Other States/UTs',
    label: '🇮🇳 Goa, North-East & UTs',
    flag: '🇮🇳',
    scope: 'india',
    shortName: 'Goa, North-East & UTs',
    domainHint: 'serviceonline.gov.in',
    portals: [
      {
        name: 'ServicePlus National Citizen Portal (Goa / NE / UTs)',
        url: 'https://serviceonline.gov.in/',
        domain: 'serviceonline.gov.in',
        category: 'Citizen Services',
        description: 'गोवा, सिक्किम, त्रिपुरा, मणिपुर, मेघालय, नागालैंड, मिजोरम, अरुणाचल, चंडीगढ़, लद्दाख व पुदुचेरी के लिए आधिकारिक ServicePlus / e-District पोर्टल।',
      },
      {
        name: 'India.gov.in State & UT Directory',
        url: 'https://www.india.gov.in/my-government/states-and-union-territories',
        domain: 'india.gov.in',
        category: 'States & UTs',
        description: 'सभी राज्यों और केंद्र शासित प्रदेशों की आधिकारिक सरकारी वेबसाइट निर्देशिका।',
      },
    ],
    citizenGuide: {
      portalName: 'ServicePlus / State e-District Portal (Goa, NE & UTs)',
      portalDomain: 'serviceonline.gov.in',
      portalUrl: 'https://serviceonline.gov.in/',
      feeSummaryHi: '₹0 से ₹50 (संबंधित राज्य/UT के ServicePlus या CSC पोर्टल के अनुसार)',
      feeSummaryEn: '₹0 to ₹50 as per respective State/UT ServicePlus or e-District portal',
      documentsHi: 'आधार कार्ड, निवास/राशन कार्ड, स्व-घोषणा पत्र और पासपोर्ट साइज फोटो',
      documentsEn: 'Aadhaar Card, Residence/Ration Card, Self-Declaration, Passport Photo',
      stepsHi: [
        'नीचे दिए हरे बटन से **serviceonline.gov.in** खोलें और अपना राज्य/UT (जैसे Goa, Chandigarh, Tripura, Ladakh, Puducherry) चुनें।',
        'MeriPehchaan से लॉगिन कर जाति, निवास या आय प्रमाण पत्र सेवा चुनें।',
        'दस्तावेज़ अपलोड कर शुल्क जमा करें और डिजिटल सर्टिफिकेट डाउनलोड करें।',
      ],
      stepsEn: [
        'Open **serviceonline.gov.in**, choose your State/UT, and log in via MeriPehchaan.',
        'Select Domicile, Caste, or Income Certificate and attach required proofs.',
        'Pay the applicable fee and download your digitally signed PDF.',
      ],
    },
  },
];

export const GLOBAL_REGIONS: RegionOption[] = [
  {
    value: '🌐 Global / World',
    label: '🌐 Global / All Countries',
    flag: '🌐',
    scope: 'global',
    shortName: 'Global / World',
    domainHint: '.gov.in / .gov',
    portals: [
      {
        name: 'National Government Services Portal (India) & Global Hub',
        url: 'https://services.india.gov.in/',
        domain: 'services.india.gov.in',
        category: 'Citizen Services Hub',
        description: 'भारत के सभी राज्यों (e-District / e-Mitra / ServicePlus) तथा विश्व के प्रमुख राष्ट्रीय ई-गवर्नमेंट पोर्टल्स का मार्गदर्शन।',
      },
    ],
  },
  {
    value: '🇺🇸 United States (USA)',
    label: '🇺🇸 United States (USA)',
    flag: '🇺🇸',
    scope: 'global',
    shortName: 'USA',
    domainHint: 'usa.gov / uscis.gov',
    portals: [
      {
        name: 'USA.gov — Official Guide to U.S. Government',
        url: 'https://www.usa.gov/',
        domain: 'usa.gov',
        category: 'US Citizen Portal',
        description: 'Official U.S. government portal for Social Security (ssa.gov), U.S. Passports, taxes (IRS), federal jobs (USAJOBS), and benefits.',
      },
      {
        name: 'USCIS — U.S. Citizenship and Immigration Services',
        url: 'https://www.uscis.gov/',
        domain: 'uscis.gov',
        category: 'Visa & Immigration',
        description: 'Official USCIS portal for H-1B, F-1, Green Cards, Work Permits (EAD), and N-400 citizenship.',
      },
    ],
    citizenGuide: {
      portalName: 'USA.gov & USCIS (United States Official Citizen Portals)',
      portalDomain: 'usa.gov',
      portalUrl: 'https://www.usa.gov/',
      feeSummaryHi: 'सामाजिक सुरक्षा (SSN) सेवाएँ $0 | अमेरिकी पासपोर्ट $130–$165 | USCIS वीज़ा/ग्रीन कार्ड आवेदन $185–$1,440 (USD)',
      feeSummaryEn: 'Social Security (SSA) $0 | U.S. Passport $130–$165 | USCIS Immigration / Visa filings $185–$1,440 (USD)',
      documentsHi: 'वैध पासपोर्ट, I-94 / वीज़ा या वैध पहचान पत्र, Social Security Number (SSN), पते का प्रमाण व फॉर्म के अनुसार शुल्क',
      documentsEn: 'Valid Passport / Photo ID, Social Security Number (SSN) or A-Number, I-94 / Visa record, Proof of U.S. Address',
      stepsHi: [
        'नीचे दिए हरे बटन से **usa.gov** (या इमिग्रेशन व वीज़ा के लिए **uscis.gov**) खोलें।',
        'आवश्यक सरकारी सेवा चुनें (जैसे Social Security, Tax/IRS, Passports या USCIS Form) और अपना **Login.gov** / USCIS अकाउंट बनाएं।',
        'ऑनलाइन फॉर्म भरकर दस्तावेज़ अपलोड करें, निर्धारित USD शुल्क जमा करें और रसीद नंबर ट्रैक करें।',
      ],
      stepsEn: [
        'Open **usa.gov** (or **uscis.gov** for visas & immigration) via the button below.',
        'Sign in with **Login.gov** or your USCIS Online Account and choose the required federal service.',
        'Complete the online form, upload documents, pay the USD filing fee, and track your case receipt number.',
      ],
    },
  },
  {
    value: '🇬🇧 United Kingdom (UK)',
    label: '🇬🇧 United Kingdom (UK)',
    flag: '🇬🇧',
    scope: 'global',
    shortName: 'UK',
    domainHint: 'gov.uk',
    portals: [
      {
        name: 'GOV.UK — UK Government Services & Visas',
        url: 'https://www.gov.uk/',
        domain: 'gov.uk',
        category: 'UK Citizen Portal',
        description: 'Official UK national citizen portal for GOV.UK One Login, Visas & Immigration, Passports, DVLA Driving Licence, NHS, and HMRC Tax.',
      },
    ],
    citizenGuide: {
      portalName: 'GOV.UK (UK National Citizen Portal)',
      portalDomain: 'gov.uk',
      portalUrl: 'https://www.gov.uk/',
      feeSummaryHi: 'UK पासपोर्ट £88.50 (ऑनलाइन) | DVLA ड्राइविंग लाइसेंस £34 | UK वीज़ा शुल्क £115 से £1,500+ (GBP)',
      feeSummaryEn: 'UK Passport £88.50 online | DVLA Driving Licence £34 | UK Visas £115–£1,500+ (GBP)',
      documentsHi: 'पासपोर्ट / BRP या eVisa शेयर कोड, National Insurance Number (NINO), UK पते का प्रमाण व बायोमेट्रिक विवरण',
      documentsEn: 'Passport / eVisa Share Code, National Insurance Number (NINO), UK Address Proof, GOV.UK One Login',
      stepsHi: [
        'नीचे दिए हरे बटन से **gov.uk** खोलें और **GOV.UK One Login** से साइन-इन करें।',
        'आवश्यक सेवा (Visas & Immigration, Passports, Driving/DVLA, या HMRC Tax) चुनें।',
        'ऑनलाइन आवेदन भरें, दस्तावेज़/बायोमेट्रिक सत्यापित करें और GBP शुल्क जमा कर डिजिटल कन्फर्मेशन प्राप्त करें।',
      ],
      stepsEn: [
        'Open **gov.uk** via the button below and sign in using **GOV.UK One Login**.',
        'Select your service (Visas & Immigration, Passports, DVLA Driving, or HMRC).',
        'Submit your application, complete identity verification, pay the GBP fee, and track status online.',
      ],
    },
  },
  {
    value: '🇦🇪 United Arab Emirates (UAE)',
    label: '🇦🇪 United Arab Emirates (UAE)',
    flag: '🇦🇪',
    scope: 'global',
    shortName: 'UAE',
    domainHint: 'u.ae / icp.gov.ae',
    portals: [
      {
        name: 'U.AE & ICP Smart Services — UAE Official Portal',
        url: 'https://u.ae/',
        domain: 'u.ae',
        category: 'UAE Citizen Portal',
        description: 'Official UAE government portal for UAE Pass, ICP Smart Services (icp.gov.ae), Emirates ID, Golden Visa, and MOHRE permits.',
      },
      {
        name: 'ICP Smart Services (Federal Authority for Identity & Citizenship)',
        url: 'https://smartservices.icp.gov.ae/',
        domain: 'icp.gov.ae',
        category: 'Emirates ID & Visas',
        description: 'Official ICP portal for Emirates ID renewal/issuance, Residence Visa, and UAE entry permits.',
      },
    ],
    citizenGuide: {
      portalName: 'UAE Pass & ICP Smart Services (u.ae / icp.gov.ae)',
      portalDomain: 'u.ae',
      portalUrl: 'https://u.ae/',
      feeSummaryHi: 'Emirates ID AED 170–370+ | रेजिडेंस / गोल्डन वीज़ा सेवाएँ AED 2,800–3,800+ | सामान्य प्रमाण पत्र AED 50–150',
      feeSummaryEn: 'Emirates ID AED 170–370+ | Residence/Golden Visa AED 2,800–3,800+ | Govt Attestations AED 50–150 (AED)',
      documentsHi: 'UAE Pass डिजिटल आईडी, Emirates ID, वैध पासपोर्ट (6 माह वैधता), रेजिडेंस वीज़ा / एंट्री परमिट व मेडिकल फिटनेस रिपोर्ट',
      documentsEn: 'UAE Pass account, Emirates ID, Valid Passport (6+ months), Residence Visa / Entry Permit, Photo',
      stepsHi: [
        'नीचे दिए हरे बटन से **u.ae** (या सीधे **smartservices.icp.gov.ae**) खोलें और **UAE PASS** से लॉगिन करें।',
        'Emirates ID, Visa Renewal, Golden Visa या MOHRE/GDRFA सेवा चुनें।',
        'दस्तावेज़ अपलोड कर निर्धारित AED शुल्क जमा करें और UAE Pass / डिजिटल वॉलेट में e-ID व वीज़ा प्राप्त करें।',
      ],
      stepsEn: [
        'Open **u.ae** (or **smartservices.icp.gov.ae**) and log in securely using **UAE PASS**.',
        'Select Emirates ID, Visa Issuance/Renewal, or MOHRE public services.',
        'Upload documents, pay the AED fee online, and receive your digital Emirates ID / e-Visa.',
      ],
    },
  },
  {
    value: '🇸🇦 Saudi Arabia',
    label: '🇸🇦 Saudi Arabia (KSA)',
    flag: '🇸🇦',
    scope: 'global',
    shortName: 'Saudi Arabia',
    domainHint: 'absher.sa / my.gov.sa',
    portals: [
      {
        name: 'Absher (أبشر) — Saudi Ministry of Interior e-Services',
        url: 'https://www.absher.sa/',
        domain: 'absher.sa',
        category: 'Saudi Digital Portal',
        description: 'Official Saudi Absher platform for Iqama renewal, Exit/Re-Entry visa, Driving Licence, Traffic & Civil Affairs.',
      },
      {
        name: 'MY.GOV.SA — Saudi Unified National Platform',
        url: 'https://www.my.gov.sa/',
        domain: 'my.gov.sa',
        category: 'Saudi Govt',
        description: 'Official Saudi government platform linking Absher, Qiwa, Nafath, and residency e-services.',
      },
    ],
    citizenGuide: {
      portalName: 'Absher & MY.GOV.SA (Saudi Digital Citizen Portal)',
      portalDomain: 'absher.sa',
      portalUrl: 'https://www.absher.sa/',
      feeSummaryHi: 'इकामा (Iqama) नवीनीकरण SAR 500–650/वर्ष | Exit/Re-Entry वीज़ा SAR 200+ | नागरिक प्रमाण पत्र SAR 0–100',
      feeSummaryEn: 'Iqama Renewal SAR 500–650/yr | Exit/Re-Entry Visa SAR 200+ | Saudi Passports SAR 300–600 (SAR)',
      documentsHi: 'Absher / Nafath (نفاذ) लॉगिन, वैध Iqama या National ID, पासपोर्ट विवरण और SADAD भुगतान नंबर',
      documentsEn: 'Absher & Nafath Digital ID, Valid Iqama / Saudi National ID, Passport details, SADAD fee payment',
      stepsHi: [
        'नीचे दिए हरे बटन से **absher.sa** (या **my.gov.sa**) खोलें और **Absher Individuals / Nafath** से लॉगिन करें।',
        'Passports (Jawazat), Civil Affairs (Ahwal) या Traffic सेवा (जैसे Iqama / Exit Re-Entry / Driving Licence) चुनें।',
        'SADAD से संबंधित SAR शुल्क जमा कर सेवा कन्फर्म करें और डिजिटल कॉपी डाउनलोड करें।',
      ],
      stepsEn: [
        'Open **absher.sa** (or **my.gov.sa**) via the button below and sign in using **Absher / Nafath**.',
        'Choose Jawazat (Passports/Iqama), Ahwal (Civil Affairs), or Traffic e-services.',
        'Pay the applicable SAR fee via SADAD and get your instant digital confirmation.',
      ],
    },
  },
  {
    value: '🇨🇦 Canada',
    label: '🇨🇦 Canada',
    flag: '🇨🇦',
    scope: 'global',
    shortName: 'Canada',
    domainHint: 'canada.ca / .gc.ca',
    portals: [
      {
        name: 'Canada.ca — Official Government of Canada & IRCC Portal',
        url: 'https://www.canada.ca/en/services.html',
        domain: 'canada.ca',
        category: 'Canada Citizen Portal',
        description: 'Official Government of Canada portal for Service Canada (SIN, EI), CRA Taxes, and IRCC Express Entry / Study & Work Permits.',
      },
    ],
    citizenGuide: {
      portalName: 'Canada.ca — Service Canada & IRCC',
      portalDomain: 'canada.ca',
      portalUrl: 'https://www.canada.ca/en/services.html',
      feeSummaryHi: 'SIN (Social Insurance Number) $0 | Study Permit CAD $150 | Work Permit CAD $155 | Express Entry PR CAD $1,525',
      feeSummaryEn: 'SIN Application $0 | Study Permit CAD $150 | Work Permit CAD $155 | Express Entry PR CAD $1,525 (CAD)',
      documentsHi: 'वैध पासपोर्ट, GCKey या Sign-In Partner लॉगिन, Study/Work/PR दस्तावेज़, बायोमेट्रिक्स (CAD $85) व CRA/SIN विवरण',
      documentsEn: 'Valid Passport, GCKey / Interac Sign-In Partner, Biometrics, Supporting Immigration/SIN proofs',
      stepsHi: [
        'नीचे दिए हरे बटन से **canada.ca** खोलें और **GCKey** या My Service Canada Account से साइन-इन करें।',
        'आवश्यक सेवा (IRCC Visa/PR, Service Canada SIN, या CRA My Account) चुनें।',
        'फॉर्म व दस्तावेज़ अपलोड कर CAD शुल्क ऑनलाइन जमा करें और पोर्टल पर स्टेटस ट्रैक करें।',
      ],
      stepsEn: [
        'Open **canada.ca** via the button below and sign in with **GCKey** or Sign-In Partner.',
        'Select IRCC (Immigration/Permits), Service Canada (SIN/Benefits), or CRA.',
        'Upload documents, pay the CAD fee online, and monitor your application portal.',
      ],
    },
  },
  {
    value: '🇦🇺 Australia',
    label: '🇦🇺 Australia',
    flag: '🇦🇺',
    scope: 'global',
    shortName: 'Australia',
    domainHint: 'my.gov.au / homeaffairs.gov.au',
    portals: [
      {
        name: 'myGov Australia — Official Digital Citizen Portal',
        url: 'https://my.gov.au/',
        domain: 'my.gov.au',
        category: 'Australia Citizen Portal',
        description: 'Official Australian Government myGov portal linking Medicare, ATO Tax, Centrelink, and Digital ID citizen services.',
      },
      {
        name: 'Department of Home Affairs — Visas & Citizenship',
        url: 'https://immi.homeaffairs.gov.au/',
        domain: 'immi.homeaffairs.gov.au',
        category: 'Visa & Migration',
        description: 'Official ImmiAccount portal for Student Visas, Skilled Migration, and Australian Citizenship.',
      },
    ],
    citizenGuide: {
      portalName: 'myGov Australia & Home Affairs (my.gov.au)',
      portalDomain: 'my.gov.au',
      portalUrl: 'https://my.gov.au/',
      feeSummaryHi: 'myGov / Medicare / ATO टैक्स सेवाएँ AUD $0 | Visitor Visa AUD $195 | Student Visa AUD $1,600 (AUD)',
      feeSummaryEn: 'myGov / Medicare / ATO $0 | Visitor Visa AUD $195 | Student Visa (Subclass 500) AUD $1,600 (AUD)',
      documentsHi: 'myGov Digital ID, पासपोर्ट / ImmiAccount, Tax File Number (TFN), Medicare कार्ड व पते का प्रमाण',
      documentsEn: 'myGov Account / myID, Valid Passport, Tax File Number (TFN), Medicare / ImmiAccount details',
      stepsHi: [
        'नीचे दिए हरे बटन से **my.gov.au** (या वीज़ा के लिए **immi.homeaffairs.gov.au**) खोलें।',
        'Medicare, ATO, Centrelink या ImmiAccount लिंक करके सेवा चुनें।',
        'ऑनलाइन आवेदन भरें, दस्तावेज़ अपलोड करें और लागू होने पर AUD शुल्क जमा करें।',
      ],
      stepsEn: [
        'Open **my.gov.au** (or **immi.homeaffairs.gov.au** for visas) via the button below.',
        'Sign in and access linked government services (Medicare, ATO, Centrelink, or ImmiAccount).',
        'Complete the digital form, attach documents, and pay any applicable AUD visa fee.',
      ],
    },
  },
  {
    value: '🇸🇬 Singapore',
    label: '🇸🇬 Singapore',
    flag: '🇸🇬',
    scope: 'global',
    shortName: 'Singapore',
    domainHint: 'singpass.gov.sg / gov.sg',
    portals: [
      {
        name: 'Singpass & Gov.sg — Singapore Official Digital Portal',
        url: 'https://www.singpass.gov.sg/',
        domain: 'singpass.gov.sg',
        category: 'Singapore Citizen Portal',
        description: 'Official Singapore digital identity (Singpass) & Gov.sg portal accessing ICA, MOM Work Passes, CPF, and IRAS Tax services.',
      },
      {
        name: 'Gov.sg — Singapore Government Directory',
        url: 'https://www.gov.sg/',
        domain: 'gov.sg',
        category: 'Singapore Govt',
        description: 'Official Singapore Government portal for public services, MOM passes, and citizen guides.',
      },
    ],
    citizenGuide: {
      portalName: 'Singpass & Gov.sg (Singapore Citizen Portal)',
      portalDomain: 'singpass.gov.sg',
      portalUrl: 'https://www.singpass.gov.sg/',
      feeSummaryHi: 'NRIC / पास सेवाएँ SGD $10–$60 | Employment Pass आवेदन SGD $105 + जारी शुल्क SGD $225 (SGD)',
      feeSummaryEn: 'ICA NRIC/Cert services SGD $10–$60 | MOM Employment Pass SGD $105–$225 (SGD)',
      documentsHi: 'Singpass ऐप (Myinfo डिजिटल प्रोफाइल), NRIC / FIN नंबर, वैध पासपोर्ट और रोजगार/निवास विवरण',
      documentsEn: 'Singpass App (Myinfo), NRIC or FIN, Valid Passport, Employment/Residence details',
      stepsHi: [
        'नीचे दिए हरे बटन से **singpass.gov.sg** (या **gov.sg**) खोलें और **Singpass QR** से लॉगिन करें।',
        'Myinfo के ज़रिए स्वतः भरी जानकारी के साथ ICA, MOM या IRAS सेवा चुनें।',
        'निर्धारित SGD शुल्क PayNow/कार्ड से जमा करें और डिजिटल सर्टिफिकेट प्राप्त करें।',
      ],
      stepsEn: [
        'Open **singpass.gov.sg** (or **gov.sg**) and log in via the Singpass app.',
        'Auto-fill verified personal details via **Myinfo** for ICA, MOM, or IRAS e-services.',
        'Pay the SGD fee via PayNow/card and download your digital pass or certificate.',
      ],
    },
  },
  {
    value: '🇩🇪 Germany',
    label: '🇩🇪 Germany (Deutschland)',
    flag: '🇩🇪',
    scope: 'global',
    shortName: 'Germany',
    domainHint: 'id.bund.de / make-it-in-germany.com',
    portals: [
      {
        name: 'BundID — Official German Federal Citizen Portal',
        url: 'https://id.bund.de/',
        domain: 'id.bund.de',
        category: 'Germany Citizen Portal',
        description: 'Official German federal citizen account (BundID) for municipal e-services, tax (ELSTER), and online government applications.',
      },
      {
        name: 'Make it in Germany — Official German Migration Portal',
        url: 'https://www.make-it-in-germany.com/en/',
        domain: 'make-it-in-germany.com',
        category: 'Visa & Work',
        description: 'Official German government portal for Opportunity Card (Chancenkarte), EU Blue Card, work visas, and universities.',
      },
    ],
    citizenGuide: {
      portalName: 'BundID & Make it in Germany (id.bund.de)',
      portalDomain: 'id.bund.de',
      portalUrl: 'https://id.bund.de/',
      feeSummaryHi: 'Personalausweis €37 | रेजिडेंस परमिट / Chancenkarte / EU Blue Card €75–€110 | डिजिटल प्रमाण पत्र €0–€15 (EUR)',
      feeSummaryEn: 'Personalausweis €37 | Residence Permit / Blue Card / Chancenkarte €75–€110 | Digital services €0–€15 (EUR)',
      documentsHi: 'BundID अकाउंट / eID, वैध पासपोर्ट, Anmeldebestätigung (पता पंजीकरण), बायोमेट्रिक फोटो व स्वास्थ्य बीमा प्रमाण',
      documentsEn: 'BundID / eID card, Valid Passport, Meldebescheinigung (address registration), Biometric Photo, Health Insurance',
      stepsHi: [
        'नीचे दिए हरे बटन से **id.bund.de** (या वीज़ा/नौकरी के लिए **make-it-in-germany.com**) खोलें।',
        'अपना **BundID** डिजिटल नागरिक अकाउंट बनाकर संबंधित राज्य/नगरपालिका (Bürgeramt / Ausländerbehörde) सेवा चुनें।',
        'दस्तावेज़ अपलोड कर EUR शुल्क जमा करें और डिजिटल पोस्टबॉक्स में पुष्टि प्राप्त करें।',
      ],
      stepsEn: [
        'Open **id.bund.de** (or **make-it-in-germany.com** for visa & work pathways).',
        'Sign in with your **BundID** account and select the federal/municipal e-service.',
        'Upload documents, pay the applicable EUR fee, and receive official notices in your BundID inbox.',
      ],
    },
  },
  {
    value: '🇫🇷 France',
    label: '🇫🇷 France',
    flag: '🇫🇷',
    scope: 'global',
    shortName: 'France',
    domainHint: 'service-public.fr',
    portals: [
      {
        name: 'Service-Public.fr — Official French Citizen Portal',
        url: 'https://www.service-public.fr/',
        domain: 'service-public.fr',
        category: 'France Citizen Portal',
        description: 'Official French government portal (FranceConnect) for civil certificates, taxes, residence permits, and public rights.',
      },
      {
        name: 'France-Visas — Official Visa Portal',
        url: 'https://france-visas.gouv.fr/',
        domain: 'france-visas.gouv.fr',
        category: 'France Visas',
        description: 'Official French government portal for Schengen visas, Campus France admissions, and work permits.',
      },
    ],
    citizenGuide: {
      portalName: 'Service-Public.fr & FranceConnect',
      portalDomain: 'service-public.fr',
      portalUrl: 'https://www.service-public.fr/',
      feeSummaryHi: 'जन्म/नागरिक प्रमाण पत्र €0 (फ्री) | Schengen वीज़ा €90 | Long-Stay वीज़ा €99 (EUR)',
      feeSummaryEn: 'Civil status certificates €0 | Schengen Visa €90 | Long-Stay Visa €99 (EUR)',
      documentsHi: 'FranceConnect लॉगिन, वैध पासपोर्ट / Carte Nationale d’Identité, Justificatif de domicile (पता प्रमाण)',
      documentsEn: 'FranceConnect ID, Valid Passport / National ID, Justificatif de domicile (Address Proof)',
      stepsHi: [
        'नीचे दिए हरे बटन से **service-public.fr** (या **france-visas.gouv.fr**) खोलें और **FranceConnect** से लॉगिन करें।',
        'आवश्यक नागरिक प्रमाण पत्र या वीज़ा सेवा चुनकर फॉर्म भरें।',
        'दस्तावेज़ संलग्न कर सबमिट करें और डिजिटल प्रति डाउनलोड करें।',
      ],
      stepsEn: [
        'Open **service-public.fr** (or **france-visas.gouv.fr**) and log in via **FranceConnect**.',
        'Choose your civil service or visa form and attach proof of address/identity.',
        'Submit online and download your official digital certificate.',
      ],
    },
  },
  {
    value: '🇯🇵 Japan',
    label: '🇯🇵 Japan (日本)',
    flag: '🇯🇵',
    scope: 'global',
    shortName: 'Japan',
    domainHint: 'japan.go.jp / myna.go.jp',
    portals: [
      {
        name: 'JapanGov & Mynaportal — Official Japan Citizen Portals',
        url: 'https://www.japan.go.jp/',
        domain: 'japan.go.jp',
        category: 'Japan Citizen Portal',
        description: 'Official Government of Japan portal linking My Number Portal (myna.go.jp), ISA Immigration, and public services.',
      },
    ],
    citizenGuide: {
      portalName: 'JapanGov & My Number Portal (japan.go.jp)',
      portalDomain: 'japan.go.jp',
      portalUrl: 'https://www.japan.go.jp/',
      feeSummaryHi: 'Juminhyo / प्रमाण पत्र ¥200–¥300 | वीज़ा एक्सटेंशन / स्टेटस परिवर्तन ¥4,000–¥6,000 (JPY)',
      feeSummaryEn: 'Residence Cert (Juminhyo) ¥200–¥300 | Visa Extension/Change ¥4,000–¥6,000 (JPY)',
      documentsHi: 'My Number Card (マイナンバーカード), Residence Card (在留カード), वैध पासपोर्ट व पते का विवरण',
      documentsEn: 'My Number Card, Residence Card (Zairyu Card), Valid Passport',
      stepsHi: [
        'नीचे दिए हरे बटन से **japan.go.jp** (या ऑनलाइन नागरिक सेवाओं हेतु **myna.go.jp**) खोलें।',
        'My Number Card से पहचान सत्यापित कर आवश्यक नगरपालिका या इमिग्रेशन सेवा चुनें।',
        'निर्धारित JPY शुल्क जमा कर प्रमाण पत्र प्राप्त करें।',
      ],
      stepsEn: [
        'Open **japan.go.jp** (or **myna.go.jp** for My Number e-services) via the button below.',
        'Verify with your My Number Card and select municipal or immigration services.',
        'Submit your application and pay the applicable JPY fee.',
      ],
    },
  },
  {
    value: '🇳🇿 New Zealand',
    label: '🇳🇿 New Zealand',
    flag: '🇳🇿',
    scope: 'global',
    shortName: 'New Zealand',
    domainHint: 'govt.nz / immigration.govt.nz',
    portals: [
      {
        name: 'Govt.nz & RealMe — New Zealand Citizen Portal',
        url: 'https://www.govt.nz/',
        domain: 'govt.nz',
        category: 'NZ Citizen Portal',
        description: 'Official New Zealand Government portal with RealMe verified digital identity for passports, certificates, IRD tax, and visas.',
      },
      {
        name: 'Immigration New Zealand',
        url: 'https://www.immigration.govt.nz/',
        domain: 'immigration.govt.nz',
        category: 'NZ Immigration',
        description: 'Official Immigration New Zealand portal for Accredited Employer Work Visa and Student Visas.',
      },
    ],
    citizenGuide: {
      portalName: 'Govt.nz & RealMe (New Zealand Official Portal)',
      portalDomain: 'govt.nz',
      portalUrl: 'https://www.govt.nz/',
      feeSummaryHi: 'नागरिक प्रमाण पत्र NZD $33 | Student Visa NZD $750 | Work Visa NZD $1,540 (NZD)',
      feeSummaryEn: 'Birth/Marriage Certificates NZD $33 | Student Visa NZD $750 | Work Visa NZD $1,540 (NZD)',
      documentsHi: 'RealMe वेरिफाइड अकाउंट, वैध पासपोर्ट, IRD नंबर व पते का प्रमाण',
      documentsEn: 'RealMe verified account, Valid Passport, IRD Number, Address proof',
      stepsHi: [
        'नीचे दिए हरे बटन से **govt.nz** (या वीज़ा के लिए **immigration.govt.nz**) खोलें और **RealMe** से लॉगिन करें।',
        'आवश्यक नागरिक या इमिग्रेशन सेवा चुनकर दस्तावेज़ अपलोड करें।',
        'NZD शुल्क ऑनलाइन जमा करें और डिजिटल कॉपी प्राप्त करें।',
      ],
      stepsEn: [
        'Open **govt.nz** (or **immigration.govt.nz** for visas) and sign in with **RealMe**.',
        'Select your citizen or visa service and attach supporting documents.',
        'Pay the NZD fee online and track your application.',
      ],
    },
  },
];

export const ALL_REGIONS: RegionOption[] = [...INDIA_REGIONS, ...GLOBAL_REGIONS];

export function isGlobalUnspecifiedLocation(locationValue: string): boolean {
  const lower = (locationValue || '').trim().toLowerCase();
  if (!lower) return true;
  return (
    lower.includes('global') ||
    lower.includes('all countries') ||
    lower === 'world'
  );
}

const QUERY_REGION_PATTERNS: Array<{ regionValue: string; pattern: RegExp }> = [
  { regionValue: '🇮🇳 India - Rajasthan', pattern: /\b(rajasthan|rj|sso\.rajasthan|jan\s*aadhaar|rpsc|rssb|rsmssb|jaipur|jodhpur|udaipur)\b|राजस्थान|जन\s*आधार/i },
  { regionValue: '🇮🇳 India - Madhya Pradesh', pattern: /\b(madhya\s*pradesh|mponline|mpedistrict|mppsc|mpesb|samagra|ladli\s*behna|bhopal|indore)\b|\bmp\b|मध्य\s*प्रदेश|एमपी\s*ऑनलाइन|समग्र/i },
  { regionValue: '🇮🇳 India - Uttar Pradesh', pattern: /\b(uttar\s*pradesh|uppsc|uppbpb|edistrict\s*up|jan\s*seva|bhulekh\s*up|lucknow|varanasi|noida)\b|\bup\b|उत्तर\s*प्रदेश|जनसेवा\s*केंद्र|ई-साथी/i },
  { regionValue: '🇮🇳 India - Bihar', pattern: /\b(bihar|rtps|bpsc|serviceonline\.bihar|patna|vasudha\s*kendra)\b|बिहार|आवासीय\s*प्रमाण/i },
  { regionValue: '🇮🇳 India - Maharashtra', pattern: /\b(maharashtra|aaple\s*sarkar|mahaonline|mahadbt|mpsc|mumbai|pune|nagpur|setu\s*kendra)\b|महाराष्ट्र|आपले\s*सरकार/i },
  { regionValue: '🇮🇳 India - Delhi (NCT)', pattern: /\b(delhi|dsssb|edistrict\.delhigovt|new\s*delhi)\b|दिल्ली/i },
  { regionValue: '🇮🇳 India - Gujarat', pattern: /\b(gujarat|digital\s*gujarat|gpsc|gsssb|ahmedabad|surat|vadodara)\b|गुजरात|डिजिटल\s*गुजरात/i },
  { regionValue: '🇮🇳 India - Haryana', pattern: /\b(haryana|saral\s*haryana|saralharyana|parivar\s*pehchan|ppp|hssc|hpsc|gurugram|faridabad)\b|हरियाणा|सरल\s*हरियाणा|परिवार\s*पहचान/i },
  { regionValue: '🇮🇳 India - Chhattisgarh', pattern: /\b(chhattisgarh|cgstate|cgpsc|cg\s*vyapam|raipur|choice\s*centre)\b|\bcg\b|छत्तीसगढ़/i },
  { regionValue: '🇮🇳 India - Punjab', pattern: /\b(punjab|sewa\s*connect|psssb|ppsc|amritsar|ludhiana)\b|पंजाब/i },
  { regionValue: '🇮🇳 India - West Bengal', pattern: /\b(west\s*bengal|wbpsc|banglar\s*sahayata|kolkata|wb)\b|पश्चिम\s*बंगाल|बंगाल/i },
  { regionValue: '🇮🇳 India - Tamil Nadu', pattern: /\b(tamil\s*nadu|tnesevai|tnega|tnpsc|chennai)\b|तमिलनाडु/i },
  { regionValue: '🇮🇳 India - Karnataka', pattern: /\b(karnataka|seva\s*sindhu|nadakacheri|kpsc|bengaluru|bangalore)\b|कर्नाटक|सेवा\s*सिंधु/i },
  { regionValue: '🇮🇳 India - Kerala', pattern: /\b(kerala|akshaya|keralapsc|kochi|thiruvananthapuram)\b|केरल/i },
  { regionValue: '🇮🇳 India - Telangana', pattern: /\b(telangana|meeseva\s*telangana|tspsc|tgpsc|hyderabad)\b|तेलंगाना/i },
  { regionValue: '🇮🇳 India - Andhra Pradesh', pattern: /\b(andhra\s*pradesh|appsc|sachivalayam|vsws|amaravati|vijayawada)\b|आंध्र\s*प्रदेश/i },
  { regionValue: '🇮🇳 India - Odisha', pattern: /\b(odisha|orissa|opsc|mo\s*seba|bhubaneswar)\b|ओडिशा/i },
  { regionValue: '🇮🇳 India - Jharkhand', pattern: /\b(jharkhand|jharsewa|jssc|jpsc|pragya\s*kendra|ranchi)\b|झारखंड|झारसेवा/i },
  { regionValue: '🇮🇳 India - Uttarakhand', pattern: /\b(uttarakhand|apuni\s*sarkar|ukpsc|uksssc|dehradun)\b|उत्तराखंड|अपनी\s*सरकार/i },
  { regionValue: '🇮🇳 India - Himachal Pradesh', pattern: /\b(himachal|himachal\s*pradesh|bonafide\s*himachali|hppsc|shimla)\b|हिमाचल/i },
  { regionValue: '🇮🇳 India - Assam', pattern: /\b(assam|sewa\s*setu|sewasetu|apsc|guwahati)\b|असम/i },
  { regionValue: '🇮🇳 India - Jammu & Kashmir', pattern: /\b(jammu|kashmir|j&k|e-?unnat|jansugam|jkssb|jkpsc|srinagar)\b|जम्मू|कश्मीर/i },
  { regionValue: '🇮🇳 India - Goa & Other States/UTs', pattern: /\b(goa|chandigarh|puducherry|ladakh|sikkim|tripura|manipur|meghalaya|nagaland|mizoram|arunachal)\b|गोवा|चंडीगढ़|लद्दाख/i },
  { regionValue: '🇦🇪 United Arab Emirates (UAE)', pattern: /\b(uae|united\s*arab\s*emirates|dubai|abu\s*dhabi|emirates\s*id|uae\s*pass|icp|mohre|golden\s*visa)\b|दुबई|यूएई/i },
  { regionValue: '🇸🇦 Saudi Arabia', pattern: /\b(saudi|saudi\s*arabia|ksa|absher|iqama|nafath|jawazat|riyadh)\b|सऊदी/i },
  { regionValue: '🇺🇸 United States (USA)', pattern: /\b(usa|u\.s\.a\.|united\s*states|america|uscis|usa\.gov|social\s*security|h-?1b|green\s*card)\b|अमेरिका/i },
  { regionValue: '🇬🇧 United Kingdom (UK)', pattern: /\b(uk|u\.k\.|united\s*kingdom|britain|england|gov\.uk|dvla|hmrc|nhs)\b|ब्रिटेन|इंग्लैंड/i },
  { regionValue: '🇨🇦 Canada', pattern: /\b(canada|ircc|express\s*entry|gckey|service\s*canada)\b|कनाडा/i },
  { regionValue: '🇦🇺 Australia', pattern: /\b(australia|mygov|my\.gov\.au|immiaccount|medicare|centrelink)\b|ऑस्ट्रेलिया/i },
  { regionValue: '🇸🇬 Singapore', pattern: /\b(singapore|singpass|gov\.sg|myinfo|mom\s*pass)\b|सिंगापुर/i },
  { regionValue: '🇩🇪 Germany', pattern: /\b(germany|deutschland|bundid|id\.bund|chancenkarte|blue\s*card|bürgeramt)\b|जर्मनी/i },
  { regionValue: '🇫🇷 France', pattern: /\b(france|service-public|franceconnect|france-visas|paris)\b|फ्रांस/i },
  { regionValue: '🇯🇵 Japan', pattern: /\b(japan|mext|myna\.go\.jp|my\s*number|tokyo|juminhyo)\b|जापान/i },
  { regionValue: '🇳🇿 New Zealand', pattern: /\b(new\s*zealand|realme|govt\.nz|auckland)\b|न्यूजीलैंड/i },
  { regionValue: '🇮🇳 India - All India (Central)', pattern: /\b(all\s*india|central\s*govt|services\.india\.gov\.in)\b|पूरे\s*भारत|ऑल\s*इंडिया/i },
];

export function detectRegionFromQueryOrLocation(
  query: string,
  locationValue: string
): { region: RegionOption; isAmbiguousGlobal: boolean; matchedFromQuery: boolean } {
  const cleanQuery = (query || '').trim();
  for (const entry of QUERY_REGION_PATTERNS) {
    if (entry.pattern.test(cleanQuery)) {
      const found = ALL_REGIONS.find((r) => r.value === entry.regionValue);
      if (found) {
        return { region: found, isAmbiguousGlobal: false, matchedFromQuery: true };
      }
    }
  }

  if (isGlobalUnspecifiedLocation(locationValue)) {
    return {
      region: GLOBAL_REGIONS[0],
      isAmbiguousGlobal: true,
      matchedFromQuery: false,
    };
  }

  return {
    region: findRegionOption(locationValue),
    isAmbiguousGlobal: false,
    matchedFromQuery: false,
  };
}

export function findRegionOption(locationValue: string): RegionOption {
  const exact = ALL_REGIONS.find((r) => r.value === locationValue);
  if (exact) return exact;

  const lower = (locationValue || '').toLowerCase();
  const fuzzy = ALL_REGIONS.find(
    (r) =>
      lower.includes(r.shortName.toLowerCase()) ||
      r.value.toLowerCase().includes(lower)
  );
  if (fuzzy) return fuzzy;

  if (lower.includes('india')) {
    return INDIA_REGIONS[0];
  }
  return GLOBAL_REGIONS[0];
}
