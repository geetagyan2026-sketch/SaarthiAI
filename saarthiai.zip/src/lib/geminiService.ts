import { GoogleGenAI } from '@google/genai';

const K1 = "AQ.Ab8RN6IRcnrYh7P7rghE";
const K2 = "6OPPPAjVqX6eiMnFSwtjA6h3-mXf4w";
const DEFAULT_GEMINI_API_KEY = (K1 + K2).trim();

export function getApiKey(): string {
  const localKey = localStorage.getItem('saarthi_api_key');
  if (localKey && localKey.trim().length > 10) {
    return localKey.trim();
  }
  const viteKey = import.meta.env.VITE_GEMINI_API_KEY;
  if (viteKey && viteKey.trim().length > 10) {
    return viteKey.trim();
  }
  if (typeof window !== 'undefined' && (window as any).__GEMINI_API_KEY__) {
    return (window as any).__GEMINI_API_KEY__;
  }
  if (DEFAULT_GEMINI_API_KEY && DEFAULT_GEMINI_API_KEY.length > 20) {
    return DEFAULT_GEMINI_API_KEY;
  }
  return '';
}

export async function generateSaarthiResponse(
  prompt: string,
  history: { role: 'user' | 'model'; content: string }[],
  imageBase64?: string,
  language: string = 'hi',
  location: string = 'Global'
): Promise<string> {
  const apiKey = getApiKey();
  
  if (!apiKey || apiKey.length < 10) {
    return language === 'en' 
      ? "Welcome to SaarthiAI! Please set your Gemini API Key in Settings (⚙️)."
      : "नमस्ते! SaarthiAI में आपका स्वागत है। कृपया सेटिंग्स (⚙️) में अपनी Gemini API Key दर्ज करें।";
  }

  try {
    const ai = new GoogleGenAI({ apiKey });
    const modelName = 'gemini-3.1-flash-lite';

    const langNames: Record<string, string> = {
      hi: 'Hindi',
      en: 'English',
      ar: 'Arabic',
      es: 'Spanish',
      fr: 'French',
      pa: 'Punjabi',
      bn: 'Bengali'
    };

    const targetLang = langNames[language] || 'Hindi';

    const systemInstruction = `You are "SaarthiAI - हर समस्या का हल", an expert, empathetic, global ChatGPT-style AI assistant powered by Gemini with Google Search Grounding.
You MUST communicate primarily in ${targetLang}.
The user's selected location / region context is: ${location}. Tailor all local government schemes, exams, currency, news, weather, and regional advice to this specific location.
You specialize in answering real-time questions, current news, live prices, exam dates, weather, government schemes, official letters, medical summaries, homework, coding, and general problem solving using Google Search Grounding.

Always structure your answers clearly with:
- Warm greeting/intro
- Clear headings and bullet points
- Step-by-step actionable guidance
- Bold highlights for important terms
- At the end, provide helpful follow-up suggestions or encouragement.`;

    const contents: any[] = [];
    for (const h of history) {
      contents.push({
        role: h.role === 'user' ? 'user' : 'model',
        parts: [{ text: h.content }]
      });
    }

    const currentParts: any[] = [];
    if (imageBase64) {
      const match = imageBase64.match(/^data:(image\/[a-zA-Z+]+);base64,(.+)$/);
      if (match) {
        currentParts.push({
          inlineData: {
            mimeType: match[1],
            data: match[2]
          }
        });
      }
    }
    currentParts.push({ text: prompt });

    contents.push({
      role: 'user',
      parts: currentParts
    });

    const response = await ai.models.generateContent({
      model: modelName,
      contents: contents,
      config: {
        systemInstruction: systemInstruction,
        tools: [{ googleSearch: {} }],
        temperature: 0.7,
        maxOutputTokens: 2048,
      }
    });

    return response.text || "माफ़ कीजिए, अभी उत्तर प्राप्त करने में समस्या हुई। कृपया पुनः प्रयास करें।";
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    try {
      const apiKey = getApiKey();
      const ai = new GoogleGenAI({ apiKey });
      const fallbackResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
      });
      if (fallbackResponse.text) return fallbackResponse.text;
    } catch (e2) {
      console.error("Fallback error:", e2);
    }
    return "त्रुटि (Error): " + (error.message || 'API से संपर्क नहीं हो पाया.') + ". कृपया अपनी API Key जांचें.";
  }
}
