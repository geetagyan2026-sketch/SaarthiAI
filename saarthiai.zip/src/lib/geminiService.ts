import { SourceLink } from '../types';
import { detectRegionFromQueryOrLocation } from './regions';
import { isMedicineOrHealthQuery, buildStructuredMedicineReply } from './medicineInfo';

export interface SaarthiResponse {
  text: string;
  sources: SourceLink[];
  cached?: boolean;
}

function buildOfflineDirectReply(
  prompt: string,
  language: string,
  location: string,
  hasImage: boolean = false,
  history: { role: 'user' | 'model'; content: string }[] = []
): SaarthiResponse {
  if (isMedicineOrHealthQuery(prompt, hasImage, history)) {
    return {
      text: buildStructuredMedicineReply(prompt, [], language),
      sources: [],
      cached: false,
    };
  }

  const { region, isAmbiguousGlobal } = detectRegionFromQueryOrLocation(prompt, location);
  const lower = prompt.toLowerCase();
  const isEnglish = language === 'en';

  const isPan = /\bpan\b|pancard|pan\s*card|पैन|e-?pan/i.test(lower);
  const isDriving = /driving licen|parivahan|sarathi|ड्राइविंग लाइसेंस/i.test(lower);
  const isPassport = /passport|पासपोर्ट/i.test(lower);
  const isRationAyushman = /राशन|ration|आयुष्मान|ayushman|pmjay|nfsa/i.test(lower);
  const isCitizenService =
    /जन आधार|jan aadhaar|मूल निवास|निवास प्रमाण|आवासीय प्रमाण|जाति प्रमाण|जाति|आय प्रमाण|domicile|caste|income certificate|ई-मित्र|emitra|e-mitra|e-district|नागरिक सेवा|citizen service|citizen portal|जनसेवा|आपले सरकार|सरल|rtps|सेवा सिंधु|झारसेवा|emirates id|uae pass|icp|golden visa|absher|iqama|singpass|bundid|mygov|gov\.uk|usa\.gov|uscis|social security|service-public|realme|ircc|express entry|chancenkarte|blue card|\bsin\b/i.test(
      lower
    );
  const isAdmission = /एडमिशन|admission|स्कूल|कॉलेज|college|university|cuet|scholarship|छात्रवृत्ति/i.test(lower);

  if (isPan) {
    return {
      text: [
        `नया पैन कार्ड (PAN Card) बनवाने की पूरी और सटीक जानकारी नीचे दी गई है:`,
        ``,
        `• **आधिकारिक पोर्टल:** **incometax.gov.in** (फ्री Instant e-PAN) और **onlineservices.nsdl.com** (फिजिकल पैन कार्ड डाक द्वारा)।`,
        `• **असली सरकारी फीस:**`,
        `  - **Instant e-PAN (डिजिटल पैन कार्ड):** **₹0 (बिल्कुल फ्री)** — आधार e-KYC द्वारा 10 मिनट में डाउनलोड।`,
        `  - **नया फिजिकल पैन कार्ड (NSDL / UTIITSL से घर पर डिलीवरी):** **₹107** (GST सहित, भारतीय पते के लिए)।`,
        `• **ज़रूरी डॉक्यूमेंट:**`,
        `  - **आधार कार्ड**`,
        `  - **आधार से लिंक मोबाइल नंबर** (OTP वेरिफिकेशन के लिए)`,
        `  - **2 पासपोर्ट साइज फोटो** और **सफेद कागज़ पर हस्ताक्षर (Signature)** (NSDL फॉर्म हेतु)।`,
        `• **स्टेप-बाय-स्टेप बनाने का तरीका:**`,
        `  1. नीचे दिए हरे बटन से आधिकारिक पोर्टल (**incometax.gov.in** पर *Instant e-PAN* या **onlineservices.nsdl.com** पर *Form 49A*) खोलें।`,
        `  2. अपना आधार नंबर, नाम और मोबाइल नंबर दर्ज करके OTP सत्यापन पूरा करें।`,
        `  3. जानकारी जांचकर फॉर्म सबमिट करें (फिजिकल कार्ड हेतु ₹107 ऑनलाइन भुगतान करें) और रसीद / e-PAN PDF डाउनलोड करें।`,
      ].join('\n'),
      sources: [{ title: 'incometax.gov.in', uri: 'https://www.incometax.gov.in/iec/foportal/' }],
      cached: false,
    };
  }

  if (isDriving && (isAmbiguousGlobal || region.scope === 'india')) {
    return {
      text: [
        `भारत में **ड्राइविंग लाइसेंस (LL / DL)** बनवाने की पूरी और असली जानकारी नीचे दी गई है:`,
        ``,
        `• **आधिकारिक पोर्टल:** सड़क परिवहन व राजमार्ग मंत्रालय — **parivahan.gov.in** (Sarathi Parivahan)`,
        `• **असली सरकारी फीस:** लर्निंग लाइसेंस (LL): **₹150–₹200** | परमानेंट ड्राइविंग लाइसेंस (DL + स्मार्ट कार्ड): **₹400–₹700** (राज्य के अनुसार)।`,
        `• **ज़रूरी डॉक्यूमेंट:** आधार कार्ड (आधार e-KYC हेतु), आयु व पते का प्रमाण, फॉर्म-1/1A, पासपोर्ट फोटो व हस्ताक्षर।`,
        `• **आवेदन प्रक्रिया:** नीचे दिए हरे बटन से **parivahan.gov.in** खोलें, अपना राज्य चुनें और आधार e-KYC से Learner / Permanent DL के लिए आवेदन करें।`,
      ].join('\n'),
      sources: [{ title: 'parivahan.gov.in', uri: 'https://parivahan.gov.in/' }],
      cached: false,
    };
  }

  if (isPassport && (isAmbiguousGlobal || region.scope === 'india')) {
    return {
      text: [
        `भारतीय पासपोर्ट (Passport) ऑनलाइन आवेदन की पूरी जानकारी नीचे दी गई है:`,
        ``,
        `• **आधिकारिक पोर्टल:** विदेश मंत्रालय का पोर्टल **passportindia.gov.in**`,
        `• **असली सरकारी फीस:** सामान्य (36 पेज, 10 वर्ष): **₹1,500** | तत्काल: **₹3,500** | नाबालिग: **₹1,000**।`,
        `• **ज़रूरी डॉक्यूमेंट:** आधार कार्ड / वोटर आईडी / पते का प्रमाण, जन्म प्रमाण पत्र या 10वीं अंकतालिका, और अपॉइंटमेंट रसीद।`,
        `• **स्टेप-बाय-स्टेप आवेदन तरीका:**`,
        `  1. नीचे दिए हरे बटन से **passportindia.gov.in** पर जाएं और New User Registration करें।`,
        `  2. लॉगिन करके *Apply for Fresh Passport* चुनें और ऑनलाइन फॉर्म भरें।`,
        `  3. नजदीकी Passport Seva Kendra (PSK) का अपॉइंटमेंट चुनकर फीस ऑनलाइन जमा करें और तय तिथि पर दस्तावेज़ सत्यापन करवाएं।`,
      ].join('\n'),
      sources: [{ title: 'passportindia.gov.in', uri: 'https://www.passportindia.gov.in/' }],
      cached: false,
    };
  }

  if (isRationAyushman && (isAmbiguousGlobal || region.scope === 'india')) {
    const stateLabel = isAmbiguousGlobal ? 'All India (NFSA / PM-JAY)' : region.label;
    return {
      text: [
        `**राशन कार्ड (NFSA) व आयुष्मान भारत कार्ड (PM-JAY)** ऑनलाइन आवेदन की पूरी जानकारी (**${stateLabel}**):`,
        ``,
        `• **आधिकारिक पोर्टल:** **beneficiary.nha.gov.in** (आयुष्मान कार्ड) एवं **nfsa.gov.in** (राशन कार्ड)`,
        `• **सरकारी फीस:** आयुष्मान भारत कार्ड (PM-JAY) **₹0 (फ्री)** | राशन कार्ड आवेदन/संशोधन शुल्क **₹0–₹50** (राज्य पोर्टल/CSC के अनुसार)।`,
        `• **ज़रूरी डॉक्यूमेंट:** आधार कार्ड (मोबाइल नंबर लिंक), परिवार का राशन/परिवार कार्ड, पासपोर्ट फोटो और स्व-घोषणा पत्र।`,
        `• **आवेदन प्रक्रिया:** नीचे दिए हरे बटन से **beneficiary.nha.gov.in** पर मोबाइल OTP से लॉगिन कर पात्रता जांचें, e-KYC करें और डिजिटल कार्ड डाउनलोड करें।`,
      ].join('\n'),
      sources: [{ title: 'beneficiary.nha.gov.in', uri: 'https://beneficiary.nha.gov.in/' }],
      cached: false,
    };
  }

  if (
    isCitizenService ||
    (!isAmbiguousGlobal &&
      region.scope === 'global' &&
      /visa|वीज़ा|govt|सरकारी|portal|पोर्टल|license|licence|\bpr\b|permit|immigration|citizenship|resident|work pass/i.test(
        lower
      ))
  ) {
    if (isAmbiguousGlobal || !region.citizenGuide) {
      return {
        text: isEnglish
          ? [
              `### 🌍 Please Select Your Indian State or Country`,
              `Your active region is currently **Global / World**. Since citizen portals, fees, and documents differ across states and countries:`,
              `• **Reply with your state or country name** (e.g., *MP*, *UP*, *Bihar*, *Rajasthan*, *Maharashtra*, *Delhi*, *UAE*, *Saudi Arabia*, *USA*, *UK*, *Canada*), or select it in the top **Region Selector**.`,
              `• Or open **services.india.gov.in** below to access all Indian state e-District / ServicePlus portals.`,
            ].join('\n')
          : [
              `### 🌍 कृपया अपना राज्य (भारत) या देश बताएं`,
              `अभी आपका क्षेत्र **Global / World** सेट है। हर राज्य और देश का आधिकारिक नागरिक पोर्टल, फीस और दस्तावेज़ अलग होते हैं:`,
              `• **कृपया चैट में अपने राज्य या देश का नाम लिखें** (जैसे *मध्य प्रदेश (MP)*, *उत्तर प्रदेश (UP)*, *बिहार (Bihar)*, *राजस्थान*, *महाराष्ट्र*, *दिल्ली*, *UAE*, *Saudi Arabia*, *USA*, *UK*, *Canada*) या ऊपर हेडर में **Region Selector** से चुनें।`,
              `• भारत के सभी राज्यों के e-District / ServicePlus पोर्टल्स के लिए आप नीचे दिए हरे बटन से **services.india.gov.in** भी खोल सकते हैं।`,
            ].join('\n'),
        sources: [{ title: 'services.india.gov.in', uri: 'https://services.india.gov.in/' }],
        cached: false,
      };
    }

    const guide = region.citizenGuide;
    return {
      text: isEnglish
        ? [
            `Official Digital Citizen Services Guide for **${region.label}**:`,
            ``,
            `• **Official Portal:** ${guide.portalName} (**${guide.portalDomain}**)`,
            `• **Official Fees:** ${guide.feeSummaryEn}`,
            `• **Required Documents:** ${guide.documentsEn}`,
            `• **Step-by-Step Process:**`,
            ...guide.stepsEn.map((s, i) => `  ${i + 1}. ${s}`),
          ].join('\n')
        : [
            `**${region.label}** — आधिकारिक डिजिटल नागरिक सेवा व प्रमाण पत्र गाइड:`,
            ``,
            `• **आधिकारिक पोर्टल:** ${guide.portalName} (**${guide.portalDomain}**)`,
            `• **असली सरकारी फीस:** ${guide.feeSummaryHi}`,
            `• **ज़रूरी डॉक्यूमेंट:** ${guide.documentsHi}`,
            `• **स्टेप-बाय-स्टेप आवेदन प्रक्रिया:**`,
            ...guide.stepsHi.map((s, i) => `  ${i + 1}. ${s}`),
          ].join('\n'),
      sources: [{ title: guide.portalDomain, uri: guide.portalUrl }],
      cached: false,
    };
  }

  if (isAdmission) {
    return {
      text: [
        `**${prompt}** से जुड़ी प्रवेश (Admission) जानकारी:`,
        ``,
        `• **आधिकारिक पोर्टल:** **cuet.nta.nic.in** / संबंधित राज्य या विश्वविद्यालय प्रवेश पोर्टल।`,
        `• **प्रवेश प्रक्रिया:** स्कूल/कॉलेज प्रवेश हेतु पिछली कक्षा की अंकतालिका, TC (स्थानांतरण प्रमाण पत्र), चरित्र प्रमाण पत्र, आधार कार्ड व पासपोर्ट फोटो आवश्यक होते हैं।`,
        `• **आवेदन तरीका:** नीचे दिए हरे बटन से आधिकारिक प्रवेश पोर्टल पर जाकर छात्र पंजीकरण करें, कोर्स/कॉलेज चुनें और आवेदन सबमिट करें।`,
      ].join('\n'),
      sources: [{ title: 'cuet.nta.nic.in', uri: 'https://cuet.nta.nic.in/' }],
      cached: false,
    };
  }

  const isGovtOrPortalAsk = /सरकारी|govt|government|नौकरी|भर्ती|vacancy|recruitment|exam|परीक्षा|form|फॉर्म|portal|पोर्टल|visa|वीज़ा/i.test(
    lower
  );
  if (!isGovtOrPortalAsk) {
    return {
      text: isEnglish
        ? `Please share a little more detail about **${prompt}** so I can give you a clear, point-by-point answer.`
        : `**${prompt}** से जुड़ा अपना स्पष्ट प्रश्न लिखें (या फोटो अपलोड करें) — मैं तुरंत सरल भाषा में पूरी जानकारी दूंगा।`,
      sources: [],
      cached: false,
    };
  }

  const topPortal = region.portals[0];
  const domain = topPortal?.domain || 'services.india.gov.in';

  return {
    text:
      isEnglish
        ? `Please check the verified official portal (**${domain}**) for live updates regarding **${prompt}** (${region.shortName}). You can also ask follow-up questions directly in this chat.`
        : `**${prompt}** से जुड़ी सटीक और ताज़ा जानकारी के लिए कृपया **${domain}** देखें या इसी चैट में अपना स्पष्ट सवाल पूछें — मैं तुरंत आपकी मदद करूंगा।`,
    sources: topPortal ? [{ title: topPortal.domain, uri: topPortal.url }] : [],
    cached: false,
  };
}

export async function generateSaarthiWithSources(
  prompt: string,
  history: { role: 'user' | 'model'; content: string }[] = [],
  imageBase64?: string,
  language: string = 'hi',
  location: string = '🌐 Global / World'
): Promise<SaarthiResponse> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 30000);

  try {
    const res = await fetch('/api/gemini/generate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt,
        history,
        imageBase64,
        language,
        location,
      }),
      signal: controller.signal,
    });

    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      return buildOfflineDirectReply(prompt, language, location, Boolean(imageBase64), history);
    }

    const sources: SourceLink[] = Array.isArray(data?.sources)
      ? data.sources.filter((s: unknown): s is SourceLink => Boolean(s && typeof (s as SourceLink).uri === 'string'))
      : [];

    const text = typeof data?.text === 'string' && data.text.trim() ? data.text.trim() : '';
    if (!text) {
      return buildOfflineDirectReply(prompt, language, location, Boolean(imageBase64), history);
    }

    return {
      text,
      sources,
      cached: Boolean(data?.cached),
    };
  } catch {
    return buildOfflineDirectReply(prompt, language, location, Boolean(imageBase64), history);
  } finally {
    clearTimeout(timeoutId);
  }
}

export async function generateSaarthiResponse(
  prompt: string,
  history: { role: 'user' | 'model'; content: string }[] = [],
  imageBase64?: string,
  language: string = 'hi',
  location: string = '🌐 Global / World'
): Promise<string> {
  const { text, sources } = await generateSaarthiWithSources(
    prompt,
    history,
    imageBase64,
    language,
    location
  );

  if (sources.length === 0) return text;
  const topSource = sources[0];
  return `${text}\n\n✅ Official Source: ${topSource.title || topSource.uri}`;
}
