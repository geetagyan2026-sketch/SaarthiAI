export interface MedicineProfile {
  key: string;
  pattern: RegExp;
  nameDisplay: string;
  compositionHi: string;
  compositionEn: string;
  usesHi: string;
  usesEn: string;
  usageHi: string;
  usageEn: string;
  precautionsHi: string;
  precautionsEn: string;
}

export const MEDICINE_DISCLAIMER_HI =
  '⚠️ यह केवल सामान्य जानकारी है। किसी भी दवाई को लेने से पहले अपने डॉक्टर से सलाह ज़रूर लें।';

export const MEDICINE_DISCLAIMER_EN =
  '⚠️ This is general informational guidance only. Always consult a qualified doctor before taking any medicine.';

const KNOWN_MEDICINES: MedicineProfile[] = [
  {
    key: 'zedocef_cv',
    pattern: /zedocef[\s-]*cv|cefpodoxime.*clavulan/i,
    nameDisplay: 'Zedocef CV 200 Tablet',
    compositionHi: 'Cefpodoxime Proxetil (200mg) + Clavulanic Acid (125mg) — यह एक कॉम्बिनेशन एंटीबायोटिक (Antibiotic) दवाई है।',
    compositionEn: 'Cefpodoxime Proxetil (200mg) + Clavulanic Acid (125mg) — a broad-spectrum combination antibiotic.',
    usesHi: 'बैक्टीरियल संक्रमण (Bacterial Infections) के इलाज में, जैसे गले व टॉन्सिल का इन्फेक्शन (Pharyngitis/Tonsillitis), फेफड़ों व श्वसन तंत्र का संक्रमण (Bronchitis, Pneumonia), साइनस, कान का इन्फेक्शन, यूरिन इन्फेक्शन (UTI) और त्वचा संक्रमण।',
    usesEn: 'Treats bacterial infections including throat/tonsillitis, respiratory tract infections (bronchitis, pneumonia), sinusitis, ear infections, urinary tract infections (UTI), and skin infections.',
    usageHi: 'सामान्य रूप से इसे **खाना खाने के बाद** पानी के साथ साबुत निगला जाता है (तोड़ें या चबाएं नहीं)। एंटीबायोटिक का पूरा कोर्स डॉक्टर द्वारा बताई गई अवधि तक पूरा करना ज़रूरी होता है।',
    usageEn: 'Typically swallowed whole with water **after food** to improve absorption and reduce stomach upset. Complete the full prescribed course as directed by your doctor.',
    precautionsHi: 'दस्त लगना, मतली/पेट खराब होना, गैस या हल्की त्वचा एलर्जी हो सकती है। पेनिसिलिन या सेफालोस्पोरिन (Cephalosporin) एंटीबायोटिक से एलर्जी, किडनी समस्या, गर्भावस्था या स्तनपान में डॉक्टर को अवश्य बताएं। वायरल बुखार/सामान्य सर्दी में बिना डॉक्टर के एंटीबायोटिक न लें।',
    precautionsEn: 'May cause diarrhea, nausea, stomach upset, or mild rash. Inform your doctor if you have cephalosporin/penicillin allergy, kidney issues, or are pregnant/breastfeeding. Do not self-medicate for viral colds.',
  },
  {
    key: 'zedocef_plain',
    pattern: /\bzedocef\b|cefpodoxime/i,
    nameDisplay: 'Zedocef 200 / Cefpodoxime Tablet',
    compositionHi: 'Cefpodoxime Proxetil (100mg / 200mg) — तीसरी पीढ़ी का सेफालोस्पोरिन एंटीबायोटिक (Antibiotic)।',
    compositionEn: 'Cefpodoxime Proxetil (100mg / 200mg) — a third-generation cephalosporin antibiotic.',
    usesHi: 'गले, कान, साइनस, फेफड़ों (निमोनिया/ब्रोंकाइटिस) और मूत्र मार्ग (UTI) के बैक्टीरियल इन्फेक्शन के उपचार में।',
    usesEn: 'Used to treat bacterial infections of the throat, ear, sinus, lungs, and urinary tract (UTI).',
    usageHi: 'आमतौर पर भोजन के बाद पानी के साथ डॉक्टर के बताए समय पर ली जाती है और निर्धारित पूरा कोर्स पूरा किया जाता है।',
    usageEn: 'Generally taken after meals with water at evenly spaced intervals for the full prescribed duration.',
    precautionsHi: 'पेट खराब होना, दस्त या एलर्जी की संभावना हो सकती है। किडनी रोग या एंटीबायोटिक एलर्जी होने पर सावधानी रखें।',
    precautionsEn: 'Common side effects include mild diarrhea, nausea, or rash. Use cautiously in patients with kidney impairment or antibiotic allergies.',
  },
  {
    key: 'paracetamol',
    pattern: /\bparacetamol\b|\bacetaminophen\b|\bdolo\b|\bcrocin\b|\bcalpol\b|पैरासिटामोल|डोलो/i,
    nameDisplay: 'Paracetamol / Dolo 650 / Crocin',
    compositionHi: 'Paracetamol / Acetaminophen (आमतौर पर 500mg या 650mg टैबलेट, या बच्चों के लिए सिरप)।',
    compositionEn: 'Paracetamol / Acetaminophen (commonly 500mg or 650mg tablets, or pediatric suspension).',
    usesHi: 'बुखार कम करने (Antipyretic) और हल्के से मध्यम दर्द (Analgesic) — जैसे सिरदर्द, बदन दर्द, दांत दर्द, मासिक धर्म दर्द या जोड़ों के दर्द से राहत के लिए।',
    usesEn: 'Used to reduce fever and relieve mild-to-moderate pain such as headache, body ache, toothache, or joint pain.',
    usageHi: 'सामान्यतः हल्के नाश्ते या **खाना खाने के बाद** पानी से ली जाती है (दो खुराकों के बीच डॉक्टर द्वारा बताए अनुसार उचित अंतराल रखा जाता है)।',
    usageEn: 'Usually taken with water **after food/snack**, keeping the recommended gap between doses as advised by a healthcare professional.',
    precautionsHi: 'अधिक मात्रा (Overdose) लेने से **लिवर (Liver)** को गंभीर नुकसान हो सकता है। लिवर की बीमारी वाले मरीज, शराब का सेवन करने वाले या जो पहले से कोई अन्य पैरासिटामोल युक्त जुकाम की दवा ले रहे हैं, वे विशेष सावधानी बरतें।',
    precautionsEn: 'Exceeding recommended limits can cause serious **liver damage**. Avoid doubling up with other cold/pain medicines that also contain Paracetamol, and avoid alcohol.',
  },
  {
    key: 'augmentin',
    pattern: /augmentin|moxikind|amoxyclav|clavam|amoxicil.*clav/i,
    nameDisplay: 'Augmentin 625 / Amoxyclav',
    compositionHi: 'Amoxicillin (500mg) + Clavulanic Acid (125mg) — ब्रॉड-स्पेक्ट्रम एंटीबायोटिक कॉम्बिनेशन।',
    compositionEn: 'Amoxicillin (500mg) + Clavulanic Acid (125mg) — a penicillin-class combination antibiotic.',
    usesHi: 'दांत और मसूड़ों का इन्फेक्शन, गले/साइनस/कान का संक्रमण, फेफड़ों का इन्फेक्शन, घाव या त्वचा और यूरिन इन्फेक्शन (UTI) में।',
    usesEn: 'Treats dental/gum infections, throat, sinus, ear, respiratory tract, skin/wound, and urinary tract infections.',
    usageHi: 'पेट में जलन से बचने के लिए **भोजन की शुरुआत में या खाना खाने के तुरंत बाद** पानी से ली जाती है।',
    usageEn: 'Best taken **at the start of a meal or right after food** with water to minimize stomach upset.',
    precautionsHi: 'दस्त, पेट मरोड़, उल्टी या पेनिसिलिन एलर्जी (खुजली/चकत्ते/सूजन) हो सकती है। पेनिसिलिन से एलर्जी या लिवर समस्या वाले व्यक्ति बिना डॉक्टर सलाह के न लें।',
    precautionsEn: 'May cause diarrhea, nausea, or allergic skin rash. Strictly avoid if allergic to penicillin/beta-lactam antibiotics.',
  },
  {
    key: 'azithromycin',
    pattern: /azithromycin|azithral|\bazee\b/i,
    nameDisplay: 'Azithromycin (Azithral 500)',
    compositionHi: 'Azithromycin (250mg / 500mg) — मैक्रोलाइड (Macrolide) वर्ग की एंटीबायोटिक दवाई।',
    compositionEn: 'Azithromycin (250mg / 500mg) — a macrolide antibiotic.',
    usesHi: 'गले में खराश/टॉन्सिल, ब्रोंकाइटिस, निमोनिया, साइनस, कान के बैक्टीरियल संक्रमण और कुछ पेट/त्वचा संक्रमणों के इलाज में।',
    usesEn: 'Used for bacterial throat/tonsillar infections, bronchitis, pneumonia, sinusitis, ear infections, and certain skin infections.',
    usageHi: 'आमतौर पर दिन में एक बार तय समय पर पानी के साथ ली जाती है; पेट खराब न हो इसके लिए भोजन के बाद लेना बेहतर रहता है।',
    usageEn: 'Usually taken once daily at the same time each day with water (can be taken after food if stomach upset occurs).',
    precautionsHi: 'पेट दर्द, दस्त या मतली हो सकती है। हृदय की धड़कन (QT prolongation) या लिवर से जुड़ी समस्या होने पर डॉक्टर को सूचित करें।',
    precautionsEn: 'May cause abdominal discomfort, loose stools, or nausea. Inform your doctor if you have liver disease or heart rhythm conditions.',
  },
  {
    key: 'pan_d',
    pattern: /\bpan[\s-]*d\b|pantocid[\s-]*dsr|pantoprazole.*domperidone|\bpantoprazole\b|\bpan\s*40\b/i,
    nameDisplay: 'Pan-D / Pantocid DSR / Pantoprazole',
    compositionHi: 'Pantoprazole (40mg, PPI) + Domperidone (30mg Sustained Release — Pan-D/DSR में) | प्लेन Pan-40 में केवल Pantoprazole 40mg।',
    compositionEn: 'Pantoprazole (40mg, proton pump inhibitor) + Domperidone (30mg SR in Pan-D/DSR); plain Pan 40 contains Pantoprazole 40mg.',
    usesHi: 'एसिडिटी, सीने में जलन (Heartburn), गैस, खट्टी डकार, GERD (एसिड रिफ्लक्स), मतली और पेट के अल्सर से राहत के लिए।',
    usesEn: 'Relieves acidity, heartburn, acid reflux (GERD), bloating, nausea, and gastritis/ulcers.',
    usageHi: 'सामान्यतः सुबह **खाली पेट (नाश्ते से 30–45 मिनट पहले)** साबुत कैप्सूल/टैबलेट पानी के साथ ली जाती है।',
    usageEn: 'Typically taken **on an empty stomach 30–45 minutes before breakfast**, swallowed whole with water.',
    precautionsHi: 'मुंह सूखना, हल्का सिरदर्द या कब्ज/दस्त हो सकता है। बिना डॉक्टर की सलाह के लगातार कई महीनों तक उपयोग न करें (लंबे उपयोग से विटामिन B12/मैग्नीशियम की कमी हो सकती है)। हृदय रोगियों को Domperidone सावधानी से लेना चाहिए।',
    precautionsEn: 'May cause dry mouth or mild headache. Avoid long-term daily use without medical review (risk of B12/magnesium deficiency). Heart patients should verify Domperidone safety with their doctor.',
  },
  {
    key: 'cefixime',
    pattern: /cefixime|taxim[\s-]*o|\bzifi\b/i,
    nameDisplay: 'Taxim-O 200 / Cefixime',
    compositionHi: 'Cefixime (100mg / 200mg) — सेफालोस्पोरिन ग्रुप की एंटीबायोटिक।',
    compositionEn: 'Cefixime (100mg / 200mg) — an oral third-generation cephalosporin antibiotic.',
    usesHi: 'टाइफाइड बुखार, यूरिन इन्फेक्शन (UTI), गले, कान और फेफड़ों के बैक्टीरियल इन्फेक्शन के इलाज में।',
    usesEn: 'Treats typhoid fever, urinary tract infections (UTI), and bacterial infections of the throat, ear, and lungs.',
    usageHi: 'भोजन के साथ या बाद में पानी के साथ ली जाती है और डॉक्टर के बताए दिनों तक पूरा कोर्स करना होता है।',
    usageEn: 'Usually taken with or after food for the full course prescribed by a doctor.',
    precautionsHi: 'पेट खराब होना, गैस या दस्त हो सकते हैं। एंटीबायोटिक एलर्जी या किडनी समस्या में डॉक्टर को बताएं।',
    precautionsEn: 'May cause loose stools, gas, or mild nausea. Caution in kidney impairment or cephalosporin allergy.',
  },
  {
    key: 'montair_lc',
    pattern: /montair[\s-]*lc|montek[\s-]*lc|montelukast.*levocetirizine/i,
    nameDisplay: 'Montair LC / Montek LC',
    compositionHi: 'Montelukast (10mg) + Levocetirizine (5mg) — एंटी-एलर्जिक कॉम्बिनेशन।',
    compositionEn: 'Montelukast (10mg) + Levocetirizine (5mg) — an anti-allergic and leukotriene receptor antagonist combination.',
    usesHi: 'एलर्जिक राइनाइटिस (लगातार छींक आना, नाक बहना/बंद होना, आंखों में खुजली), मौसमी एलर्जी और हल्के एलर्जिक अस्थमा के लक्षणों में।',
    usesEn: 'Relieves allergic rhinitis (sneezing, runny/blocked nose, watery eyes), skin hives, and allergy-triggered airway symptoms.',
    usageHi: 'अक्सर **शाम या रात को सोने से पहले** पानी के साथ ली जाती है (क्योंकि इससे हल्की नींद आ सकती है)।',
    usageEn: 'Commonly taken **once daily in the evening or at bedtime** with water.',
    precautionsHi: 'हल्की नींद/सुस्ती, मुंह सूखना या थकान महसूस हो सकती है; दवा लेने के बाद ड्राइविंग या भारी मशीन चलाने में सावधानी रखें।',
    precautionsEn: 'Can cause mild drowsiness or dry mouth; be cautious when driving or operating machinery.',
  },
  {
    key: 'combiflam',
    pattern: /combiflam|ibuprofen.*paracetamol/i,
    nameDisplay: 'Combiflam Tablet',
    compositionHi: 'Ibuprofen (400mg) + Paracetamol (325mg) — दर्द निवारक और सूजन कम करने वाली दवाई (NSAID + Analgesic)।',
    compositionEn: 'Ibuprofen (400mg) + Paracetamol (325mg) — an NSAID plus analgesic pain & fever reliever.',
    usesHi: 'बदन दर्द, दांत दर्द, मांसपेशियों/जोड़ों का दर्द, मोच, सूजन और तेज बुखार से राहत के लिए।',
    usesEn: 'Relieves muscle pain, dental pain, joint/back pain, inflammation, and fever.',
    usageHi: 'पेट में जलन/एसिडिटी से बचने के लिए हमेशा **खाना खाने के बाद** पानी के साथ ली जाती है (खाली पेट न लें)।',
    usageEn: 'Always taken **with or after food** to prevent stomach irritation or acidity.',
    precautionsHi: 'खाली पेट लेने से पेट दर्द, एसिडिटी या अल्सर का खतरा बढ़ सकता है। किडनी रोग, पेट के अल्सर, अस्थमा, हाई बीपी या गर्भावस्था में बिना डॉक्टर सलाह के न लें।',
    precautionsEn: 'Never take on an empty stomach. Avoid without medical advice if you have stomach ulcers, kidney/liver disease, heart issues, or are pregnant.',
  },
  {
    key: 'zerodol',
    pattern: /zerodol|aceclofenac.*paracetamol/i,
    nameDisplay: 'Zerodol-P / Zerodol-SP',
    compositionHi: 'Zerodol-P: Aceclofenac (100mg) + Paracetamol (325mg) | Zerodol-SP में इसके साथ Serratiopeptidase (15mg) भी होता है।',
    compositionEn: 'Zerodol-P: Aceclofenac (100mg) + Paracetamol (325mg); Zerodol-SP adds Serratiopeptidase (15mg) for swelling.',
    usesHi: 'जोड़ों का दर्द, कमर दर्द, दांत दर्द, चोट के बाद दर्द और सूजन कम करने के लिए।',
    usesEn: 'Relieves joint pain, backache, dental pain, post-injury pain, and inflammatory swelling.',
    usageHi: 'गैस और पेट की जलन से बचने के लिए **भोजन के बाद** ही पानी के साथ ली जाती है।',
    usageEn: 'Should always be taken **after meals** with water to protect the stomach lining.',
    precautionsHi: 'एसिडिटी, मतली या पेट दर्द हो सकता है। किडनी, लिवर, पेट के अल्सर या दिल के मरीजों को डॉक्टर से पूछे बिना इसका सेवन नहीं करना चाहिए।',
    precautionsEn: 'May cause heartburn or stomach discomfort. Avoid in peptic ulcer, kidney/liver impairment, or pregnancy unless prescribed.',
  },
  {
    key: 'cetirizine_allegra',
    pattern: /\bcetirizine\b|\blevocetirizine\b|\bokacet\b|\ballegra\b|\bfexofenadine\b|\bavil\b/i,
    nameDisplay: 'Cetirizine / Levocetirizine / Allegra',
    compositionHi: 'एंटी-हिस्टामाइन (Antihistamine) एलर्जी की दवाई — Cetirizine (10mg), Levocetirizine (5mg), या Fexofenadine (Allegra 120/180mg)।',
    compositionEn: 'Antihistamine anti-allergy medicine — Cetirizine (10mg), Levocetirizine (5mg), or Fexofenadine (Allegra 120/180mg).',
    usesHi: 'एलर्जी, छींकें, नाक बहना, आंखों से पानी आना, पित्ती (Urticaria), कीड़े के काटने या त्वचा की खुजली में राहत के लिए।',
    usesEn: 'Relieves allergies, sneezing, runny nose, itchy eyes, hives (urticaria), and skin itching.',
    usageHi: 'आमतौर पर दिन में एक बार (विशेषकर रात को) पानी से ली जाती है; Allegra फलों के जूस के बजाय सादे पानी से लेनी चाहिए।',
    usageEn: 'Usually taken once daily with plain water (Fexofenadine/Allegra works best with water rather than fruit juice).',
    precautionsHi: 'Cetirizine/Avil से सुस्ती या नींद आ सकती है (Allegra में नींद कम आती है)। शराब के साथ सेवन न करें और वाहन चलाते समय सतर्क रहें।',
    precautionsEn: 'Cetirizine can cause drowsiness (Fexofenadine is largely non-drowsy). Avoid alcohol and be careful while driving.',
  },
  {
    key: 'ofloxacin_oz',
    pattern: /ofloxacin.*ornidazole|\bo2\b.*tablet|ornidazole|\bnorflox\b/i,
    nameDisplay: 'Ofloxacin + Ornidazole (O2 / Norflox-TZ)',
    compositionHi: 'Ofloxacin (200mg) + Ornidazole (500mg) — दो एंटीबायोटिक दवाइयों का संयोजन।',
    compositionEn: 'Ofloxacin (200mg) + Ornidazole (500mg) — dual antibacterial & antiprotozoal combination.',
    usesHi: 'दस्त, पेचिश (Dysentery), पेट व आंतों के संक्रमण (Gastrointestinal infections) और कुछ स्त्री रोग संबंधी संक्रमणों में।',
    usesEn: 'Used to treat bacterial/protozoal diarrhea, dysentery, and gastrointestinal infections.',
    usageHi: 'भोजन के बाद पानी के साथ तय अंतराल पर ली जाती है और शरीर में पानी की कमी (ORS/इलेक्ट्राल) का भी ध्यान रखा जाता है।',
    usageEn: 'Taken after meals with water as prescribed, alongside proper hydration (ORS).',
    precautionsHi: 'मुंह में धातु जैसा स्वाद (Metallic taste), चक्कर आना या मतली हो सकती है। दवा के दौरान **शराब का सेवन बिल्कुल न करें**। गर्भावस्था में डॉक्टर की सलाह आवश्यक है।',
    precautionsEn: 'May cause metallic taste, nausea, or dizziness. **Strictly avoid alcohol** during and shortly after the course.',
  },
  {
    key: 'meftal_spas',
    pattern: /meftal[\s-]*spas|mefenamic.*dicyclomine/i,
    nameDisplay: 'Meftal-Spas Tablet',
    compositionHi: 'Mefenamic Acid (250mg) + Dicyclomine Hydrochloride (10mg) — दर्द और पेट की ऐंठन (Spasm) कम करने वाली दवाई।',
    compositionEn: 'Mefenamic Acid (250mg) + Dicyclomine (10mg) — an antispasmodic and pain-relieving combination.',
    usesHi: 'पेट की मरोड़/ऐंठन (Abdominal cramps), मासिक धर्म का दर्द (Period pain) और आंतों की ऐंठन से राहत के लिए।',
    usesEn: 'Relieves abdominal cramps, spasmodic stomach pain, and menstrual (period) cramps.',
    usageHi: 'पेट में जलन से बचने के लिए **खाना खाने के बाद** पानी के साथ ली जाती है।',
    usageEn: 'Always taken **after meals** with water to avoid gastric irritation.',
    precautionsHi: 'मुंह सूखना, चक्कर आना, धुंधला दिखना या एसिडिटी हो सकती है। पेट के अल्सर, किडनी रोग या ग्लूकोमा में डॉक्टर की सलाह के बिना न लें।',
    precautionsEn: 'May cause dry mouth, dizziness, or acidity. Avoid without medical advice if you have ulcers, kidney disease, or glaucoma.',
  },
  {
    key: 'sinarest_cold',
    pattern: /sinarest|wikoryl|cheston\s*cold|d\s*cold\s*total|phenylephrine/i,
    nameDisplay: 'Sinarest / Cheston Cold / Wikoryl',
    compositionHi: 'Paracetamol (500mg) + Phenylephrine (10mg) + Chlorpheniramine Maleate (2mg) — सर्दी-जुकाम कॉम्बिनेशन।',
    compositionEn: 'Paracetamol (500mg) + Phenylephrine (10mg) + Chlorpheniramine Maleate (2mg) — multi-symptom cold relief.',
    usesHi: 'बंद नाक खोलने, बहती नाक, छींक, गले की खराश, हल्का बुखार और सर्दी-जुकाम से जुड़े सिरदर्द में राहत के लिए।',
    usesEn: 'Relieves blocked/runny nose, sneezing, sinus congestion, mild fever, and cold-related headache.',
    usageHi: 'भोजन के बाद पानी के साथ ली जाती है; इसके साथ अलग से दूसरी पैरासिटामोल गोली न मिलाएं।',
    usageEn: 'Taken after food with water; avoid combining with extra Paracetamol tablets.',
    precautionsHi: 'हल्की नींद आ सकती है। हाई ब्लड प्रेशर (High BP), हृदय रोग, थायराइड या ग्लूकोमा के मरीज Phenylephrine लेने से पहले डॉक्टर से पूछें।',
    precautionsEn: 'May cause drowsiness. Patients with high blood pressure, heart disease, or thyroid issues should consult a doctor first.',
  },
];

export function isMedicineOrHealthQuery(
  prompt: string,
  hasImage: boolean = false,
  history: Array<{ role?: string; content?: string }> = []
): boolean {
  const clean = (prompt || '').trim();
  const lower = clean.toLowerCase();

  // Never treat govt health card schemes as medicine info queries
  if (/आयुष्मान|ayushman|pmjay|cghs|esic|राशन|ration\s*card|सरकारी योजना|भर्ती|नौकरी|जाति प्रमाण|मूल निवास|पैन कार्ड|पासपोर्ट/i.test(lower)) {
    return false;
  }

  if (KNOWN_MEDICINES.some((m) => m.pattern.test(clean))) {
    return true;
  }

  if (
    /दवाई|दवाइयां|दवा\b|गोली|कैप्सूल|सिरप|टैबलेट|इंजेक्शन|मलहम|साल्ट|कंपोजिशन|खुराक|साइड\s*इफेक्ट|बुखार|जुकाम|खांसी|सिरदर्द|पेट\s*दर्द|एसिडिटी|उल्टी|दस्त|इन्फेक्शन|एलर्जी|\bmedicine\b|\btablet\b|\btabs?\b|\bcap(?:sule)?\b|\bsyrup\b|\bsuspension\b|\bointment\b|\bdosage\b|\bside\s*effects?\b|\bcomposition\b|\bantibiotic\b|\bpainkiller\b|\bantacid\b|\bprescription\b|\b(?:omez|digene|gelusil|saridon|disprin|shelcal|becosules|metrogyl|ciplox|ondem|rantac|ecosprin|thyronorm|glycomet|electral|limcee|betadine|soframycin|volini|ascoril|benadryl|honitus|cofsils)\b/i.test(
      lower
    )
  ) {
    return true;
  }

  // Medicine strength patterns like "Zedocef CV 200", "Azee 500mg", "Telma 40", "Dolo 650"
  if (
    /\b\d+(?:\.\d+)?\s*(?:mg|mcg|ml|gm|iu)\b/i.test(lower) ||
    /\b[a-z]{3,}(?:cef|cillin|mycin|floxacin|prazole|dazole|profen|mol|fenac|statin|sartan|dipine|olol|formin|gliptin|lukast|clav)\b/i.test(
      lower
    ) ||
    /\b[a-z]{3,}\s+(?:cv|dsr|sr|sp|dx|ls|forte)\b/i.test(lower) ||
    /\b[a-z]{3,}\s+(?:50|100|125|150|200|250|325|400|500|625|650|750|1000)\b/i.test(lower)
  ) {
    return true;
  }

  if (
    hasImage &&
    /पर्चा|पत्ती|पत्ता|दवा|medicine|tablet|strip|capsule|salt|क्या काम/i.test(lower)
  ) {
    return true;
  }

  // Follow-up in a medicine conversation
  const lastModelMsg = [...history].reverse().find((h) => h?.role === 'model')?.content || '';
  if (
    /दवाई का नाम लिखें|साल्ट\s*\(Composition\)|अपने डॉक्टर से सलाह ज़रूर लें/i.test(lastModelMsg) &&
    clean.split(/\s+/).length <= 5
  ) {
    return true;
  }

  return false;
}

export function buildStructuredMedicineReply(
  prompt: string,
  webSnippets: string[] = [],
  language: string = 'hi'
): string {
  const isEnglish = language === 'en';
  const cleanPrompt = (prompt || '').trim();

  // If user clicked the generic starter prompt without specifying a medicine name yet
  const isStarterAsk =
    /किसी दवाई की जानकारी पाने के लिए उसका नाम बताइए|दवाई की जानकारी|medicine info/i.test(cleanPrompt) &&
    !KNOWN_MEDICINES.some((m) => m.pattern.test(cleanPrompt)) &&
    !/\d+\s*(?:mg|ml|50|100|200|250|500|625|650)/i.test(cleanPrompt);

  if (isStarterAsk) {
    return isEnglish
      ? [
          `### 💊 Medicine Information Assistant`,
          `Please type the **name of any medicine** (for example: *Zedocef CV 200*, *Paracetamol / Dolo 650*, *Augmentin 625*, *Pan-D*) or **upload a clear photo** of the medicine strip/prescription.`,
          ``,
          `I will explain:`,
          `• **Medicine Name & Salt (Composition)**`,
          `• **Uses**`,
          `• **General Usage**`,
          `• **Side Effects & Precautions**`,
          ``,
          MEDICINE_DISCLAIMER_EN,
        ].join('\n')
      : [
          `### 💊 दवाई की जानकारी (Medicine Info)`,
          `कृपया नीचे चैट में **किसी भी दवाई का नाम लिखें** (जैसे *Zedocef CV 200*, *Paracetamol*, *Dolo 650*, *Augmentin 625*, *Pan-D*) या **दवाई के पत्ते / पर्चे की साफ फोटो अपलोड करें**।`,
          ``,
          `मैं आपको तुरंत आसान भाषा में ये 4 बातें बताऊंगा:`,
          `• **दवाई का नाम और साल्ट (Composition)**`,
          `• **किस काम आती है (Uses)**`,
          `• **कैसे ली जाती है (General Usage)**`,
          `• **सावधानियां और साइड इफेक्ट्स (Side Effects & Precautions)**`,
          ``,
          MEDICINE_DISCLAIMER_HI,
        ].join('\n');
  }

  const matched = KNOWN_MEDICINES.find((m) => m.pattern.test(cleanPrompt));
  if (matched) {
    if (isEnglish) {
      return [
        `### 💊 ${matched.nameDisplay}`,
        ``,
        `• **Medicine Name & Salt (Composition):** ${matched.compositionEn}`,
        `• **Uses:** ${matched.usesEn}`,
        `• **General Usage:** ${matched.usageEn}`,
        `• **Side Effects & Precautions:** ${matched.precautionsEn}`,
        ``,
        MEDICINE_DISCLAIMER_EN,
      ].join('\n');
    }

    return [
      `### 💊 ${matched.nameDisplay} — पूरी जानकारी`,
      ``,
      `• **दवाई का नाम और साल्ट (Composition):** ${matched.compositionHi}`,
      `• **किस काम आती है (Uses):** ${matched.usesHi}`,
      `• **कैसे ली जाती है (General Usage):** ${matched.usageHi}`,
      `• **सावधानियां और साइड इफेक्ट्स (Side Effects & Precautions):** ${matched.precautionsHi}`,
      ``,
      MEDICINE_DISCLAIMER_HI,
    ].join('\n');
  }

  // Dynamic structured response from medical web snippets (when medicine isn't in preset dictionary & Gemini quota fallback runs)
  const cleanSnippets = webSnippets
    .map((s) => s.replace(/https?:\/\/\S+/g, '').replace(/\s+/g, ' ').trim())
    .filter((s) => s.length > 25);

  if (isEnglish) {
    const infoLine =
      cleanSnippets[0] ||
      `Details for **${cleanPrompt}** depend on its exact active salt printed on the strip/label.`;
    const extraLine =
      cleanSnippets[1] ||
      'Mild stomach upset, nausea, drowsiness, or allergic skin reactions are possible depending on the active ingredient.';
    return [
      `### 💊 ${cleanPrompt}`,
      ``,
      `• **Medicine Name & Salt (Composition):** ${infoLine}`,
      `• **Uses:** Used for conditions specifically diagnosed and prescribed by a registered medical practitioner based on the active salt.`,
      `• **General Usage:** Take strictly in the dose and timing advised on your doctor's prescription (check strip label for exact mg/ml strength and expiry date).`,
      `• **Side Effects & Precautions:** ${extraLine} Inform your doctor about any allergies, pregnancy, kidney/liver issues, or ongoing medications.`,
      ``,
      MEDICINE_DISCLAIMER_EN,
    ].join('\n');
  }

  const compositionLine =
    cleanSnippets[0] ||
    `**${cleanPrompt}** — कृपया दवाई के पत्ते (Strip) पर लिखा सक्रिय साल्ट (Active Composition / mg) अवश्य जांचें या पत्ते की फोटो अपलोड करें।`;
  const usesLine =
    cleanSnippets[1] ||
    `यह दवाई संबंधित संक्रमण या लक्षण के अनुसार केवल डॉक्टर द्वारा निर्धारित बीमारी के इलाज में उपयोग की जाती है।`;

  return [
    `### 💊 ${cleanPrompt} — सामान्य जानकारी`,
    ``,
    `• **दवाई का नाम और साल्ट (Composition):** ${compositionLine}`,
    `• **किस काम आती है (Uses):** ${usesLine}`,
    `• **कैसे ली जाती है (General Usage):** इसे हमेशा डॉक्टर द्वारा बताई गई खुराक (Dosage) और समय के अनुसार पानी के साथ लें; दवा लेने से पहले पत्ते की एक्सपायरी डेट अवश्य जांचें।`,
    `• **सावधानियां और साइड इफेक्ट्स (Side Effects & Precautions):** पेट खराब होना, मतली, चक्कर या एलर्जी जैसे सामान्य प्रभाव हो सकते हैं। गर्भावस्था, स्तनपान, लिवर/किडनी रोग या किसी दवाई से एलर्जी होने पर डॉक्टर को पहले बताएं।`,
    ``,
    MEDICINE_DISCLAIMER_HI,
  ].join('\n');
}
