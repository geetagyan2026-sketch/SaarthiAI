export function isAndroidApp(): boolean {
  if (typeof window === 'undefined') return false;
  const isCapacitor = !!(window as any).Capacitor;
  const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
  const isAndroidUA = /Android/i.test(navigator.userAgent);
  const isWebView = /(; wv\b|;\s*Wv\b)/i.test(navigator.userAgent) || (isAndroidUA && !(window as any).chrome);
  return isCapacitor || isWebView || (isAndroidUA && isStandalone);
}
