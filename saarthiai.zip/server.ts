import 'dotenv/config';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';
import {
  isMedicineOrHealthQuery,
  buildStructuredMedicineReply,
  MEDICINE_DISCLAIMER_HI,
  MEDICINE_DISCLAIMER_EN,
} from './src/lib/medicineInfo';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.set('trust proxy', true);
app.use(express.json({ limit: '15mb' }));

interface SourceItem {
  title: string;
  uri: string;
  snippet?: string;
}

interface OfficialPortal {
  name: string;
  url: string;
  domain: string;
  category: string;
  description: string;
  keywords: string[];
}

interface LiveWebResult {
  title: string;
  link: string;
  publisher: string;
  pubDate: string;
  snippet: string;
  domain: string;
  breadcrumb: string;
  isOfficial: boolean;
}

interface OfficialPortalInfo {
  name: string;
  url: string;
  domain: string;
  category: string;
  description: string;
}

interface CacheEntry {
  text: string;
  sources: SourceItem[];
  expiresAt: number;
}

const CACHE_TTL_MS = 15 * 60 * 1000;
const MAX_CACHE_ENTRIES = 300;
const searchCache = new Map<string, CacheEntry>();

const RATE_WINDOW_MS = 60 * 1000;
const MAX_API_REQUESTS_PER_MINUTE = 30;
const rateLimitMap = new Map<string, number[]>();

// Circuit breaker when Gemini API free quota is exhausted so searches stay 0.1s fast
let geminiCooldownUntil = 0;

const OFFICIAL_PORTALS: OfficialPortal[] = [
  {
    name: 'Rajasthan Public Service Commission (RPSC) — Official Portal',
    url: 'https://rpsc.rajasthan.gov.in/',
    domain: 'rpsc.rajasthan.gov.in',
    category: 'State PSC',
    description: 'राजस्थान लोक सेवा आयोग (RPSC) की आधिकारिक वेबसाइट — ताज़ा भर्ती विज्ञापन, आवेदन लिंक, सिलेबस, एडमिट कार्ड और परीक्षा परिणाम।',
    keywords: ['rpsc', 'ras', 'rajasthan', 'si', '1st grade', '2nd grade', 'assistant professor'],
  },
  {
    name: 'RSSB / RSMSSB — राजस्थान कर्मचारी चयन बोर्ड',
    url: 'https://rssb.rajasthan.gov.in/',
    domain: 'rssb.rajasthan.gov.in',
    category: 'Rajasthan Govt',
    description: 'राजस्थान कर्मचारी चयन बोर्ड की आधिकारिक वेबसाइट — CET, पटवारी, VDO, REET, LDC भर्ती नोटिफिकेशन, सिलेबस व ऑनलाइन आवेदन।',
    keywords: ['rsmssb', 'rssb', 'cet', 'patwari', 'vdo', 'reet', 'rajasthan police', 'ldc'],
  },
  {
    name: 'UPSC — Union Public Service Commission (Official Portal)',
    url: 'https://upsc.gov.in/',
    domain: 'upsc.gov.in',
    category: 'Central Govt',
    description: 'संघ लोक सेवा आयोग (UPSC) की आधिकारिक वेबसाइट — IAS/CSE, NDA, CDS, CAPF परीक्षा कैलेंडर, नोटिफिकेशन, सिलेबस व एडमिट कार्ड।',
    keywords: ['upsc', 'ias', 'ips', 'cse', 'nda', 'cds', 'capf', 'civil services'],
  },
  {
    name: 'SSC — Staff Selection Commission (Official Portal)',
    url: 'https://ssc.gov.in/',
    domain: 'ssc.gov.in',
    category: 'Central Govt',
    description: 'कर्मचारी चयन आयोग (SSC) की आधिकारिक वेबसाइट — CGL, CHSL, MTS, GD Constable भर्ती विज्ञापन, ऑनलाइन आवेदन व परीक्षा तिथि।',
    keywords: ['ssc', 'cgl', 'chsl', 'mts', 'gd', 'cpo', 'stenographer', 'je'],
  },
  {
    name: 'NTA NEET UG — National Testing Agency (Official)',
    url: 'https://neet.nta.nic.in/',
    domain: 'neet.nta.nic.in',
    category: 'Medical Exam',
    description: 'राष्ट्रीय परीक्षा एजेंसी (NTA) NEET UG आधिकारिक पोर्टल — मेडिकल प्रवेश परीक्षा आवेदन, सूचना बुलेटिन, सिलेबस और परिणाम।',
    keywords: ['neet', 'medical', 'mbbs', 'nta'],
  },
  {
    name: 'NTA JEE Main — Joint Entrance Examination (Official)',
    url: 'https://jeemain.nta.nic.in/',
    domain: 'jeemain.nta.nic.in',
    category: 'Engineering Exam',
    description: 'NTA JEE Main आधिकारिक पोर्टल — B.E./B.Tech व B.Arch प्रवेश परीक्षा रजिस्ट्रेशन, परीक्षा शहर सूचना, एडमिट कार्ड और स्कोरकार्ड।',
    keywords: ['jee', 'iit', 'nit', 'engineering', 'nta'],
  },
  {
    name: 'CBSE — Central Board of Secondary Education',
    url: 'https://www.cbse.gov.in/',
    domain: 'cbse.gov.in',
    category: 'Board Exam',
    description: 'केंद्रीय माध्यमिक शिक्षा बोर्ड (CBSE) की आधिकारिक वेबसाइट — कक्षा 10वीं/12वीं डेटशीट, सिलेबस, सैंपल पेपर, CTET व बोर्ड रिज़ल्ट।',
    keywords: ['cbse', '10th', '12th', 'board exam', 'ctet'],
  },
  {
    name: 'RBSE — Board of Secondary Education, Rajasthan',
    url: 'https://rajeduboard.rajasthan.gov.in/',
    domain: 'rajeduboard.rajasthan.gov.in',
    category: 'Board Exam',
    description: 'राजस्थान माध्यमिक शिक्षा बोर्ड (अजमेर) आधिकारिक पोर्टल — 10वीं व 12वीं टाइम टेबल, सिलेबस, मॉडल पेपर व बोर्ड परीक्षा परिणाम।',
    keywords: ['rbse', 'bser', 'rajasthan board', '10th', '12th'],
  },
  {
    name: 'UP Police Recruitment & Promotion Board (UPPBPB)',
    url: 'https://uppbpb.gov.in/',
    domain: 'uppbpb.gov.in',
    category: 'Police / State',
    description: 'उत्तर प्रदेश पुलिस भर्ती एवं प्रोन्नति बोर्ड — कांस्टेबल, उप-निरीक्षक (SI) भर्ती विज्ञप्ति, शारीरिक व लिखित परीक्षा सूचना।',
    keywords: ['up police', 'uppbpb', 'constable', 'up si', 'uttar pradesh'],
  },
  {
    name: 'BPSC — Bihar Public Service Commission',
    url: 'https://bpsc.bihar.gov.in/',
    domain: 'bpsc.bihar.gov.in',
    category: 'State PSC',
    description: 'बिहार लोक सेवा आयोग (BPSC) आधिकारिक वेबसाइट — CCE, शिक्षक भर्ती (TRE) विज्ञापन, परीक्षा कैलेंडर व ऑनलाइन आवेदन।',
    keywords: ['bpsc', 'bihar', 'tre', 'bihar teacher'],
  },
  {
    name: 'MPPSC — Madhya Pradesh Public Service Commission',
    url: 'https://mppsc.mp.gov.in/',
    domain: 'mppsc.mp.gov.in',
    category: 'State PSC',
    description: 'मध्य प्रदेश लोक सेवा आयोग आधिकारिक पोर्टल — राज्य सेवा परीक्षा विज्ञापन, सिलेबस, प्रवेश पत्र व चयन सूची।',
    keywords: ['mppsc', 'madhya pradesh', 'mp police'],
  },
  {
    name: 'Indian Railways — Railway Recruitment Board (RRB)',
    url: 'https://www.rrbcdg.gov.in/',
    domain: 'rrbcdg.gov.in',
    category: 'Railway',
    description: 'भारतीय रेल भर्ती बोर्ड (RRB) आधिकारिक पोर्टल — NTPC, Group D, ALP, Technician भर्ती अधिसूचना, आवेदन व एडमिट कार्ड।',
    keywords: ['rrb', 'railway', 'ntpc', 'group d', 'alp', 'technician'],
  },
  {
    name: 'IBPS — Institute of Banking Personnel Selection',
    url: 'https://www.ibps.in/',
    domain: 'ibps.in',
    category: 'Banking',
    description: 'बैंकिंग कार्मिक चयन संस्थान (IBPS) की आधिकारिक वेबसाइट — PO, Clerk, RRB और SO परीक्षा कैलेंडर व ऑनलाइन आवेदन।',
    keywords: ['ibps', 'po', 'clerk', 'rrb po', 'bank'],
  },
  {
    name: 'PM-KISAN Samman Nidhi — Official Portal',
    url: 'https://pmkisan.gov.in/',
    domain: 'pmkisan.gov.in',
    category: 'Govt Scheme',
    description: 'प्रधानमंत्री किसान सम्मान निधि आधिकारिक पोर्टल — नया किसान पंजीकरण, e-KYC, लाभार्थी सूची व किस्त स्टेटस जांचें।',
    keywords: ['pm kisan', 'kisan', 'किसान', 'samman nidhi', 'किस्त'],
  },
  {
    name: 'Ayushman Bharat (PM-JAY) — NHA Official Portal',
    url: 'https://beneficiary.nha.gov.in/',
    domain: 'beneficiary.nha.gov.in',
    category: 'Govt Scheme',
    description: 'आयुष्मान भारत प्रधानमंत्री जन आरोग्य योजना — लाभार्थी पात्रता जांचें, आयुष्मान कार्ड डाउनलोड और ई-केवाईसी करें।',
    keywords: ['ayushman', 'आयुष्मान', 'pmjay', 'health card', 'आयुष्मान कार्ड'],
  },
  {
    name: 'NFSA Ration Card Portal — राष्ट्रीय खाद्य सुरक्षा पोर्टल',
    url: 'https://nfsa.gov.in/',
    domain: 'nfsa.gov.in',
    category: 'Ration Card',
    description: 'भारत सरकार राष्ट्रीय खाद्य सुरक्षा (NFSA) राशन कार्ड पोर्टल — नया राशन कार्ड आवेदन, सदस्य जोड़ना व स्टेटस।',
    keywords: ['ration', 'ration card', 'राशन कार्ड', 'राशन', 'nfsa'],
  },
  {
    name: 'Rajasthan e-Mitra / SSO Official Portal',
    url: 'https://sso.rajasthan.gov.in/',
    domain: 'sso.rajasthan.gov.in',
    category: 'Rajasthan e-Mitra',
    description: 'राजस्थान SSO एवं ई-मित्र पोर्टल — जन आधार, राजस्थान मूल निवास, जाति व आय प्रमाण पत्र और सभी राज्य सरकारी सेवाएँ।',
    keywords: ['sso.rajasthan', 'sso rajasthan', 'rajasthan', 'राजस्थान', 'जन आधार', 'jan aadhaar'],
  },
  {
    name: 'MP e-District & MPOnline — मध्य प्रदेश नागरिक पोर्टल',
    url: 'https://mpedistrict.gov.in/',
    domain: 'mpedistrict.gov.in',
    category: 'MP Govt',
    description: 'मध्य प्रदेश ई-डिस्ट्रिक्ट एवं MPOnline (mponline.gov.in) — समग्र, मूल निवास, जाति व आय प्रमाण पत्र और लोक सेवा गारंटी सेवाएँ।',
    keywords: ['madhya pradesh', 'mpedistrict', 'mponline', 'samagra', 'मध्य प्रदेश', 'समग्र', 'एमपी ऑनलाइन'],
  },
  {
    name: 'UP e-District & जनसेवा केंद्र (e-Sathi) Portal',
    url: 'https://edistrict.up.gov.in/',
    domain: 'edistrict.up.gov.in',
    category: 'UP Govt',
    description: 'उत्तर प्रदेश ई-डिस्ट्रिक्ट एवं जनसेवा केंद्र पोर्टल — आय, जाति, निवास प्रमाण पत्र, परिवार आईडी व राज्य सरकारी सेवाएँ।',
    keywords: ['uttar pradesh', 'uppsc', 'edistrict up', 'jan seva kendra', 'उत्तर प्रदेश', 'जनसेवा केंद्र', 'ई-साथी'],
  },
  {
    name: 'RTPS Bihar / ServicePlus बिहार नागरिक पोर्टल',
    url: 'https://serviceonline.bihar.gov.in/',
    domain: 'serviceonline.bihar.gov.in',
    category: 'Bihar Govt',
    description: 'बिहार लोक सेवाओं का अधिकार (RTPS) पोर्टल — आवासीय, जाति, आय प्रमाण पत्र और बिहार नागरिक सेवाएँ।',
    keywords: ['bihar', 'rtps', 'serviceonline.bihar', 'बिहार', 'आवासीय प्रमाण'],
  },
  {
    name: 'Maharashtra Aaple Sarkar & MPSC Portal',
    url: 'https://aaplesarkar.mahaonline.gov.in/',
    domain: 'aaplesarkar.mahaonline.gov.in',
    category: 'Maharashtra Govt',
    description: 'महाराष्ट्र शासन आपले सरकार पोर्टल — रहिवासी, उत्पन्न, जात प्रमाणपत्र व MahaDBT सेवाएँ।',
    keywords: ['maharashtra', 'mpsc', 'mahadbt', 'aaple sarkar', 'mumbai', 'pune', 'महाराष्ट्र', 'आपले सरकार'],
  },
  {
    name: 'Delhi e-District & DSSSB Official Portal',
    url: 'https://edistrict.delhigovt.nic.in/',
    domain: 'edistrict.delhigovt.nic.in',
    category: 'Delhi Govt',
    description: 'दिल्ली ई-डिस्ट्रिक्ट व DSSSB आधिकारिक पोर्टल — निवास, जाति, आय प्रमाण पत्र व दिल्ली नागरिक सेवाएँ।',
    keywords: ['delhi', 'dsssb', 'edistrict delhi', 'दिल्ली'],
  },
  {
    name: 'Digital Gujarat & GPSC Official Portal',
    url: 'https://www.digitalgujarat.gov.in/',
    domain: 'digitalgujarat.gov.in',
    category: 'Gujarat Govt',
    description: 'डिजिटल गुजरात एवं GPSC पोर्टल — छात्रवृत्ति, नागरिक प्रमाण पत्र व गुजरात सरकारी सेवाएँ।',
    keywords: ['gujarat', 'gpsc', 'gsssb', 'गुजरात', 'डिजिटल गुजरात'],
  },
  {
    name: 'SARAL Haryana & HSSC Official Portal',
    url: 'https://saralharyana.gov.in/',
    domain: 'saralharyana.gov.in',
    category: 'Haryana Govt',
    description: 'सरल हरियाणा एवं HSSC पोर्टल — परिवार पहचान पत्र (PPP), प्रमाण पत्र व राज्य योजनाएँ।',
    keywords: ['haryana', 'hssc', 'hpsc', 'saral', 'parivar pehchan', 'हरियाणा', 'सरल हरियाणा'],
  },
  {
    name: 'CG e-District — छत्तीसगढ़ लोक सेवा पोर्टल',
    url: 'https://edistrict.cgstate.gov.in/',
    domain: 'edistrict.cgstate.gov.in',
    category: 'Chhattisgarh Govt',
    description: 'छत्तीसगढ़ ई-डिस्ट्रिक्ट व चॉइस पोर्टल — मूल निवास, जाति व आय प्रमाण पत्र और राज्य सेवाएँ।',
    keywords: ['chhattisgarh', 'cgstate', 'cgpsc', 'cg vyapam', 'छत्तीसगढ़'],
  },
  {
    name: 'Punjab Sewa Connect & PSSSB Portal',
    url: 'https://connect.punjab.gov.in/',
    domain: 'connect.punjab.gov.in',
    category: 'Punjab Govt',
    description: 'पंजाब डिजिटल नागरिक सेवा पोर्टल (Sewa Connect) व PSSSB सरकारी सेवाएँ।',
    keywords: ['punjab', 'psssb', 'ppsc', 'पंजाब'],
  },
  {
    name: 'West Bengal e-District & WBPSC Portal',
    url: 'https://edistrict.wb.gov.in/',
    domain: 'edistrict.wb.gov.in',
    category: 'West Bengal Govt',
    description: 'पश्चिम बंगाल ई-डिस्ट्रिक्ट एवं WBPSC सरकारी सेवा व प्रमाण पत्र पोर्टल।',
    keywords: ['west bengal', 'wbpsc', 'kolkata', 'पश्चिम बंगाल'],
  },
  {
    name: 'Tamil Nadu e-Sevai (TNeGA) & TNPSC Portal',
    url: 'https://www.tnesevai.tn.gov.in/',
    domain: 'tnesevai.tn.gov.in',
    category: 'Tamil Nadu Govt',
    description: 'तमिलनाडु TNeGA ई-सेवा नागरिक प्रमाण पत्र पोर्टल व TNPSC।',
    keywords: ['tamil nadu', 'tnpsc', 'chennai', 'tnesevai', 'tnega', 'तमिलनाडु'],
  },
  {
    name: 'Karnataka Seva Sindhu & KPSC Portal',
    url: 'https://sevasindhu.karnataka.gov.in/',
    domain: 'sevasindhu.karnataka.gov.in',
    category: 'Karnataka Govt',
    description: 'कर्नाटक सेवा सिंधु पोर्टल — गारंटी योजनाएँ, प्रमाण पत्र व नागरिक सेवाएँ।',
    keywords: ['karnataka', 'seva sindhu', 'kpsc', 'bengaluru', 'कर्नाटक', 'सेवा सिंधु'],
  },
  {
    name: 'e-District Kerala Citizen Portal',
    url: 'https://edistrict.kerala.gov.in/',
    domain: 'edistrict.kerala.gov.in',
    category: 'Kerala Govt',
    description: 'केरल ई-डिस्ट्रिक्ट व अक्षय केंद्र नागरिक सेवा पोर्टल।',
    keywords: ['kerala', 'akshaya', 'keralapsc', 'केरल'],
  },
  {
    name: 'MeeSeva Telangana Citizen Portal',
    url: 'https://ts.meeseva.telangana.gov.in/',
    domain: 'ts.meeseva.telangana.gov.in',
    category: 'Telangana Govt',
    description: 'तेलंगाना मीसेवा (MeeSeva) व TGPSC नागरिक सेवा पोर्टल।',
    keywords: ['telangana', 'meeseva', 'tspsc', 'tgpsc', 'hyderabad', 'तेलंगाना'],
  },
  {
    name: 'AP Grama/Ward Sachivalayam & MeeSeva Portal',
    url: 'https://vsws.ap.gov.in/',
    domain: 'vsws.ap.gov.in',
    category: 'AP Govt',
    description: 'आंध्र प्रदेश ग्राम/वार्ड सचिवालय व नागरिक सेवा पोर्टल।',
    keywords: ['andhra pradesh', 'appsc', 'sachivalayam', 'आंध्र प्रदेश'],
  },
  {
    name: 'e-District Odisha & Mo Seba Portal',
    url: 'https://edistrict.odisha.gov.in/',
    domain: 'edistrict.odisha.gov.in',
    category: 'Odisha Govt',
    description: 'ओडिशा ई-डिस्ट्रिक्ट व राज्य नागरिक सेवा पोर्टल।',
    keywords: ['odisha', 'orissa', 'opsc', 'ओडिशा'],
  },
  {
    name: 'JharSewa — झारखंड ई-डिस्ट्रिक्ट पोर्टल',
    url: 'https://jharsewa.jharkhand.gov.in/',
    domain: 'jharsewa.jharkhand.gov.in',
    category: 'Jharkhand Govt',
    description: 'झारसेवा पोर्टल — स्थानीय निवासी, जाति, आय प्रमाण पत्र व झारखंड नागरिक सेवाएँ।',
    keywords: ['jharkhand', 'jharsewa', 'jssc', 'jpsc', 'झारखंड', 'झारसेवा'],
  },
  {
    name: 'Apuni Sarkar — अपनी सरकार उत्तराखंड पोर्टल',
    url: 'https://eservices.uk.gov.in/',
    domain: 'eservices.uk.gov.in',
    category: 'Uttarakhand Govt',
    description: 'उत्तराखंड अपनी सरकार पोर्टल — स्थायी निवास, जाति व आय प्रमाण पत्र।',
    keywords: ['uttarakhand', 'apuni sarkar', 'ukpsc', 'उत्तराखंड'],
  },
  {
    name: 'e-District Himachal Pradesh Portal',
    url: 'https://edistrict.hp.gov.in/',
    domain: 'edistrict.hp.gov.in',
    category: 'HP Govt',
    description: 'हिमाचल प्रदेश ई-डिस्ट्रिक्ट — Bonafide Himachali, जाति व आय प्रमाण पत्र।',
    keywords: ['himachal', 'himachal pradesh', 'hppsc', 'हिमाचल'],
  },
  {
    name: 'Sewa Setu Assam Citizen Portal',
    url: 'https://sewasetu.assam.gov.in/',
    domain: 'sewasetu.assam.gov.in',
    category: 'Assam Govt',
    description: 'असम सेवा सेतु (Sewa Setu) पोर्टल — PRC, जाति, आय प्रमाण पत्र व नागरिक सेवाएँ।',
    keywords: ['assam', 'sewa setu', 'sewasetu', 'असम'],
  },
  {
    name: 'National Government Services Portal (India)',
    url: 'https://services.india.gov.in/',
    domain: 'services.india.gov.in',
    category: 'All India Citizen',
    description: 'भारत सरकार का एकीकृत राष्ट्रीय नागरिक सेवा पोर्टल — सभी राज्यों की ई-डिस्ट्रिक्ट व सरकारी सेवाओं के लिंक।',
    keywords: ['all india', 'services.india', 'serviceonline'],
  },
  {
    name: 'Parivahan Sewa / Sarathi — Driving Licence & RC Portal',
    url: 'https://parivahan.gov.in/',
    domain: 'parivahan.gov.in',
    category: 'Transport Portal',
    description: 'भारत सरकार परिवहन व सारथी पोर्टल — ड्राइविंग लाइसेंस (LL/DL), वाहन RC, चालान व RTO सेवाएँ।',
    keywords: ['driving license', 'driving licence', 'parivahan', 'sarathi', 'ड्राइविंग लाइसेंस', 'लाइसेंस', 'vahan'],
  },
  {
    name: 'USA.gov & USCIS — United States Official Portal',
    url: 'https://www.usa.gov/',
    domain: 'usa.gov',
    category: 'US Govt (.gov)',
    description: 'Official U.S. government portal for Social Security, Passports, IRS taxes, federal jobs (USAJOBS), and USCIS immigration/visas.',
    keywords: ['usa', 'united states', 'us visa', 'uscis', 'h-1b', 'green card', 'f-1', 'social security', 'अमेरिका'],
  },
  {
    name: 'GOV.UK — United Kingdom Official Portal',
    url: 'https://www.gov.uk/',
    domain: 'gov.uk',
    category: 'UK Govt (.gov.uk)',
    description: 'Official UK government portal for GOV.UK One Login, Visas & Immigration, Passports, DVLA Driving Licence, NHS, and HMRC.',
    keywords: ['uk', 'united kingdom', 'britain', 'gov.uk', 'uk visa', 'dvla', 'ब्रिटेन'],
  },
  {
    name: 'U.AE & ICP Smart Services — United Arab Emirates Official Portal',
    url: 'https://u.ae/',
    domain: 'u.ae',
    category: 'UAE Govt (.gov.ae)',
    description: 'Official UAE government portal for UAE Pass, Golden Visa, Emirates ID (icp.gov.ae), MOHRE work permits, and Dubai/Abu Dhabi e-services.',
    keywords: ['uae', 'dubai', 'abu dhabi', 'united arab emirates', 'golden visa', 'emirates', 'emirates id', 'icp', 'uae pass', 'दुबई', 'यूएई'],
  },
  {
    name: 'Absher & MY.GOV.SA — Saudi Arabia Official Portal',
    url: 'https://www.absher.sa/',
    domain: 'absher.sa',
    category: 'Saudi Govt (.sa)',
    description: 'Official Saudi Arabia Absher & MY.GOV.SA portal for Iqama renewal, Exit/Re-Entry visa, Saudi Passports, and Civil Affairs.',
    keywords: ['saudi', 'saudi arabia', 'ksa', 'absher', 'iqama', 'my.gov.sa', 'nafath', 'सऊदी'],
  },
  {
    name: 'Canada.ca — Government of Canada & IRCC Official Portal',
    url: 'https://www.canada.ca/en/services.html',
    domain: 'canada.ca',
    category: 'Canada Govt (.gc.ca)',
    description: 'Official Government of Canada (Service Canada & IRCC) portal for Express Entry PR, Study/Work Permits, SIN, and CRA.',
    keywords: ['canada', 'ircc', 'express entry', 'gc.ca', 'gckey', 'कनाडा'],
  },
  {
    name: 'myGov Australia & Home Affairs — Official Portal',
    url: 'https://my.gov.au/',
    domain: 'my.gov.au',
    category: 'Australia Govt (.gov.au)',
    description: 'Official Australian Government myGov & Home Affairs portal for Medicare, ATO, Student Visas, and Skilled Migration.',
    keywords: ['australia', 'gov.au', 'mygov', 'my.gov.au', 'australian visa', 'ऑस्ट्रेलिया'],
  },
  {
    name: 'BundID & Make it in Germany — Official German Portal',
    url: 'https://id.bund.de/',
    domain: 'id.bund.de',
    category: 'Germany Govt',
    description: 'Official German federal citizen portal (BundID) and Make it in Germany for Chancenkarte, EU Blue Card, and municipal services.',
    keywords: ['germany', 'deutschland', 'chancenkarte', 'blue card', 'bundid', 'id.bund.de', 'जर्मनी'],
  },
  {
    name: 'Singpass & Gov.sg — Singapore Official Government Portal',
    url: 'https://www.singpass.gov.sg/',
    domain: 'singpass.gov.sg',
    category: 'Singapore Govt (.gov.sg)',
    description: 'Official Singapore digital portal (Singpass & Gov.sg) for Myinfo, ICA, MOM Employment Pass, and citizen e-services.',
    keywords: ['singapore', 'singpass', 'gov.sg', 'myinfo', 'सिंगापुर'],
  },
  {
    name: 'Service-Public.fr & France-Visas — Official French Portal',
    url: 'https://www.service-public.fr/',
    domain: 'service-public.fr',
    category: 'France Govt (.fr)',
    description: 'Official French citizen & visa portal (Service-Public.fr & FranceConnect) for civil certificates and Schengen visas.',
    keywords: ['france', 'service-public', 'franceconnect', 'france-visas', 'फ्रांस'],
  },
  {
    name: 'JapanGov & My Number Portal — Official Japanese Portal',
    url: 'https://www.japan.go.jp/',
    domain: 'japan.go.jp',
    category: 'Japan Govt (.go.jp)',
    description: 'Official Government of Japan portal for My Number e-services, work/student visas, and MEXT scholarships.',
    keywords: ['japan', 'mext', 'go.jp', 'myna', 'जापान'],
  },
  {
    name: 'Govt.nz & Immigration New Zealand — Official Portal',
    url: 'https://www.govt.nz/',
    domain: 'govt.nz',
    category: 'NZ Govt (.govt.nz)',
    description: 'Official New Zealand Government & RealMe portal for citizen certificates, taxes, and immigration visas.',
    keywords: ['new zealand', 'realme', 'govt.nz', 'न्यूजीलैंड'],
  },
  {
    name: 'Income Tax e-Filing & PAN Card Portal (भारत सरकार)',
    url: 'https://www.incometax.gov.in/',
    domain: 'incometax.gov.in',
    category: 'PAN / Tax Portal',
    description: 'पैन कार्ड (Instant e-PAN / नया पैन आवेदन), आधार-पैन लिंकिंग व इनकम टैक्स ऑनलाइन सेवाओं का आधिकारिक सरकारी पोर्टल।',
    keywords: ['pan', 'pancard', 'pan card', 'पैन कार्ड', 'पैन', 'income tax', 'e-pan', 'nsdl'],
  },
  {
    name: 'Passport Seva — Ministry of External Affairs (MEA)',
    url: 'https://www.passportindia.gov.in/',
    domain: 'passportindia.gov.in',
    category: 'Passport Portal',
    description: 'भारतीय पासपोर्ट (नया / नवीनीकरण / पुलिस वेरिफिकेशन व अपॉइंटमेंट) आवेदन का आधिकारिक सरकारी पोर्टल।',
    keywords: ['passport', 'पासपोर्ट', 'passport seva'],
  },
  {
    name: 'National Scholarship Portal (NSP) — भारत सरकार',
    url: 'https://scholarships.gov.in/',
    domain: 'scholarships.gov.in',
    category: 'Scholarship & Admission',
    description: 'राष्ट्रीय छात्रवृत्ति पोर्टल (NSP) — स्कूल, कॉलेज व विश्वविद्यालय छात्रों के लिए सरकारी छात्रवृत्ति व आवेदन।',
    keywords: ['scholarship', 'छात्रवृत्ति', 'nsp'],
  },
  {
    name: 'NTA CUET / Samarth University Admission Portal',
    url: 'https://cuet.nta.nic.in/',
    domain: 'cuet.nta.nic.in',
    category: 'College Admission',
    description: 'केंद्रीय एवं राज्य विश्वविद्यालयों (UG/PG कॉलेज एडमिशन व प्रवेश परीक्षा) का आधिकारिक पोर्टल।',
    keywords: ['college admission', 'कॉलेज एडमिशन', 'एडमिशन', 'admission', 'cuet', 'university'],
  },
  {
    name: 'National Portal of India — भारत सरकार पोर्टल',
    url: 'https://www.india.gov.in/',
    domain: 'india.gov.in',
    category: 'Govt of India',
    description: 'भारत सरकार का राष्ट्रीय पोर्टल — केंद्र और राज्य सरकार की सभी योजनाओं, परीक्षाओं, विभागों व सेवाओं के आधिकारिक लिंक।',
    keywords: ['india', 'govt', 'sarkari', 'सरकारी', 'योजना', 'yojana', 'scheme'],
  },
];

interface CitizenRegionMeta {
  key: string;
  label: string;
  scope: 'india' | 'global';
  portalName: string;
  domain: string;
  url: string;
  feeHi: string;
  feeEn: string;
  docsHi: string;
  docsEn: string;
  stepsHi: string[];
  stepsEn: string[];
  queryRegex: RegExp;
  locationRegex: RegExp;
}

const CITIZEN_REGION_REGISTRY: CitizenRegionMeta[] = [
  {
    key: 'rajasthan',
    label: 'राजस्थान (Rajasthan)',
    scope: 'india',
    portalName: 'Rajasthan E-Mitra / SSO Portal',
    domain: 'sso.rajasthan.gov.in',
    url: 'https://sso.rajasthan.gov.in/',
    feeHi: 'ई-मित्र टोकन शुल्क **₹30 से ₹50** (जन आधार, मूल निवास, जाति व आय प्रमाण पत्र)।',
    feeEn: '**₹30 to ₹50** E-Mitra token fee for Jan Aadhaar, Domicile, Caste & Income certificates.',
    docsHi: 'जन आधार कार्ड (Jan Aadhaar), आधार कार्ड, राशन कार्ड, पासपोर्ट साइज फोटो और स्व-घोषणा पत्र।',
    docsEn: 'Jan Aadhaar Card, Aadhaar Card, Ration Card, Passport Photo, and Self-Declaration Form.',
    stepsHi: [
      'नीचे दिए हरे बटन से **sso.rajasthan.gov.in** खोलें और अपनी SSO ID / जन आधार से लॉगिन करें (या नज़दीकी ई-मित्र केंद्र जाएं)।',
      'Citizen Apps में **E-Mitra** चुनकर जाति, मूल निवास, आय प्रमाण पत्र या जन आधार सेवा भरें।',
      'दस्तावेज़ अपलोड कर ₹30–₹50 टोकन शुल्क जमा करें और डिजिटल सर्टिफिकेट डाउनलोड करें।',
    ],
    stepsEn: [
      'Open **sso.rajasthan.gov.in** via the button below and sign in with your SSO ID.',
      'Select **E-Mitra** under Citizen Apps and choose Jan Aadhaar, Domicile, Caste, or Income certificate.',
      'Upload documents, pay ₹30–₹50, and download your digitally signed PDF.',
    ],
    queryRegex: /\b(rajasthan|rj|sso\.rajasthan|jan\s*aadhaar|rpsc|rssb|rsmssb|jaipur|jodhpur|udaipur)\b|राजस्थान|जन\s*आधार/i,
    locationRegex: /rajasthan/i,
  },
  {
    key: 'mp',
    label: 'मध्य प्रदेश (Madhya Pradesh)',
    scope: 'india',
    portalName: 'MP e-District & MPOnline (मध्य प्रदेश लोक सेवा गारंटी)',
    domain: 'mpedistrict.gov.in',
    url: 'https://mpedistrict.gov.in/',
    feeHi: 'लोक सेवा गारंटी / MPOnline शुल्क **₹20 से ₹40** (निवास, जाति व आय प्रमाण पत्र; कियोस्क **mponline.gov.in** पर भी उपलब्ध)।',
    feeEn: '**₹20 to ₹40** Lok Seva Kendra / **mpedistrict.gov.in** & **mponline.gov.in** service fee.',
    docsHi: 'समग्र आईडी (Samagra ID), आधार कार्ड, राशन कार्ड / वोटर आईडी, स्व-घोषणा पत्र और पासपोर्ट फोटो।',
    docsEn: 'Samagra ID, Aadhaar Card, Ration Card / Voter ID, Self-Declaration Form, and Passport Photo.',
    stepsHi: [
      'नीचे दिए हरे बटन से **mpedistrict.gov.in** खोलें (अथवा अन्य ऑनलाइन सेवाओं हेतु **mponline.gov.in** का उपयोग करें)।',
      'समग्र आईडी व आधार OTP से लॉगिन कर स्थानीय निवासी, डिजिटल जाति या आय प्रमाण पत्र सेवा चुनें।',
      'दस्तावेज़ अपलोड कर ₹20–₹40 शुल्क जमा करें और डिजिटल हस्ताक्षरित प्रमाण पत्र डाउनलोड करें।',
    ],
    stepsEn: [
      'Open **mpedistrict.gov.in** (or **mponline.gov.in** for MPOnline kiosk services) via the button below.',
      'Verify with Samagra ID & Aadhaar OTP and select Domicile, Caste, or Income certificate.',
      'Upload documents, pay ₹20–₹40, and download your signed PDF certificate.',
    ],
    queryRegex: /\b(madhya\s*pradesh|mponline|mpedistrict|mppsc|mpesb|samagra|ladli\s*behna|bhopal|indore)\b|\bmp\b|मध्य\s*प्रदेश|समग्र|एमपी\s*ऑनलाइन/i,
    locationRegex: /madhya pradesh/i,
  },
  {
    key: 'up',
    label: 'उत्तर प्रदेश (Uttar Pradesh)',
    scope: 'india',
    portalName: 'UP e-District / जनसेवा केंद्र (e-Sathi)',
    domain: 'edistrict.up.gov.in',
    url: 'https://edistrict.up.gov.in/',
    feeHi: 'ई-साथी (Citizen Login) से **₹15 प्रति प्रमाण पत्र** | जनसेवा केंद्र (CSC) शुल्क **₹30**।',
    feeEn: '**₹15** via Citizen Login (e-Sathi) | **₹30** at Jan Seva Kendra (CSC).',
    docsHi: 'आधार कार्ड, परिवार आईडी (Family ID) / राशन कार्ड, स्वप्रमाणित घोषणा पत्र व पासपोर्ट फोटो।',
    docsEn: 'Aadhaar Card, UP Family ID / Ration Card, Self-Declaration Form, and Passport Photo.',
    stepsHi: [
      'नीचे दिए हरे बटन से **edistrict.up.gov.in** खोलें और **सिटीजन लॉगिन (ई-साथी)** से लॉगिन करें।',
      'जाति, आय या निवास प्रमाण पत्र फॉर्म भरें और स्वप्रमाणित घोषणा पत्र व आधार अपलोड करें।',
      '₹15 ऑनलाइन शुल्क जमा करें; तहसील सत्यापन के बाद पोर्टल से ही डिजिटल प्रमाण पत्र डाउनलोड करें।',
    ],
    stepsEn: [
      'Open **edistrict.up.gov.in** and sign in via **Citizen Login (e-Sathi)**.',
      'Fill out the Caste, Income, or Domicile certificate form and upload your self-declaration & Aadhaar.',
      'Pay ₹15 online and download the signed PDF after Tehsil verification.',
    ],
    queryRegex: /\b(uttar\s*pradesh|uppsc|uppbpb|edistrict\s*up|jan\s*seva|bhulekh\s*up|lucknow|varanasi|noida)\b|\bup\b|उत्तर\s*प्रदेश|जनसेवा\s*केंद्र|ई-साथी/i,
    locationRegex: /uttar pradesh/i,
  },
  {
    key: 'bihar',
    label: 'बिहार (Bihar)',
    scope: 'india',
    portalName: 'RTPS Bihar / ServicePlus बिहार पोर्टल',
    domain: 'serviceonline.bihar.gov.in',
    url: 'https://serviceonline.bihar.gov.in/',
    feeHi: 'स्वयं ऑनलाइन आवेदन **₹0 (बिल्कुल मुफ्त)** | वसुधा केंद्र / CSC शुल्क **₹20–₹30**।',
    feeEn: '**₹0 (Free)** via direct online RTPS Bihar portal | **₹20–₹30** at Vasudha Kendra / CSC.',
    docsHi: 'आधार कार्ड (मोबाइल OTP), स्व-अभिप्रमाणित पासपोर्ट फोटो, स्थानीय पता/भूमि प्रमाण व आय विवरण।',
    docsEn: 'Aadhaar Card, Self-attested Passport Photo, Residence/Land proof.',
    stepsHi: [
      'नीचे दिए हरे बटन से **serviceonline.bihar.gov.in** खोलें और **लोक सेवाओं का अधिकार (RTPS)** -> सामान्य प्रशासन विभाग चुनें।',
      'आवासीय (निवास), जाति या आय प्रमाण पत्र (अंचल/अनुमंडल स्तर) चुनकर फॉर्म भरें व दस्तावेज़ अपलोड करें।',
      '₹0 में सबमिट कर रसीद सेव करें और 10–14 कार्य दिवस में डिजिटल सर्टिफिकेट डाउनलोड करें।',
    ],
    stepsEn: [
      'Open **serviceonline.bihar.gov.in** and choose General Administration Dept under RTPS Services.',
      'Select Residence, Caste, or Income certificate and upload your self-attested photo & Aadhaar.',
      'Submit for ₹0, save the acknowledgment slip, and download the signed PDF once ready.',
    ],
    queryRegex: /\b(bihar|rtps|bpsc|serviceonline\.bihar|patna|vasudha\s*kendra)\b|बिहार|आवासीय\s*प्रमाण/i,
    locationRegex: /bihar/i,
  },
  {
    key: 'maharashtra',
    label: 'महाराष्ट्र (Maharashtra)',
    scope: 'india',
    portalName: 'Aaple Sarkar (आपले सरकार महाराष्ट्र)',
    domain: 'aaplesarkar.mahaonline.gov.in',
    url: 'https://aaplesarkar.mahaonline.gov.in/',
    feeHi: '**₹33.60** ऑनलाइन सेवा शुल्क (आपले सरकार / MahaOnline) | सेतू केंद्र पर ₹59 तक।',
    feeEn: '**₹33.60** online citizen fee on Aaple Sarkar (up to ₹59 at Setu Kendra).',
    docsHi: 'आधार कार्ड, रेशन कार्ड, शाळा सोडल्याचा दाखला (LC/TC) किंवा रहिवासी पुरावा व स्व-घोषणापत्र।',
    docsEn: 'Aadhaar Card, Ration Card, School Leaving Certificate (LC) or Residence Proof, Self-Declaration.',
    stepsHi: [
      'नीचे दिए हरे बटन से **aaplesarkar.mahaonline.gov.in** खोलें और मोबाइल OTP से लॉगिन करें।',
      'Revenue Department में Domicile, Income या Caste Certificate चुनकर दस्तावेज़ अपलोड करें।',
      '₹33.60 ऑनलाइन जमा करें और अनुमोदन के बाद PDF प्रमाण पत्र डाउनलोड करें।',
    ],
    stepsEn: [
      'Open **aaplesarkar.mahaonline.gov.in** and log in with Mobile OTP.',
      'Choose Domicile, Income, or Caste Certificate under Revenue Dept and upload proofs.',
      'Pay ₹33.60 online and download your digitally signed certificate.',
    ],
    queryRegex: /\b(maharashtra|aaple\s*sarkar|mahaonline|mahadbt|mpsc|mumbai|pune|nagpur)\b|महाराष्ट्र|आपले\s*सरकार/i,
    locationRegex: /maharashtra/i,
  },
  {
    key: 'delhi',
    label: 'दिल्ली (Delhi NCT)',
    scope: 'india',
    portalName: 'e-District Delhi (दिल्ली सरकार)',
    domain: 'edistrict.delhigovt.nic.in',
    url: 'https://edistrict.delhigovt.nic.in/',
    feeHi: '**₹0 (निःशुल्क)** — दिल्ली ई-डिस्ट्रिक्ट पोर्टल पर अधिकांश प्रमाण पत्र आवेदन मुफ्त हैं।',
    feeEn: '**₹0 (Free)** online application on e-District Delhi for Domicile/Caste/Income certificates.',
    docsHi: 'आधार कार्ड, दिल्ली में 3 वर्ष के निवास का प्रमाण (बिजली/पानी बिल), जन्म/आय प्रमाण व स्व-घोषणा पत्र।',
    docsEn: 'Aadhaar Card, 3-year Delhi address proof (utility bill), birth/income proof, self-declaration.',
    stepsHi: [
      'नीचे दिए हरे बटन से **edistrict.delhigovt.nic.in** खोलें और आधार/वोटर आईडी से Citizen Login करें।',
      'Revenue Department में Domicile, Caste, OBC या Income प्रमाण पत्र चुनें और दस्तावेज़ अपलोड करें।',
      '₹0 में सबमिट करें और SDM सत्यापन के बाद सर्टिफिकेट डाउनलोड करें।',
    ],
    stepsEn: [
      'Open **edistrict.delhigovt.nic.in** and log in as a registered Citizen.',
      'Choose Domicile, Caste, or Income Certificate under Revenue Department.',
      'Upload documents, submit for ₹0, and download after SDM verification.',
    ],
    queryRegex: /\b(delhi|dsssb|edistrict\.delhigovt|new\s*delhi)\b|दिल्ली/i,
    locationRegex: /delhi/i,
  },
  {
    key: 'gujarat',
    label: 'गुजरात (Gujarat)',
    scope: 'india',
    portalName: 'Digital Gujarat Portal (डिजिटल गुजरात)',
    domain: 'digitalgujarat.gov.in',
    url: 'https://www.digitalgujarat.gov.in/',
    feeHi: '**₹20 से ₹30** सेवा शुल्क (डिजिटल गुजरात / ई-ग्राम या जनसेवा केंद्र)।',
    feeEn: '**₹20 to ₹30** service fee on Digital Gujarat / e-Gram Kendra.',
    docsHi: 'आधार कार्ड, राशन कार्ड, स्कूल लीविंग सर्टिफिकेट (LC), निवास व आय का प्रमाण, फोटो।',
    docsEn: 'Aadhaar Card, Ration Card, School Leaving Certificate (LC), Residence & Income proof.',
    stepsHi: [
      'नीचे दिए हरे बटन से **digitalgujarat.gov.in** खोलें और Citizen Login करें।',
      '*Services -> Citizen Services* से Income, Caste, Non-Creamy Layer या Domicile चुनें।',
      'दस्तावेज़ अपलोड कर ₹20–₹30 शुल्क जमा करें और डिजिटल सर्टिफिकेट डाउनलोड करें।',
    ],
    stepsEn: [
      'Open **digitalgujarat.gov.in** and sign in via Citizen Login.',
      'Select Income, Caste, Non-Creamy Layer, or Domicile under Citizen Services.',
      'Pay ₹20–₹30 online and download your signed certificate.',
    ],
    queryRegex: /\b(gujarat|digital\s*gujarat|gpsc|gsssb|ahmedabad|surat|vadodara)\b|गुजरात|डिजिटल\s*गुजरात/i,
    locationRegex: /gujarat/i,
  },
  {
    key: 'haryana',
    label: 'हरियाणा (Haryana)',
    scope: 'india',
    portalName: 'Antyodaya-SARAL Haryana (सरल हरियाणा)',
    domain: 'saralharyana.gov.in',
    url: 'https://saralharyana.gov.in/',
    feeHi: '**₹10 से ₹50** सरकारी प्रमाण पत्र शुल्क (सरल पोर्टल / अटल सेवा केंद्र)।',
    feeEn: '**₹10 to ₹50** citizen service fee on Saral Haryana / Atal Seva Kendra.',
    docsHi: 'परिवार पहचान पत्र (PPP / Family ID — अनिवार्य), आधार कार्ड, पते का प्रमाण व स्व-घोषणा पत्र।',
    docsEn: 'Parivar Pehchan Patra (PPP / Family ID — mandatory), Aadhaar Card, Address proof.',
    stepsHi: [
      'नीचे दिए हरे बटन से **saralharyana.gov.in** खोलें और सरल/जनपरिचय आईडी से लॉगिन करें।',
      'अपनी **Family ID (PPP)** दर्ज कर OTP सत्यापित करें और जाति/निवास/आय प्रमाण पत्र चुनें।',
      '₹10–₹50 शुल्क जमा करें और डिजिटल सर्टिफिकेट डाउनलोड करें।',
    ],
    stepsEn: [
      'Open **saralharyana.gov.in** and log in with JanParichay/Saral credentials.',
      'Enter your **Parivar Pehchan Patra (PPP)** ID, verify OTP, and select the certificate.',
      'Pay ₹10–₹50 and download your digitally signed certificate.',
    ],
    queryRegex: /\b(haryana|saral\s*haryana|saralharyana|parivar\s*pehchan|ppp|hssc|hpsc|gurugram)\b|हरियाणा|सरल\s*हरियाणा|परिवार\s*पहचान/i,
    locationRegex: /haryana/i,
  },
  {
    key: 'chhattisgarh',
    label: 'छत्तीसगढ़ (Chhattisgarh)',
    scope: 'india',
    portalName: 'CG e-District (छत्तीसगढ़ ई-डिस्ट्रिक्ट / चॉइस पोर्टल)',
    domain: 'edistrict.cgstate.gov.in',
    url: 'https://edistrict.cgstate.gov.in/',
    feeHi: '**₹30 से ₹50** (लोक सेवा केंद्र / चॉइस सेंटर / ऑनलाइन टोकन शुल्क)।',
    feeEn: '**₹30 to ₹50** on CG e-District / Lok Seva Kendra (CHOICE).',
    docsHi: 'आधार कार्ड, राशन कार्ड, बी-1 खसरा / मिसल रिकॉर्ड या निवास प्रमाण, स्व-घोषणा पत्र व फोटो।',
    docsEn: 'Aadhaar Card, Ration Card, B-1/Misal or Residence proof, Self-declaration, Photo.',
    stepsHi: [
      'नीचे दिए हरे बटन से **edistrict.cgstate.gov.in** खोलें और **नागरिक (Citizen)** लॉगिन करें।',
      'मूल निवास, जाति या आय प्रमाण पत्र सेवा चुनकर दस्तावेज़ अपलोड करें।',
      '₹30–₹50 शुल्क जमा करें और तहसील से जारी डिजिटल सर्टिफिकेट डाउनलोड करें।',
    ],
    stepsEn: [
      'Open **edistrict.cgstate.gov.in** and sign in under Citizen Login.',
      'Select Domicile, Caste, or Income Certificate and attach required proofs.',
      'Pay ₹30–₹50 and download your digitally signed PDF.',
    ],
    queryRegex: /\b(chhattisgarh|cgstate|cgpsc|cg\s*vyapam|raipur)\b|\bcg\b|छत्तीसगढ़/i,
    locationRegex: /chhattisgarh/i,
  },
  {
    key: 'punjab',
    label: 'पंजाब (Punjab)',
    scope: 'india',
    portalName: 'Digital Punjab / Sewa Connect',
    domain: 'connect.punjab.gov.in',
    url: 'https://connect.punjab.gov.in/',
    feeHi: '**₹50 से ₹100** (सरकारी व सेवा केंद्र सुविधा शुल्क)।',
    feeEn: '**₹50 to ₹100** government & Sewa Kendra facilitation fee.',
    docsHi: 'आधार कार्ड, वोटर/राशन कार्ड, स्व-घोषणा एवं निवास प्रमाण व पासपोर्ट फोटो।',
    docsEn: 'Aadhaar Card, Voter/Ration Card, Self-declaration & Residence proof.',
    stepsHi: [
      'नीचे दिए हरे बटन से **connect.punjab.gov.in** खोलें और Citizen Login करें।',
      'Residence, Caste या Income Certificate चुनकर दस्तावेज़ अपलोड करें।',
      'ऑनलाइन शुल्क जमा कर e-Sign सर्टिफिकेट डाउनलोड करें।',
    ],
    stepsEn: [
      'Open **connect.punjab.gov.in** and sign in via Citizen Login.',
      'Select Residence, Caste, or Income Certificate and attach proofs.',
      'Pay the applicable fee and download your e-signed certificate.',
    ],
    queryRegex: /\b(punjab|sewa\s*connect|psssb|ppsc|amritsar|ludhiana)\b|पंजाब/i,
    locationRegex: /punjab/i,
  },
  {
    key: 'wb',
    label: 'पश्चिम बंगाल (West Bengal)',
    scope: 'india',
    portalName: 'e-District West Bengal (बांग्लार सहायता केंद्र)',
    domain: 'edistrict.wb.gov.in',
    url: 'https://edistrict.wb.gov.in/',
    feeHi: '**₹0 (निःशुल्क)** — e-District पोर्टल पर ऑनलाइन प्रमाण पत्र आवेदन मुफ्त है।',
    feeEn: '**₹0 (Free)** online certificate applications on e-District West Bengal.',
    docsHi: 'आधार कार्ड, वोटर आईडी (EPIC) / राशन कार्ड, आवासीय/आय स्व-घोषणा पत्र व फोटो।',
    docsEn: 'Aadhaar Card, Voter ID / Ration Card, Residence/Income declaration, Photo.',
    stepsHi: [
      'नीचे दिए हरे बटन से **edistrict.wb.gov.in** खोलें और Citizen Registration से लॉगिन करें।',
      'Income, Domicile या Local Residence प्रमाण पत्र चुनकर दस्तावेज़ अपलोड करें।',
      '₹0 में सबमिट करें और BDO/SDO अनुमोदन के बाद PDF डाउनलोड करें।',
    ],
    stepsEn: [
      'Open **edistrict.wb.gov.in** and sign in with Citizen Registration.',
      'Select Income or Domicile Certificate, attach proofs, and submit for ₹0.',
      'Download your signed certificate once approved by BDO/SDO.',
    ],
    queryRegex: /\b(west\s*bengal|wbpsc|kolkata)\b|पश्चिम\s*बंगाल/i,
    locationRegex: /west bengal/i,
  },
  {
    key: 'tn',
    label: 'तमिलनाडु (Tamil Nadu)',
    scope: 'india',
    portalName: 'TNeGA / e-Sevai Tamil Nadu',
    domain: 'tnesevai.tn.gov.in',
    url: 'https://www.tnesevai.tn.gov.in/',
    feeHi: '**₹60** सामान्य प्रमाण पत्र शुल्क (Community / Nativity / Income Certificate)।',
    feeEn: '**₹60** online fee on e-Sevai Tamil Nadu.',
    docsHi: 'Aadhaar Card, Smart Ration Card, Passport Photo, Address Proof, Self-Declaration।',
    docsEn: 'Aadhaar Card, Smart Ration Card, Passport Photo, Address Proof, Self-Declaration.',
    stepsHi: [
      'नीचे दिए हरे बटन से **tnesevai.tn.gov.in** खोलें और CAN नंबर से लॉगिन करें।',
      'Community, Nativity या Income Certificate चुनकर दस्तावेज़ अपलोड करें।',
      '₹60 शुल्क जमा करें और Tahsildar स्वीकृति के बाद सर्टिफिकेट डाउनलोड करें।',
    ],
    stepsEn: [
      'Open **tnesevai.tn.gov.in**, register your CAN, and log in.',
      'Select Community, Nativity, or Income Certificate and attach proofs.',
      'Pay ₹60 online and download your certificate.',
    ],
    queryRegex: /\b(tamil\s*nadu|tnesevai|tnega|tnpsc|chennai)\b|तमिलनाडु/i,
    locationRegex: /tamil nadu/i,
  },
  {
    key: 'karnataka',
    label: 'कर्नाटक (Karnataka)',
    scope: 'india',
    portalName: 'Seva Sindhu Karnataka (सेवा सिंधु)',
    domain: 'sevasindhu.karnataka.gov.in',
    url: 'https://sevasindhu.karnataka.gov.in/',
    feeHi: '**₹25 से ₹40** (सेवा सिंधु / नाडाकचेरी / ग्राम वन शुल्क)।',
    feeEn: '**₹25 to ₹40** via Seva Sindhu / Nadakacheri / Grama One.',
    docsHi: 'आधार कार्ड, राशन कार्ड / Kutumba ID, पते व आय का स्व-घोषणा पत्र, फोटो।',
    docsEn: 'Aadhaar Card, Ration Card / Kutumba ID, Address & Income Self-Declaration, Photo.',
    stepsHi: [
      'नीचे दिए हरे बटन से **sevasindhu.karnataka.gov.in** खोलें और MeriPehchaan से लॉगिन करें।',
      'Caste, Income या Residence Certificate चुनकर फॉर्म भरें और ₹25–₹40 जमा करें।',
    ],
    stepsEn: [
      'Open **sevasindhu.karnataka.gov.in** and sign in with MeriPehchaan.',
      'Apply for Caste, Income, or Residence Certificate and pay ₹25–₹40.',
    ],
    queryRegex: /\b(karnataka|seva\s*sindhu|nadakacheri|kpsc|bengaluru|bangalore)\b|कर्नाटक|सेवा\s*सिंधु/i,
    locationRegex: /karnataka/i,
  },
  {
    key: 'kerala',
    label: 'केरल (Kerala)',
    scope: 'india',
    portalName: 'e-District Kerala / Akshaya',
    domain: 'edistrict.kerala.gov.in',
    url: 'https://edistrict.kerala.gov.in/',
    feeHi: '**₹15 से ₹35** (e-District Kerala / अक्षय केंद्र शुल्क)।',
    feeEn: '**₹15 to ₹35** on e-District Kerala / Akshaya Centre.',
    docsHi: 'आधार कार्ड, राशन कार्ड, SSLC सर्टिफिकेट, आय/निवास प्रमाण पत्र।',
    docsEn: 'Aadhaar Card, Ration Card, SSLC Certificate, Address & Income proof.',
    stepsHi: [
      'नीचे दिए हरे बटन से **edistrict.kerala.gov.in** खोलें और Citizen Login करें।',
      'Nativity, Community या Income Certificate आवेदन कर ₹15–₹35 जमा करें।',
    ],
    stepsEn: [
      'Open **edistrict.kerala.gov.in**, select Nativity/Community/Income certificate, and pay ₹15–₹35.',
    ],
    queryRegex: /\b(kerala|akshaya|keralapsc|kochi|thiruvananthapuram)\b|केरल/i,
    locationRegex: /kerala/i,
  },
  {
    key: 'telangana',
    label: 'तेलंगाना (Telangana)',
    scope: 'india',
    portalName: 'MeeSeva Telangana Portal',
    domain: 'ts.meeseva.telangana.gov.in',
    url: 'https://ts.meeseva.telangana.gov.in/',
    feeHi: '**₹35 से ₹45** (मीसेवा ऑनलाइन / T App Folio शुल्क)।',
    feeEn: '**₹35 to ₹45** via MeeSeva Telangana / T App Folio.',
    docsHi: 'आधार कार्ड, राशन कार्ड / खाद्य सुरक्षा कार्ड, निवास व शैक्षणिक प्रमाण।',
    docsEn: 'Aadhaar Card, Ration Card, Residence & Educational proofs.',
    stepsHi: [
      'नीचे दिए हरे बटन से **ts.meeseva.telangana.gov.in** खोलें और Caste/Income/Residence चुनें।',
      '₹35–₹45 शुल्क जमा कर Tahsildar स्वीकृति के बाद सर्टिफिकेट डाउनलोड करें।',
    ],
    stepsEn: [
      'Open **ts.meeseva.telangana.gov.in**, apply for Caste/Income/Residence certificate, and pay ₹35–₹45.',
    ],
    queryRegex: /\b(telangana|meeseva\s*telangana|tspsc|tgpsc|hyderabad)\b|तेलंगाना/i,
    locationRegex: /telangana/i,
  },
  {
    key: 'ap',
    label: 'आंध्र प्रदेश (Andhra Pradesh)',
    scope: 'india',
    portalName: 'AP Grama / Ward Sachivalayam & MeeSeva',
    domain: 'vsws.ap.gov.in',
    url: 'https://vsws.ap.gov.in/',
    feeHi: '**₹35 से ₹45** (ग्राम/वार्ड सचिवालय व मीसेवा शुल्क)।',
    feeEn: '**₹35 to ₹45** via AP Grama/Ward Sachivalayam or MeeSeva.',
    docsHi: 'आधार कार्ड, राइस/राशन कार्ड, पते व आय का प्रमाण, फोटो।',
    docsEn: 'Aadhaar Card, Rice/Ration Card, Address & Income proof.',
    stepsHi: [
      'नीचे दिए हरे बटन से **vsws.ap.gov.in** (या ग्राम/वार्ड सचिवालय) पर प्रमाण पत्र आवेदन कर ₹35–₹45 जमा करें।',
    ],
    stepsEn: [
      'Visit **vsws.ap.gov.in** or your nearest Sachivalayam to apply and pay ₹35–₹45.',
    ],
    queryRegex: /\b(andhra\s*pradesh|appsc|sachivalayam|vsws|amaravati|vijayawada)\b|आंध्र\s*प्रदेश/i,
    locationRegex: /andhra pradesh/i,
  },
  {
    key: 'odisha',
    label: 'ओडिशा (Odisha)',
    scope: 'india',
    portalName: 'e-District Odisha (ओडिशा ई-डिस्ट्रिक्ट)',
    domain: 'edistrict.odisha.gov.in',
    url: 'https://edistrict.odisha.gov.in/',
    feeHi: '**₹30** (Mo Seba Kendra / e-District प्रमाण पत्र शुल्क)।',
    feeEn: '**₹30** on e-District Odisha / Mo Seba Kendra.',
    docsHi: 'आधार कार्ड, ROR (जमीन का पट्टा), राशन कार्ड व स्व-घोषणा पत्र।',
    docsEn: 'Aadhaar Card, Land ROR, Ration Card, Self-Declaration.',
    stepsHi: [
      'नीचे दिए हरे बटन से **edistrict.odisha.gov.in** खोलें, Resident/Caste/Income चुनें और ₹30 शुल्क जमा करें।',
    ],
    stepsEn: [
      'Open **edistrict.odisha.gov.in**, select Resident/Caste/Income certificate, and pay ₹30.',
    ],
    queryRegex: /\b(odisha|orissa|opsc|mo\s*seba|bhubaneswar)\b|ओडिशा/i,
    locationRegex: /odisha/i,
  },
  {
    key: 'jharkhand',
    label: 'झारखंड (Jharkhand)',
    scope: 'india',
    portalName: 'JharSewa Jharkhand (झारसेवा / प्रज्ञा केंद्र)',
    domain: 'jharsewa.jharkhand.gov.in',
    url: 'https://jharsewa.jharkhand.gov.in/',
    feeHi: '**₹0** (स्वयं ऑनलाइन) से **₹30–₹50** (प्रज्ञा केंद्र / CSC शुल्क)।',
    feeEn: '**₹0** (self-apply) to **₹30–₹50** (Pragya Kendra / CSC).',
    docsHi: 'आधार कार्ड, खतियान / वंशावली / स्थानीय निवास प्रमाण, स्व-घोषणा पत्र व फोटो।',
    docsEn: 'Aadhaar Card, Khatiyan / Local Residence proof, Self-declaration.',
    stepsHi: [
      'नीचे दिए हरे बटन से **jharsewa.jharkhand.gov.in** खोलें, Local Resident/Caste/Income फॉर्म भरें और सर्टिफिकेट डाउनलोड करें।',
    ],
    stepsEn: [
      'Open **jharsewa.jharkhand.gov.in**, apply for Local Resident/Caste/Income certificate, and download your signed PDF.',
    ],
    queryRegex: /\b(jharkhand|jharsewa|jssc|jpsc|pragya\s*kendra|ranchi)\b|झारखंड|झारसेवा/i,
    locationRegex: /jharkhand/i,
  },
  {
    key: 'uttarakhand',
    label: 'उत्तराखंड (Uttarakhand)',
    scope: 'india',
    portalName: 'Apuni Sarkar Uttarakhand (अपनी सरकार)',
    domain: 'eservices.uk.gov.in',
    url: 'https://eservices.uk.gov.in/',
    feeHi: '**₹30** (अपनी सरकार ऑनलाइन / CSC पोर्टल शुल्क)।',
    feeEn: '**₹30** on Apuni Sarkar Uttarakhand.',
    docsHi: 'आधार कार्ड, परिवार रजिस्टर की नकल / राशन कार्ड, 15 वर्ष निवास या भूमि प्रमाण, फोटो।',
    docsEn: 'Aadhaar Card, Pariwar Register / Ration Card, Residence proof.',
    stepsHi: [
      'नीचे दिए हरे बटन से **eservices.uk.gov.in** खोलें और स्थायी निवास, जाति या पर्वतीय प्रमाण पत्र आवेदन करें।',
    ],
    stepsEn: [
      'Open **eservices.uk.gov.in**, apply for Permanent Resident, Caste, or Hill certificate, and pay ₹30.',
    ],
    queryRegex: /\b(uttarakhand|apuni\s*sarkar|ukpsc|uksssc|dehradun)\b|उत्तराखंड|अपनी\s*सरकार/i,
    locationRegex: /uttarakhand/i,
  },
  {
    key: 'hp',
    label: 'हिमाचल प्रदेश (Himachal Pradesh)',
    scope: 'india',
    portalName: 'e-District Himachal Pradesh',
    domain: 'edistrict.hp.gov.in',
    url: 'https://edistrict.hp.gov.in/',
    feeHi: '**₹20 से ₹35** (लोकमित्र केंद्र / e-District शुल्क)।',
    feeEn: '**₹20 to ₹35** on e-District HP / Lokmitra Kendra.',
    docsHi: 'आधार कार्ड, परिवार रजिस्टर नकल, राशन कार्ड, पटवारी रिपोर्ट व फोटो।',
    docsEn: 'Aadhaar Card, Parivar Register, Ration Card, Patwari report.',
    stepsHi: [
      'नीचे दिए हरे बटन से **edistrict.hp.gov.in** खोलें और Bonafide Himachali, Caste या Income Certificate आवेदन करें।',
    ],
    stepsEn: [
      'Open **edistrict.hp.gov.in**, select Bonafide Himachali, Caste, or Income certificate, and pay ₹20–₹35.',
    ],
    queryRegex: /\b(himachal|himachal\s*pradesh|bonafide\s*himachali|hppsc|shimla)\b|हिमाचल/i,
    locationRegex: /himachal/i,
  },
  {
    key: 'assam',
    label: 'असम (Assam)',
    scope: 'india',
    portalName: 'Sewa Setu Assam (सेवा सेतु)',
    domain: 'sewasetu.assam.gov.in',
    url: 'https://sewasetu.assam.gov.in/',
    feeHi: '**₹30 से ₹50** (Sewa Setu / RTPS असम ऑनलाइन सेवा शुल्क)।',
    feeEn: '**₹30 to ₹50** on Sewa Setu Assam.',
    docsHi: 'आधार / वोटर आईडी, भूमि रिकॉर्ड या निवास प्रमाण, स्व-घोषणा पत्र व फोटो।',
    docsEn: 'Aadhaar / Voter ID, Residence or Land proof, Self-declaration.',
    stepsHi: [
      'नीचे दिए हरे बटन से **sewasetu.assam.gov.in** खोलें और PRC, Caste या Income Certificate आवेदन करें।',
    ],
    stepsEn: [
      'Open **sewasetu.assam.gov.in**, apply for PRC, Caste, or Income certificate, and pay ₹30–₹50.',
    ],
    queryRegex: /\b(assam|sewa\s*setu|sewasetu|apsc|guwahati)\b|असम/i,
    locationRegex: /assam/i,
  },
  {
    key: 'jk',
    label: 'जम्मू-कश्मीर (Jammu & Kashmir)',
    scope: 'india',
    portalName: 'e-UNNAT / JanSugam J&K (ServicePlus)',
    domain: 'serviceonline.gov.in',
    url: 'https://serviceonline.gov.in/',
    feeHi: '**₹0 से ₹30** (e-UNNAT / ServicePlus पोर्टल शुल्क)।',
    feeEn: '**₹0 to ₹30** on e-UNNAT / JanSugam J&K.',
    docsHi: 'आधार कार्ड, राशन कार्ड, PRC / 15-वर्ष निवास प्रमाण व फोटो।',
    docsEn: 'Aadhaar Card, Ration Card, PRC / 15-Year Residence proof.',
    stepsHi: [
      'नीचे दिए हरे बटन से **serviceonline.gov.in** (JanSugam J&K) खोलें और Domicile / Category प्रमाण पत्र आवेदन करें।',
    ],
    stepsEn: [
      'Open **serviceonline.gov.in** (JanSugam J&K) and apply for Domicile or Category certificate.',
    ],
    queryRegex: /\b(jammu|kashmir|j&k|e-?unnat|jansugam|jkssb|jkpsc|srinagar)\b|जम्मू|कश्मीर/i,
    locationRegex: /jammu/i,
  },
  {
    key: 'other_india',
    label: 'गोवा, पूर्वोत्तर व केंद्र शासित प्रदेश (Goa / NE / UTs)',
    scope: 'india',
    portalName: 'ServicePlus National Citizen Portal',
    domain: 'serviceonline.gov.in',
    url: 'https://serviceonline.gov.in/',
    feeHi: '**₹0 से ₹50** (संबंधित राज्य/UT के ServicePlus या CSC पोर्टल के अनुसार)।',
    feeEn: '**₹0 to ₹50** as per your State/UT ServicePlus or e-District portal.',
    docsHi: 'आधार कार्ड, निवास/राशन कार्ड, स्व-घोषणा पत्र व पासपोर्ट साइज फोटो।',
    docsEn: 'Aadhaar Card, Residence/Ration Card, Self-declaration, Photo.',
    stepsHi: [
      'नीचे दिए हरे बटन से **serviceonline.gov.in** खोलें, अपना राज्य/UT चुनें और MeriPehchaan से लॉगिन कर प्रमाण पत्र आवेदन करें।',
    ],
    stepsEn: [
      'Open **serviceonline.gov.in**, select your State/UT, log in via MeriPehchaan, and submit your application.',
    ],
    queryRegex: /\b(goa|chandigarh|puducherry|ladakh|sikkim|tripura|manipur|meghalaya|nagaland|mizoram|arunachal)\b|गोवा|चंडीगढ़|लद्दाख/i,
    locationRegex: /goa|other states|union territor/i,
  },
  {
    key: 'all_india',
    label: 'All India (Central Govt Citizen Services)',
    scope: 'india',
    portalName: 'National Government Services Portal (भारत सरकार)',
    domain: 'services.india.gov.in',
    url: 'https://services.india.gov.in/',
    feeHi: 'राज्य व सेवा के अनुसार **₹0 से ₹50** (संबंधित राज्य e-District / ServicePlus पोर्टल पर)।',
    feeEn: '**₹0 to ₹50** depending on your state e-District / ServicePlus portal.',
    docsHi: 'आधार कार्ड (मोबाइल लिंक), राशन/परिवार कार्ड, पते व आय का प्रमाण, फोटो व स्व-घोषणा पत्र।',
    docsEn: 'Aadhaar Card, Ration/Family ID, Address & Income proof, Photo, Self-declaration.',
    stepsHi: [
      'नीचे दिए हरे बटन से **services.india.gov.in** खोलें और अपना राज्य (जैसे UP, MP, Bihar, Rajasthan, Maharashtra, Delhi) व आवश्यक सेवा चुनें।',
      'यह आपको सीधे आपके राज्य के आधिकारिक e-District / ServicePlus पोर्टल पर ले जाएगा जहाँ से आप ऑनलाइन आवेदन व PDF डाउनलोड कर सकते हैं।',
    ],
    stepsEn: [
      'Open **services.india.gov.in**, choose your State and citizen service, and proceed to your state e-District portal.',
    ],
    queryRegex: /\b(all\s*india|central\s*govt|services\.india\.gov\.in)\b|पूरे\s*भारत|ऑल\s*इंडिया/i,
    locationRegex: /all india/i,
  },
  {
    key: 'usa',
    label: 'United States (USA)',
    scope: 'global',
    portalName: 'USA.gov & USCIS (United States Official Portals)',
    domain: 'usa.gov',
    url: 'https://www.usa.gov/',
    feeHi: 'Social Security (SSA) सेवाएँ **$0** | अमेरिकी पासपोर्ट **$130–$165** | USCIS वीज़ा / ग्रीन कार्ड आवेदन **$185–$1,440 (USD)**।',
    feeEn: 'Social Security (SSA) **$0** | U.S. Passport **$130–$165** | USCIS Visa / Immigration filings **$185–$1,440 (USD)**.',
    docsHi: 'वैध पासपोर्ट, Social Security Number (SSN) या A-Number, I-94 / वीज़ा रिकॉर्ड, अमेरिकी पते का प्रमाण व Login.gov अकाउंट।',
    docsEn: 'Valid Passport / Photo ID, SSN or A-Number, I-94 / Visa record, Proof of U.S. Address, Login.gov account.',
    stepsHi: [
      'नीचे दिए हरे बटन से **usa.gov** (या वीज़ा व इमिग्रेशन के लिए **uscis.gov**) खोलें।',
      '**Login.gov** / USCIS अकाउंट से साइन-इन कर आवश्यक सेवा (Social Security, IRS Tax, Passport या Visa Form) चुनें।',
      'फॉर्म व दस्तावेज़ अपलोड करें, निर्धारित USD शुल्क जमा करें और केस नंबर ट्रैक करें।',
    ],
    stepsEn: [
      'Open **usa.gov** (or **uscis.gov** for immigration & visas) via the button below.',
      'Sign in with **Login.gov** or USCIS Online Account and choose your federal service.',
      'Complete the application, upload proofs, pay the USD fee, and track your receipt number.',
    ],
    queryRegex: /\b(usa|u\.s\.a\.|united\s*states|america|uscis|usa\.gov|social\s*security|h-?1b|green\s*card)\b|अमेरिका/i,
    locationRegex: /united states|usa/i,
  },
  {
    key: 'uk',
    label: 'United Kingdom (UK)',
    scope: 'global',
    portalName: 'GOV.UK (UK National Citizen Portal)',
    domain: 'gov.uk',
    url: 'https://www.gov.uk/',
    feeHi: 'UK पासपोर्ट **£88.50** (ऑनलाइन) | DVLA ड्राइविंग लाइसेंस **£34** | UK वीज़ा आवेदन **£115 से £1,500+ (GBP)**।',
    feeEn: 'UK Passport **£88.50** online | DVLA Driving Licence **£34** | UK Visas **£115–£1,500+ (GBP)**.',
    docsHi: 'पासपोर्ट / eVisa Share Code, National Insurance Number (NINO), UK पते का प्रमाण व GOV.UK One Login।',
    docsEn: 'Passport / eVisa Share Code, National Insurance Number (NINO), UK Address Proof, GOV.UK One Login.',
    stepsHi: [
      'नीचे दिए हरे बटन से **gov.uk** खोलें और **GOV.UK One Login** से साइन-इन करें।',
      'Visas & Immigration, Passports, DVLA Driving या HMRC Tax सेवा चुनकर फॉर्म भरें।',
      'पहचान सत्यापन पूरा करें, GBP शुल्क ऑनलाइन जमा करें और डिजिटल स्टेटस प्राप्त करें।',
    ],
    stepsEn: [
      'Open **gov.uk** via the button below and sign in using **GOV.UK One Login**.',
      'Choose Visas, Passports, DVLA Driving, or HMRC Tax services.',
      'Complete identity verification, pay the GBP fee online, and track your application.',
    ],
    queryRegex: /\b(uk|u\.k\.|united\s*kingdom|britain|england|gov\.uk|dvla|hmrc|nhs)\b|ब्रिटेन|इंग्लैंड/i,
    locationRegex: /united kingdom|\buk\b/i,
  },
  {
    key: 'uae',
    label: 'United Arab Emirates (UAE)',
    scope: 'global',
    portalName: 'UAE Pass & ICP Smart Services (u.ae / icp.gov.ae)',
    domain: 'u.ae',
    url: 'https://u.ae/',
    feeHi: 'Emirates ID **AED 170–370+** | रेजिडेंस / गोल्डन वीज़ा **AED 2,800–3,800+** | सरकारी अटेस्टेशन **AED 50–150**।',
    feeEn: 'Emirates ID **AED 170–370+** | Residence / Golden Visa **AED 2,800–3,800+** | Govt Attestations **AED 50–150 (AED)**.',
    docsHi: 'UAE PASS अकाउंट, Emirates ID, वैध पासपोर्ट (6+ माह), रेजिडेंस वीज़ा / एंट्री परमिट व मेडिकल फिटनेस।',
    docsEn: 'UAE PASS account, Emirates ID, Valid Passport (6+ months), Residence Visa / Entry Permit, Photo.',
    stepsHi: [
      'नीचे दिए हरे बटन से **u.ae** (या सीधे **smartservices.icp.gov.ae**) खोलें और **UAE PASS** से लॉगिन करें।',
      'Emirates ID, Visa Renewal, Golden Visa या MOHRE सेवा चुनें और दस्तावेज़ अपलोड करें।',
      'निर्धारित AED शुल्क ऑनलाइन जमा करें और UAE Pass वॉलेट में डिजिटल Emirates ID / e-Visa प्राप्त करें।',
    ],
    stepsEn: [
      'Open **u.ae** (or **smartservices.icp.gov.ae**) and sign in using **UAE PASS**.',
      'Select Emirates ID, Visa Renewal, Golden Visa, or MOHRE e-services.',
      'Upload documents, pay the AED fee, and receive your digital Emirates ID / e-Visa.',
    ],
    queryRegex: /\b(uae|united\s*arab\s*emirates|dubai|abu\s*dhabi|emirates\s*id|uae\s*pass|icp|mohre|golden\s*visa)\b|दुबई|यूएई/i,
    locationRegex: /emirates|uae/i,
  },
  {
    key: 'saudi',
    label: 'Saudi Arabia (KSA)',
    scope: 'global',
    portalName: 'Absher & MY.GOV.SA (Saudi Digital Citizen Portal)',
    domain: 'absher.sa',
    url: 'https://www.absher.sa/',
    feeHi: 'इकामा (Iqama) नवीनीकरण **SAR 500–650/वर्ष** | Exit/Re-Entry वीज़ा **SAR 200+** | सऊदी पासपोर्ट **SAR 300–600 (SAR)**।',
    feeEn: 'Iqama Renewal **SAR 500–650/yr** | Exit/Re-Entry Visa **SAR 200+** | Passports **SAR 300–600 (SAR)**.',
    docsHi: 'Absher व Nafath (نفاذ) लॉगिन, वैध Iqama / National ID, पासपोर्ट विवरण व SADAD भुगतान नंबर।',
    docsEn: 'Absher & Nafath Digital ID, Valid Iqama / National ID, Passport details, SADAD payment.',
    stepsHi: [
      'नीचे दिए हरे बटन से **absher.sa** (या **my.gov.sa**) खोलें और **Absher Individuals / Nafath** से लॉगिन करें।',
      'Jawazat (Iqama/Visa/Passports), Ahwal (Civil Affairs) या Traffic सेवा चुनें।',
      'SADAD से संबंधित SAR शुल्क जमा कर तुरंत डिजिटल कन्फर्मेशन प्राप्त करें।',
    ],
    stepsEn: [
      'Open **absher.sa** (or **my.gov.sa**) and sign in using **Absher / Nafath**.',
      'Choose Jawazat (Passports/Iqama), Ahwal (Civil Affairs), or Traffic e-services.',
      'Pay the applicable SAR fee via SADAD and receive instant digital confirmation.',
    ],
    queryRegex: /\b(saudi|saudi\s*arabia|ksa|absher|iqama|nafath|jawazat|riyadh)\b|सऊदी/i,
    locationRegex: /saudi/i,
  },
  {
    key: 'canada',
    label: 'Canada',
    scope: 'global',
    portalName: 'Canada.ca — Service Canada & IRCC',
    domain: 'canada.ca',
    url: 'https://www.canada.ca/en/services.html',
    feeHi: 'SIN आवेदन **$0** | Study Permit **CAD $150** | Work Permit **CAD $155** | Express Entry PR **CAD $1,525**।',
    feeEn: 'SIN Application **$0** | Study Permit **CAD $150** | Work Permit **CAD $155** | Express Entry PR **CAD $1,525 (CAD)**.',
    docsHi: 'वैध पासपोर्ट, GCKey या Sign-In Partner लॉगिन, बायोमेट्रिक्स (CAD $85) व पते/रोजगार के प्रमाण।',
    docsEn: 'Valid Passport, GCKey / Sign-In Partner, Biometrics, Supporting Immigration/SIN proofs.',
    stepsHi: [
      'नीचे दिए हरे बटन से **canada.ca** खोलें और **GCKey** या My Service Canada Account से लॉगिन करें।',
      'IRCC (Visa/PR), Service Canada (SIN/Benefits) या CRA सेवा चुनकर दस्तावेज़ अपलोड करें व CAD शुल्क जमा करें।',
    ],
    stepsEn: [
      'Open **canada.ca**, sign in via **GCKey**, select IRCC / Service Canada service, upload documents, and pay CAD fees online.',
    ],
    queryRegex: /\b(canada|ircc|express\s*entry|gckey|service\s*canada)\b|कनाडा/i,
    locationRegex: /canada/i,
  },
  {
    key: 'australia',
    label: 'Australia',
    scope: 'global',
    portalName: 'myGov Australia & Home Affairs (my.gov.au)',
    domain: 'my.gov.au',
    url: 'https://my.gov.au/',
    feeHi: 'myGov / Medicare / ATO टैक्स सेवाएँ **AUD $0** | Visitor Visa **AUD $195** | Student Visa **AUD $1,600 (AUD)**।',
    feeEn: 'myGov / Medicare / ATO **$0** | Visitor Visa **AUD $195** | Student Visa **AUD $1,600 (AUD)**.',
    docsHi: 'myGov अकाउंट / Digital ID, वैध पासपोर्ट, Tax File Number (TFN), Medicare / ImmiAccount विवरण।',
    docsEn: 'myGov Account / myID, Valid Passport, Tax File Number (TFN), Medicare / ImmiAccount details.',
    stepsHi: [
      'नीचे दिए हरे बटन से **my.gov.au** (या वीज़ा हेतु **immi.homeaffairs.gov.au**) खोलें, आवश्यक सेवा लिंक करें और आवेदन सबमिट करें।',
    ],
    stepsEn: [
      'Open **my.gov.au** (or **immi.homeaffairs.gov.au** for visas), access linked services, and submit online.',
    ],
    queryRegex: /\b(australia|mygov|my\.gov\.au|immiaccount|medicare|centrelink)\b|ऑस्ट्रेलिया/i,
    locationRegex: /australia/i,
  },
  {
    key: 'singapore',
    label: 'Singapore',
    scope: 'global',
    portalName: 'Singpass & Gov.sg (Singapore Citizen Portal)',
    domain: 'singpass.gov.sg',
    url: 'https://www.singpass.gov.sg/',
    feeHi: 'ICA NRIC/प्रमाण पत्र **SGD $10–$60** | Employment Pass आवेदन **SGD $105** + जारी शुल्क **SGD $225 (SGD)**।',
    feeEn: 'ICA NRIC/Cert services **SGD $10–$60** | MOM Employment Pass **SGD $105–$225 (SGD)**.',
    docsHi: 'Singpass ऐप (Myinfo डिजिटल प्रोफाइल), NRIC / FIN नंबर व वैध पासपोर्ट।',
    docsEn: 'Singpass App (Myinfo), NRIC or FIN, Valid Passport.',
    stepsHi: [
      'नीचे दिए हरे बटन से **singpass.gov.sg** खोलें, Singpass QR से लॉगिन करें और Myinfo के साथ ICA/MOM/IRAS सेवा आवेदन करें।',
    ],
    stepsEn: [
      'Open **singpass.gov.sg**, sign in via Singpass QR, and submit ICA/MOM/IRAS forms with Myinfo.',
    ],
    queryRegex: /\b(singapore|singpass|gov\.sg|myinfo|mom\s*pass)\b|सिंगापुर/i,
    locationRegex: /singapore/i,
  },
  {
    key: 'germany',
    label: 'Germany (Deutschland)',
    scope: 'global',
    portalName: 'BundID & Make it in Germany (id.bund.de)',
    domain: 'id.bund.de',
    url: 'https://id.bund.de/',
    feeHi: 'Personalausweis **€37** | रेजिडेंस परमिट / Chancenkarte / EU Blue Card **€75–€110** | डिजिटल सेवाएँ **€0–€15 (EUR)**।',
    feeEn: 'Personalausweis **€37** | Residence Permit / Chancenkarte / EU Blue Card **€75–€110** | Digital services **€0–€15 (EUR)**.',
    docsHi: 'BundID अकाउंट / eID, वैध पासपोर्ट, Anmeldebestätigung (पता पंजीकरण), बायोमेट्रिक फोटो व स्वास्थ्य बीमा।',
    docsEn: 'BundID / eID card, Valid Passport, Address Registration (Meldebescheinigung), Health Insurance.',
    stepsHi: [
      'नीचे दिए हरे बटन से **id.bund.de** (या वीज़ा/नौकरी हेतु **make-it-in-germany.com**) खोलें और BundID से लॉगिन कर आवेदन करें।',
    ],
    stepsEn: [
      'Open **id.bund.de** (or **make-it-in-germany.com**), sign in with BundID, and submit your federal/municipal form.',
    ],
    queryRegex: /\b(germany|deutschland|bundid|id\.bund|chancenkarte|blue\s*card|bürgeramt)\b|जर्मनी/i,
    locationRegex: /germany/i,
  },
  {
    key: 'france',
    label: 'France',
    scope: 'global',
    portalName: 'Service-Public.fr & FranceConnect',
    domain: 'service-public.fr',
    url: 'https://www.service-public.fr/',
    feeHi: 'नागरिक प्रमाण पत्र **€0 (फ्री)** | Schengen वीज़ा **€90** | Long-Stay वीज़ा **€99 (EUR)**।',
    feeEn: 'Civil status certificates **€0** | Schengen Visa **€90** | Long-Stay Visa **€99 (EUR)**.',
    docsHi: 'FranceConnect लॉगिन, वैध पासपोर्ट / National ID, Justificatif de domicile (पता प्रमाण)।',
    docsEn: 'FranceConnect ID, Valid Passport, Proof of address.',
    stepsHi: [
      'नीचे दिए हरे बटन से **service-public.fr** खोलें और **FranceConnect** से लॉगिन कर ऑनलाइन आवेदन करें।',
    ],
    stepsEn: [
      'Open **service-public.fr**, sign in with **FranceConnect**, and submit your civil or visa application.',
    ],
    queryRegex: /\b(france|service-public|franceconnect|france-visas|paris)\b|फ्रांस/i,
    locationRegex: /france/i,
  },
  {
    key: 'japan',
    label: 'Japan',
    scope: 'global',
    portalName: 'JapanGov & My Number Portal (japan.go.jp)',
    domain: 'japan.go.jp',
    url: 'https://www.japan.go.jp/',
    feeHi: 'Juminhyo प्रमाण पत्र **¥200–¥300** | वीज़ा एक्सटेंशन / स्टेटस परिवर्तन **¥4,000–¥6,000 (JPY)**।',
    feeEn: 'Juminhyo Certificate **¥200–¥300** | Visa Extension/Change **¥4,000–¥6,000 (JPY)**.',
    docsHi: 'My Number Card, Residence Card (Zairyu Card) व वैध पासपोर्ट।',
    docsEn: 'My Number Card, Residence Card (Zairyu Card), Valid Passport.',
    stepsHi: [
      'नीचे दिए हरे बटन से **japan.go.jp** (या **myna.go.jp**) खोलें और My Number Card से सत्यापित कर आवेदन करें।',
    ],
    stepsEn: [
      'Open **japan.go.jp** (or **myna.go.jp**), authenticate with your My Number Card, and submit your request.',
    ],
    queryRegex: /\b(japan|mext|myna\.go\.jp|my\s*number|tokyo|juminhyo)\b|जापान/i,
    locationRegex: /japan/i,
  },
  {
    key: 'nz',
    label: 'New Zealand',
    scope: 'global',
    portalName: 'Govt.nz & RealMe (New Zealand Official Portal)',
    domain: 'govt.nz',
    url: 'https://www.govt.nz/',
    feeHi: 'नागरिक प्रमाण पत्र **NZD $33** | Student Visa **NZD $750** | Work Visa **NZD $1,540 (NZD)**।',
    feeEn: 'Certificates **NZD $33** | Student Visa **NZD $750** | Work Visa **NZD $1,540 (NZD)**.',
    docsHi: 'RealMe वेरिफाइड अकाउंट, वैध पासपोर्ट, IRD नंबर व पते का प्रमाण।',
    docsEn: 'RealMe verified account, Valid Passport, IRD Number, Address proof.',
    stepsHi: [
      'नीचे दिए हरे बटन से **govt.nz** (या **immigration.govt.nz**) खोलें और **RealMe** से लॉगिन कर आवेदन करें।',
    ],
    stepsEn: [
      'Open **govt.nz** (or **immigration.govt.nz**), sign in with **RealMe**, and submit your online application.',
    ],
    queryRegex: /\b(new\s*zealand|realme|govt\.nz|auckland)\b|न्यूजीलैंड/i,
    locationRegex: /new zealand/i,
  },
];

function isGlobalUnspecifiedLocation(location: string): boolean {
  const lower = (location || '').trim().toLowerCase();
  if (!lower) return true;
  return lower.includes('global') || lower.includes('all countries') || lower === 'world';
}

function resolveCitizenPortalForQuery(
  query: string,
  location: string
): { meta: CitizenRegionMeta | null; isAmbiguousGlobal: boolean; matchedFromQuery: boolean } {
  const cleanQuery = (query || '').trim();
  for (const meta of CITIZEN_REGION_REGISTRY) {
    if (meta.queryRegex.test(cleanQuery)) {
      return { meta, isAmbiguousGlobal: false, matchedFromQuery: true };
    }
  }

  if (isGlobalUnspecifiedLocation(location)) {
    return { meta: null, isAmbiguousGlobal: true, matchedFromQuery: false };
  }

  const locLower = (location || '').toLowerCase();
  for (const meta of CITIZEN_REGION_REGISTRY) {
    if (meta.locationRegex.test(locLower)) {
      return { meta, isAmbiguousGlobal: false, matchedFromQuery: false };
    }
  }

  if (locLower.includes('india')) {
    const allIndia = CITIZEN_REGION_REGISTRY.find((m) => m.key === 'all_india') || null;
    return { meta: allIndia, isAmbiguousGlobal: false, matchedFromQuery: false };
  }

  return { meta: null, isAmbiguousGlobal: true, matchedFromQuery: false };
}

function isCitizenServiceQuery(prompt: string): boolean {
  const lower = prompt.toLowerCase();
  return /ई-मित्र|emitra|e-mitra|e-district|जन आधार|jan aadhaar|मूल निवास|निवास प्रमाण|आवासीय प्रमाण|जाति प्रमाण|आय प्रमाण|domicile|caste certificate|income certificate|residence certificate|नागरिक सेवा|citizen service|digital citizen|citizen portal|जनसेवा|लोक सेवा|आपले सरकार|aaple sarkar|सरल हरियाणा|saral|rtps|सेवा सिंधु|seva sindhu|झारसेवा|jharsewa|सेवा सेतु|अपनी सरकार|emirates id|uae pass|icp|golden visa|absher|iqama|singpass|bundid|mygov|my\.gov\.au|gov\.uk|usa\.gov|uscis|social security|service-public|realme|ircc|express entry|service canada|chancenkarte|blue card|\bsin\b|e-governance|प्रमाण पत्र/i.test(
    lower
  );
}

function escapeRegex(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function matchesKeyword(text: string, kw: string): boolean {
  const cleanKw = kw.trim();
  if (!cleanKw) return false;
  if (/^[a-z0-9\s.-]+$/i.test(cleanKw)) {
    const regex = new RegExp(`(?:^|[^a-z0-9])${escapeRegex(cleanKw)}(?:[^a-z0-9]|$)`, 'i');
    return regex.test(text);
  }
  return text.toLowerCase().includes(cleanKw.toLowerCase());
}

function findOfficialPortals(query: string, location: string = ''): OfficialPortalInfo[] {
  if (isMedicineOrHealthQuery(query)) {
    return [];
  }
  const isPan = /\bpan\b|pancard|pan\s*card|पैन|e-?pan/i.test(query);
  const isDriving = /driving licen|parivahan|sarathi|ड्राइविंग लाइसेंस/i.test(query);

  // If this is a citizen / e-Mitra / e-District / Global citizen portal query (and not PAN/Driving/etc.),
  // resolve the exact state or country portal dynamically without Rajasthan bias.
  if (!isPan && !isDriving && isCitizenServiceQuery(query)) {
    const resolved = resolveCitizenPortalForQuery(query, location);
    if (resolved.meta) {
      return [
        {
          name: resolved.meta.portalName,
          url: resolved.meta.url,
          domain: resolved.meta.domain,
          category: resolved.meta.scope === 'india' ? 'Citizen & e-District' : 'Global Citizen Portal',
          description: resolved.meta.feeHi,
        },
      ];
    }
    if (resolved.isAmbiguousGlobal) {
      return [
        {
          name: 'National Government Services Portal (India)',
          url: 'https://services.india.gov.in/',
          domain: 'services.india.gov.in',
          category: 'All India Citizen Hub',
          description: 'भारत के सभी राज्यों व केंद्रीय सरकारी सेवाओं का एकीकृत राष्ट्रीय पोर्टल।',
        },
      ];
    }
  }

  const queryMatches: Array<{ portal: OfficialPortalInfo; score: number }> = [];

  for (const p of OFFICIAL_PORTALS) {
    let queryScore = 0;
    let locationScore = 0;
    for (const kw of p.keywords) {
      if (matchesKeyword(query, kw)) {
        queryScore += kw.trim().length > 3 ? 12 : 9;
      } else if (location && matchesKeyword(location, kw)) {
        locationScore += 2;
      }
    }
    if (queryScore > 0) {
      queryMatches.push({
        portal: {
          name: p.name,
          url: p.url,
          domain: p.domain,
          category: p.category,
          description: p.description,
        },
        score: queryScore + locationScore,
      });
    }
  }

  if (queryMatches.length > 0) {
    queryMatches.sort((a, b) => b.score - a.score);
    return queryMatches.slice(0, 2).map((s) => s.portal);
  }

  // Only fall back to location citizen portal if the query explicitly asks generically about visas/jobs/govt services for the active location
  if (!isDriving && /सरकारी|govt|government|visa|वीज़ा|portal|पोर्टल|form|फॉर्म/i.test(query)) {
    const resolved = resolveCitizenPortalForQuery(query, location);
    if (resolved.meta) {
      return [
        {
          name: resolved.meta.portalName,
          url: resolved.meta.url,
          domain: resolved.meta.domain,
          category: resolved.meta.scope === 'india' ? 'State Portal' : 'Global Citizen Portal',
          description: resolved.meta.feeHi,
        },
      ];
    }
  }

  return [];
}

function decodeHtmlEntities(str: string): string {
  return str
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&#x27;|&apos;/g, "'")
    .replace(/&nbsp;/g, ' ')
    .replace(/&#(\d+);/g, (_, num) => String.fromCharCode(Number(num)))
    .replace(/&#x([0-9a-fA-F]+);/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)))
    .replace(/\s+/g, ' ')
    .trim();
}

function parseUrlMeta(urlStr: string): { domain: string; breadcrumb: string; isOfficial: boolean } {
  try {
    const u = new URL(urlStr);
    const domain = u.hostname.replace(/^www\./, '');
    const pathParts = u.pathname
      .split('/')
      .filter(Boolean)
      .slice(0, 3)
      .map((part) => decodeURIComponent(part).slice(0, 28));
    const breadcrumb = pathParts.length > 0 ? `${domain} › ${pathParts.join(' › ')}` : domain;
    const isOfficial = /\.(gov\.in|nic\.in|gov|ac\.in|edu\.in)$/i.test(u.hostname);
    return { domain, breadcrumb, isOfficial };
  } catch {
    return { domain: urlStr, breadcrumb: urlStr, isOfficial: false };
  }
}

async function resolveDirectUrl(uri: string): Promise<string> {
  if (!uri.includes('vertexaisearch.cloud.google.com/grounding-api-redirect')) {
    return uri;
  }
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 1800);
  try {
    const res = await fetch(uri, {
      method: 'HEAD',
      redirect: 'follow',
      signal: controller.signal,
    });
    if (res.url && !res.url.includes('vertexaisearch.cloud.google.com')) {
      return res.url;
    }
  } catch {
    // Keep original URI if resolution fails or times out
  } finally {
    clearTimeout(timeout);
  }
  return uri;
}

async function fetchDirectWebSearchResults(query: string): Promise<LiveWebResult[]> {
  const searchUrl = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 5000);

  try {
    const res = await fetch(searchUrl, {
      signal: controller.signal,
      headers: {
        'User-Agent':
          'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        Accept: 'text/html,application/xhtml+xml',
      },
    });
    if (!res.ok) return [];
    const html = await res.text();

    const blocks = html.split(/class="result\s+results_links/).slice(1, 14);
    const items: LiveWebResult[] = [];
    const seenUrls = new Set<string>();

    for (const block of blocks) {
      if (items.length >= 8) break;
      const aMatch = block.match(/class="result__a"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/);
      const snippetMatch = block.match(/class="result__snippet"[^>]*>([\s\S]*?)<\/(?:a|div|span)>/);
      if (!aMatch) continue;

      let rawHref = decodeHtmlEntities(aMatch[1]);
      if (rawHref.startsWith('//')) {
        rawHref = `https:${rawHref}`;
      }
      const uddgMatch = rawHref.match(/[?&]uddg=([^&]+)/);
      if (uddgMatch) {
        try {
          rawHref = decodeURIComponent(uddgMatch[1]);
        } catch {
          // keep rawHref
        }
      }

      // Skip DuckDuckGo ad / internal redirect links
      if (!/^https?:\/\//i.test(rawHref) || rawHref.includes('duckduckgo.com/y.js')) {
        continue;
      }

      const normalizedUrl = rawHref.replace(/#.*$/, '');
      if (seenUrls.has(normalizedUrl)) continue;
      seenUrls.add(normalizedUrl);

      const title = decodeHtmlEntities(aMatch[2]);
      const snippet = snippetMatch ? decodeHtmlEntities(snippetMatch[1]) : '';
      if (!title) continue;

      const meta = parseUrlMeta(normalizedUrl);
      items.push({
        title,
        link: normalizedUrl,
        publisher: meta.domain,
        pubDate: '',
        snippet: snippet || `${meta.domain} पर ${query} से संबंधित जानकारी देखें।`,
        domain: meta.domain,
        breadcrumb: meta.breadcrumb,
        isOfficial: meta.isOfficial,
      });
    }

    return items;
  } catch {
    return [];
  } finally {
    clearTimeout(timeout);
  }
}

function isOfficialDomainUrl(urlStr: string): boolean {
  try {
    const host = new URL(urlStr).hostname.toLowerCase();
    return /\.(gov\.in|nic\.in|gov|gov\.uk|gc\.ca|gov\.ae|gov\.au|go\.jp|gouv\.fr|gov\.sg|gov\.sa|govt\.nz|ac\.in|edu\.in|edu)$/i.test(
      host
    );
  } catch {
    return false;
  }
}

function extractCleanDomain(urlStr: string): string {
  try {
    return new URL(urlStr).hostname.replace(/^www\./, '');
  } catch {
    return urlStr;
  }
}

function curateOfficialSources(
  groundedSources: SourceItem[],
  matchedPortals: OfficialPortalInfo[],
  directResults: LiveWebResult[] = []
): SourceItem[] {
  const candidates: SourceItem[] = [];
  const seenDomains = new Set<string>();

  const blockedNonOfficialDomains = ['un.org', 'wikipedia.org', 'adda247.com', 'testbook.com', 'sarkariresult.com'];

  const addCandidate = (title: string, uri: string) => {
    if (!uri || !/^https?:\/\//i.test(uri)) return;
    if (uri.includes('vertexaisearch.cloud.google.com')) return;
    const domain = extractCleanDomain(uri).toLowerCase();
    if (seenDomains.has(domain)) return;
    seenDomains.add(domain);
    candidates.push({
      title: title || domain,
      uri,
    });
  };

  // 1. Prioritize matched official portals & grounded official URLs first
  for (const p of matchedPortals) {
    addCandidate(p.domain, p.url);
  }

  for (const s of groundedSources) {
    if (isOfficialDomainUrl(s.uri)) {
      addCandidate(extractCleanDomain(s.uri), s.uri);
    }
  }

  // 2. Include official direct web results if any
  for (const r of directResults) {
    if (r.isOfficial || isOfficialDomainUrl(r.link)) {
      addCandidate(r.domain, r.link);
    }
  }

  // 3. Fallback to remaining clean non-blocked links only if no official link found
  if (candidates.length === 0) {
    for (const s of groundedSources) {
      const dom = extractCleanDomain(s.uri).toLowerCase();
      if (!blockedNonOfficialDomains.some((b) => dom.endsWith(b))) {
        addCandidate(extractCleanDomain(s.uri), s.uri);
      }
    }
    for (const r of directResults) {
      const dom = r.domain.toLowerCase();
      if (!blockedNonOfficialDomains.some((b) => dom.endsWith(b))) {
        addCandidate(r.domain, r.link);
      }
    }
  }

  return candidates.slice(0, 1);
}

function cleanLiveSnippet(raw: string): string {
  return raw
    .replace(/https?:\/\/\S+/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function isGeneralNonFormQuery(prompt: string): boolean {
  const lower = prompt.toLowerCase();
  if (
    isMedicineOrHealthQuery(prompt) ||
    isCitizenServiceQuery(prompt) ||
    /\bpan\b|pancard|pan\s*card|पैन|passport|पासपोर्ट|driving licen|parivahan/i.test(lower)
  ) {
    return false;
  }
  return /(बिजली बिल|अस्पताल बिल|\bbill\b|\breceipt\b|रसीद|होमवर्क|\bhomework\b|ब्याज|\binterest\b|\bemi\b|प्रार्थना पत्र|\bapplication letter\b|\breels\b|\bwhatsapp\b|स्टेटस)/i.test(
    lower
  );
}

function synthesizeDirectChatAnswer(
  prompt: string,
  directResults: LiveWebResult[],
  officialPortals: OfficialPortalInfo[],
  language: string,
  location: string
): { text: string; sources: SourceItem[] } {
  const isEnglish = language === 'en';
  const lower = prompt.toLowerCase();
  const topPortal = officialPortals[0];
  const officialWebHits = directResults.filter((r) => r.isOfficial || isOfficialDomainUrl(r.link));
  const usableSnippets = (officialWebHits.length > 0 ? officialWebHits : directResults)
    .map((r) => cleanLiveSnippet(r.snippet))
    .filter((s) => s.length > 35 && s.length < 240 && !/no\.\s*\d+\/\d{4}/i.test(s))
    .slice(0, 2);

  // 0A. Medicine & Health Queries — NEVER attach govt portals like services.india.gov.in
  if (isMedicineOrHealthQuery(prompt)) {
    const medicineSnippets = directResults
      .map((r) => cleanLiveSnippet(r.snippet))
      .filter((s) => s.length > 25);
    return {
      text: buildStructuredMedicineReply(prompt, medicineSnippets, language),
      sources: [],
    };
  }

  const sources = curateOfficialSources([], officialPortals, directResults);
  const verifiedDomain = sources[0]?.title || topPortal?.domain || '';
  const departmentName = topPortal?.name || (verifiedDomain ? `${location} Official Department Portal (${verifiedDomain})` : location);
  const resolvedCitizen = resolveCitizenPortalForQuery(prompt, location);
  const usesRajasthanSso =
    /rpsc|rssb|rsmssb|जन\s*आधार|sso\.rajasthan/i.test(prompt) ||
    resolvedCitizen.meta?.key === 'rajasthan';

  // 0B. General non-form query (bills / homework / EMI / letters)
  if (!isEnglish && isGeneralNonFormQuery(prompt)) {
    const snippetBlock = usableSnippets.length
      ? usableSnippets.map((s) => `• ${s}`).join('\n')
      : `• **"${prompt}"** से जुड़े मुख्य बिंदु और सरल मार्गदर्शन नीचे दिए गए हैं:`;

    const text = [
      `### 📌 विषय का सारांश`,
      snippetBlock,
      `• यदि आपने किसी बिल, रसीद या विषय से जुड़ा सवाल पूछा है, तो आप स्पष्ट फोटो अपलोड करके भी तुरंत विस्तृत जानकारी प्राप्त कर सकते हैं।`,
      ``,
      `### 📋 मुख्य बिंदु और जानकारी`,
      `• **स्पष्ट विवरण:** ऊपर दिए गए विषय के अनुसार प्रत्येक मुख्य जानकारी को सरल चरणों में समझाया गया है।`,
      `• **बिल / गणित / हिसाब:** सभी संख्याओं, ब्याज दर या देय तिथि की दोबारा जांच कर लें और भुगतान के बाद रसीद सुरक्षित रखें।`,
      ``,
      `### ✅ अगले कदम (Step-by-Step)`,
      `• **स्टेप 1:** अपने प्रश्न या दस्तावेज़ से जुड़े मुख्य विवरण (तारीख, राशि, नाम या फोटो) स्पष्ट लिखें।`,
      `• **स्टेप 2:** यदि आप चाहें तो स्पष्ट प्रश्न या संख्या लिखकर आगे का पूरा हल यहीं चैट में पूछ सकते हैं।`,
    ].join('\n');

    return { text, sources: [] };
  }

  // 1. CATEGORY 1: Citizen Services / Cards / Global e-Government Portals
  const isPan = /\bpan\b|pancard|pan\s*card|पैन|e-?pan/i.test(lower);
  const isDriving = /driving licen|parivahan|sarathi|ड्राइविंग लाइसेंस/i.test(lower);
  const isPassport = /passport|पासपोर्ट/i.test(lower);
  const isRationOrAyushman = /राशन|ration|आयुष्मान|ayushman|pmjay|nfsa/i.test(lower);
  const isCitizenCertificate = isCitizenServiceQuery(prompt);

  if (isPan) {
    return {
      text: isEnglish
        ? [
            `Here is the official guide to apply for a new **PAN Card** in India:`,
            ``,
            `• **Official Portals:** **incometax.gov.in** (Free Instant e-PAN) and **onlineservices.nsdl.com** (Physical PAN Card delivered by post).`,
            `• **Real Government Fees:**`,
            `  - **Instant e-PAN (Digital PDF via Aadhaar e-KYC):** **₹0 (Completely Free)**`,
            `  - **Physical PAN Card (Indian Address):** **₹107** (inclusive of GST)`,
            `• **Required Documents:** Aadhaar Card, Aadhaar-linked mobile number (for OTP), 2 passport-size photos, and signature on white paper (for NSDL physical card).`,
            `• **Step-by-Step Apply Process:**`,
            `  1. Open **incometax.gov.in** (select *Instant e-PAN*) or **onlineservices.nsdl.com** (*Form 49A*) using the Apply button below.`,
            `  2. Enter your 12-digit Aadhaar number and verify with OTP.`,
            `  3. Confirm personal details, pay ₹107 (for physical card via NSDL), submit, and download your acknowledgment / e-PAN PDF.`,
          ].join('\n')
        : [
            `नया **पैन कार्ड (PAN Card)** बनवाने की पूरी और असली जानकारी नीचे दी गई है:`,
            ``,
            `• **आधिकारिक पोर्टल:** **incometax.gov.in** (मुफ्त Instant e-PAN) और **onlineservices.nsdl.com** (घर पर फिजिकल पैन कार्ड मंगवाने हेतु)।`,
            `• **असली सरकारी फीस:**`,
            `  - **Instant e-PAN (आधार e-KYC से डिजिटल पैन):** **₹0 (बिल्कुल फ्री)** — 10 मिनट में PDF डाउनलोड।`,
            `  - **नया फिजिकल पैन कार्ड (भारतीय पते पर डाक द्वारा):** **₹107** (GST सहित)।`,
            `• **ज़रूरी डॉक्यूमेंट:**`,
            `  - **आधार कार्ड**`,
            `  - **आधार से लिंक मोबाइल नंबर** (OTP सत्यापन के लिए)`,
            `  - **पासपोर्ट साइज फोटो** (20KB–50KB) व **सफेद कागज़ पर हस्ताक्षर / साइन** (10KB–20KB, NSDL फॉर्म हेतु)।`,
            `• **स्टेप-बाय-स्टेप बनाने का तरीका:**`,
            `  1. नीचे दिए हरे बटन से **incometax.gov.in** खोलें और **"Instant e-PAN"** चुनें (या फिजिकल कार्ड के लिए NSDL पर **Form 49A** चुनें)।`,
            `  2. अपना 12 अंकों का आधार नंबर दर्ज कर मोबाइल पर आए OTP से e-KYC सत्यापित करें।`,
            `  3. नाम, जन्मतिथि व पता जांचकर सबमिट करें (फिजिकल कार्ड के लिए ₹107 ऑनलाइन फीस जमा करें) और रसीद/e-PAN PDF डाउनलोड करें।`,
          ].join('\n'),
      sources: [{ title: 'incometax.gov.in', uri: 'https://www.incometax.gov.in/iec/foportal/' }],
    };
  }

  // Indian Driving License unless query/location explicitly resolves to a Global country
  if (isDriving && (!resolvedCitizen.meta || resolvedCitizen.meta.scope === 'india')) {
    return {
      text: isEnglish
        ? [
            `Here is the official guide for **Driving Licence (LL / DL)** in India:`,
            ``,
            `• **Official Portal:** Ministry of Road Transport & Highways — **parivahan.gov.in** (Sarathi Parivahan)`,
            `• **Real Government Fees:** Learner's Licence (LL): **₹150–₹200** | Permanent Driving Licence (DL + Smart Card): **₹400–₹700** (varies slightly by state).`,
            `• **Required Documents:** Aadhaar Card (for contactless e-KYC), Age & Address Proof, Form 1 / Form 1A (if age 40+), Passport Photo & Signature.`,
            `• **Step-by-Step Apply Process:**`,
            `  1. Open **parivahan.gov.in** via the button below, select *Driving Licence Related Services*, and pick your state.`,
            `  2. Apply for Learner's Licence via Aadhaar authentication (or RTO slot) and take the online LL test.`,
            `  3. After 30 days of holding LL, apply for Permanent DL, pay the fee, and book your driving test slot.`,
          ].join('\n')
        : [
            `भारत में **ड्राइविंग लाइसेंस (Driving Licence — LL / DL)** बनवाने की पूरी और असली जानकारी:`,
            ``,
            `• **आधिकारिक पोर्टल:** सड़क परिवहन एवं राजमार्ग मंत्रालय — **parivahan.gov.in** (Sarathi Parivahan)`,
            `• **असली सरकारी फीस:** लर्निंग लाइसेंस (LL): **₹150–₹200** | परमानेंट ड्राइविंग लाइसेंस (DL + स्मार्ट कार्ड): **₹400–₹700** (राज्य के अनुसार)।`,
            `• **ज़रूरी डॉक्यूमेंट:** आधार कार्ड (फेसलेस e-KYC हेतु), आयु व पते का प्रमाण, फॉर्म-1/1A (40 वर्ष से अधिक होने पर मेडिकल), पासपोर्ट फोटो व हस्ताक्षर।`,
            `• **स्टेप-बाय-स्टेप आवेदन तरीका:**`,
            `  1. नीचे दिए हरे बटन से **parivahan.gov.in** खोलें, *Driving Licence Related Services* चुनें और अपना राज्य चुनें।`,
            `  2. आधार e-KYC के माध्यम से Learner's Licence (LL) आवेदन करें, ऑनलाइन फीस जमा कर घर बैठे LL टेस्ट दें।`,
            `  3. LL बनने के 30 दिन बाद Permanent DL के लिए आवेदन कर RTO ड्राइविंग टेस्ट स्लॉट बुक करें।`,
          ].join('\n'),
      sources: [{ title: 'parivahan.gov.in', uri: 'https://parivahan.gov.in/' }],
    };
  }

  // Indian Passport (unless Global country explicitly chosen/asked)
  if (isPassport && (!resolvedCitizen.meta || resolvedCitizen.meta.scope === 'india')) {
    return {
      text: isEnglish
        ? [
            `Official guide to apply for an **Indian Passport**:`,
            ``,
            `• **Official Portal:** Ministry of External Affairs (MEA) — **passportindia.gov.in**`,
            `• **Real Government Fees:** Normal (36 pages, 10 years): **₹1,500** | Tatkaal: **₹3,500** | Minor: **₹1,000**.`,
            `• **Required Documents:** Aadhaar Card / Voter ID / Address proof, Birth Certificate or 10th Marksheet, and appointment slip.`,
            `• **Step-by-Step Process:** Register on **passportindia.gov.in**, fill *Apply for Fresh Passport*, pay ₹1,500, and visit your selected Passport Seva Kendra (PSK) on the appointment date.`,
          ].join('\n')
        : [
            `भारतीय पासपोर्ट (Passport) ऑनलाइन आवेदन की पूरी जानकारी नीचे दी गई है:`,
            ``,
            `• **विभाग व आधिकारिक पोर्टल:** विदेश मंत्रालय (MEA) — **passportindia.gov.in**`,
            `• **असली सरकारी फीस:** सामान्य (36 पेज, 10 वर्ष): **₹1,500** | तत्काल: **₹3,500** | नाबालिग: **₹1,000**।`,
            `• **ज़रूरी डॉक्यूमेंट:** आधार कार्ड / वोटर आईडी / पते का प्रमाण, जन्म प्रमाण पत्र या 10वीं की मार्कशीट, और अपॉइंटमेंट रसीद।`,
            `• **स्टेप-बाय-स्टेप तरीका:**`,
            `  1. नीचे दिए हरे बटन से **passportindia.gov.in** पर जाकर *New User Registration* करें।`,
            `  2. लॉगिन कर *Apply for Fresh Passport / Re-issue* चुनें और फॉर्म भरें।`,
            `  3. नज़दीकी Passport Seva Kendra (PSK) की तारीख चुनकर शुल्क ऑनलाइन जमा करें और तय दिन दस्तावेज़ सत्यापन करवाएं।`,
          ].join('\n'),
      sources: [{ title: 'passportindia.gov.in', uri: 'https://www.passportindia.gov.in/' }],
    };
  }

  // Ration Card & Ayushman Bharat (dynamic state reference when active)
  if (isRationOrAyushman && (!resolvedCitizen.meta || resolvedCitizen.meta.scope === 'india')) {
    const stateNote = resolvedCitizen.meta
      ? `${resolvedCitizen.meta.label} (${resolvedCitizen.meta.domain})`
      : 'All India (NFSA / PM-JAY)';
    return {
      text: isEnglish
        ? [
            `Official guide for **Ration Card (NFSA) & Ayushman Bharat Card (PM-JAY)** — **${stateNote}**:`,
            ``,
            `• **Official Portals:** **beneficiary.nha.gov.in** (Ayushman Card) & **nfsa.gov.in** (Ration Card).`,
            `• **Government Fee:** Ayushman Bharat Card (PM-JAY) **₹0 (Free)** | Ration Card application/update fee **₹0–₹50** at CSC/state portal.`,
            `• **Required Documents:** Aadhaar Card (mobile-linked), Ration/Family ID, and Passport Photo.`,
            `• **Step-by-Step Process:** Open **beneficiary.nha.gov.in** via the button below, verify mobile OTP, check eligibility/e-KYC, and download your Ayushman Card PDF.`,
          ].join('\n')
        : [
            `**राशन कार्ड (NFSA) व आयुष्मान भारत कार्ड (PM-JAY)** ऑनलाइन आवेदन की पूरी जानकारी (**${stateNote}**):`,
            ``,
            `• **आधिकारिक पोर्टल:** **beneficiary.nha.gov.in** (आयुष्मान कार्ड) एवं **nfsa.gov.in** (राष्ट्रीय खाद्य सुरक्षा राशन पोर्टल)।`,
            `• **असली सरकारी फीस:** आयुष्मान भारत कार्ड (PM-JAY) **₹0 (बिल्कुल मुफ्त)** | राशन कार्ड आवेदन/संशोधन शुल्क **₹0 से ₹50** (राज्य पोर्टल/CSC के अनुसार)।`,
            `• **ज़रूरी डॉक्यूमेंट:** आधार कार्ड (मोबाइल नंबर लिंक होना आवश्यक), परिवार पहचान/राशन कार्ड व पासपोर्ट साइज फोटो।`,
            `• **स्टेप-बाय-स्टेप आवेदन तरीका:**`,
            `  1. नीचे दिए हरे बटन से **beneficiary.nha.gov.in** खोलें और मोबाइल OTP से लॉगिन करें।`,
            `  2. राज्य व आधार/राशन नंबर दर्ज कर पात्रता जांचें और e-KYC पूरा करें।`,
            `  3. सत्यापन के बाद अपना आयुष्मान / राशन कार्ड PDF डाउनलोड करें।`,
          ].join('\n'),
      sources: [{ title: 'beneficiary.nha.gov.in', uri: 'https://beneficiary.nha.gov.in/' }],
    };
  }

  // Dynamic All-India State Citizen Portal & Global National Citizen Portal Resolution
  if (
    isCitizenCertificate ||
    (resolvedCitizen.meta?.scope === 'global' &&
      /visa|वीज़ा|driving|licence|license|passport|पासपोर्ट|tax|नौकरी|govt|सरकारी|\bpr\b|permit|immigration|citizenship|resident|work pass/i.test(
        lower
      ))
  ) {
    // When location is 'Global / World' and user did NOT name any state or country, NEVER force Rajasthan!
    if (resolvedCitizen.isAmbiguousGlobal || !resolvedCitizen.meta) {
      return {
        text: isEnglish
          ? [
              `### 🌍 Select Your State (India) or Country for Citizen Services`,
              `Your region is currently set to **Global / World**, and you haven't specified a state or country yet. Official digital citizen portals, fees, and documents differ by state and country:`,
              ``,
              `• **Which Indian State or Country do you need help with?** Just reply with the name (e.g., **"Bihar"**, **"MP"**, **"UP"**, **"Rajasthan"**, **"Maharashtra"**, **"Delhi"**, **"UAE"**, **"Saudi Arabia"**, **"USA"**, **"UK"**, **"Canada"**) or select it from the **Region Selector** at the top!`,
              `• **All-India Unified Portal:** **services.india.gov.in** connects all Indian state e-District / ServicePlus portals:`,
              `  - **Madhya Pradesh:** mpedistrict.gov.in / mponline.gov.in | **Uttar Pradesh:** edistrict.up.gov.in`,
              `  - **Bihar:** serviceonline.bihar.gov.in (RTPS) | **Rajasthan:** sso.rajasthan.gov.in`,
              `  - **Maharashtra:** aaplesarkar.mahaonline.gov.in | **Delhi:** edistrict.delhigovt.nic.in`,
              `  - **Global Portals:** USA (usa.gov), UK (gov.uk), UAE (u.ae / icp.gov.ae), Saudi (absher.sa), Canada (canada.ca)`,
            ].join('\n')
          : [
              `### 🌍 कृपया अपना राज्य (भारत) या देश बताएं — सटीक ई-मित्र / सरकारी सेवा पोर्टल के लिए`,
              `अभी आपका क्षेत्र **Global / World** पर सेट है और आपने किसी विशेष राज्य या देश का नाम नहीं लिखा है। हर राज्य और देश का आधिकारिक पोर्टल, फीस और दस्तावेज़ अलग होते हैं:`,
              ``,
              `• **कृपया चैट में अपने राज्य या देश का नाम लिखें** (या ऊपर हेडर में **Region Selector** से चुनें), जैसे:`,
              `  - **भारत के प्रमुख राज्य:** *मध्य प्रदेश (MP)*, *उत्तर प्रदेश (UP)*, *बिहार (Bihar)*, *राजस्थान*, *महाराष्ट्र*, *दिल्ली*, *गुजरात*, *हरियाणा*, *छत्तीसगढ़*, *झारखंड* आदि।`,
              `  - **प्रमुख वैश्विक देश:** *UAE (Dubai)*, *Saudi Arabia (Absher)*, *USA*, *UK*, *Canada*, *Australia*, *Singapore*, *Germany*।`,
              `• **All-India केंद्रीय सेवा पोर्टल:** आप नीचे दिए हरे बटन से **services.india.gov.in** खोलकर भी भारत के किसी भी राज्य का **e-District / ServicePlus** पोर्टल चुन सकते हैं।`,
              `• **उदाहरण के लिए लिखें:** *"बिहार जाति और आवासीय प्रमाण पत्र"*, *"MP मूल निवास और आय प्रमाण पत्र"*, या *"UAE Emirates ID कैसे बनाएं"* — मैं तुरंत उसी राज्य/देश की असली फीस, दस्तावेज़ और सीधा लिंक दूंगा!`,
            ].join('\n'),
        sources: [{ title: 'services.india.gov.in', uri: 'https://services.india.gov.in/' }],
      };
    }

    const meta = resolvedCitizen.meta;
    return {
      text: isEnglish
        ? [
            `Official Digital Citizen Services Guide for **${meta.label}**:`,
            ``,
            `• **Official Portal:** ${meta.portalName} (**${meta.domain}**)`,
            `• **Official Fees:** ${meta.feeEn}`,
            `• **Required Documents:** ${meta.docsEn}`,
            `• **Step-by-Step Process:**`,
            ...meta.stepsEn.map((step, i) => `  ${i + 1}. ${step}`),
          ].join('\n')
        : [
            `**${meta.label}** — आधिकारिक डिजिटल नागरिक सेवा व प्रमाण पत्र गाइड:`,
            ``,
            `• **आधिकारिक पोर्टल:** ${meta.portalName} (**${meta.domain}**)`,
            `• **असली सरकारी फीस:** ${meta.feeHi}`,
            `• **ज़रूरी डॉक्यूमेंट:** ${meta.docsHi}`,
            `• **स्टेप-बाय-स्टेप आवेदन प्रक्रिया:**`,
            ...meta.stepsHi.map((step, i) => `  ${i + 1}. ${step}`),
          ].join('\n'),
      sources: [{ title: meta.domain, uri: meta.url }],
    };
  }

  // 2. School / College Admission / Scholarship
  const isAdmission = /एडमिशन|admission|स्कूल|कॉलेज|college|university|cuet|scholarship|छात्रवृत्ति/i.test(lower);
  if (!isEnglish && isAdmission) {
    return {
      text: [
        `**${prompt}** से जुड़ी प्रवेश (Admission) जानकारी:`,
        ``,
        `• **आधिकारिक पोर्टल:** ${topPortal?.name || 'केंद्रीय एवं राज्य विश्वविद्यालय प्रवेश पोर्टल'} (**${verifiedDomain}**)`,
        `• **पात्रता व कोर्स:** UG प्रवेश हेतु मान्यता प्राप्त बोर्ड से 12वीं उत्तीर्ण तथा PG हेतु स्नातक डिग्री; स्कूल प्रवेश हेतु पिछली कक्षा की अंकतालिका।`,
        `• **ज़रूरी डॉक्यूमेंट:** पिछली कक्षा की अंकतालिका, TC (Transfer Certificate), चरित्र प्रमाण पत्र (CC), आधार कार्ड, जाति/मूल निवास/आय प्रमाण पत्र, फोटो व साइन।`,
        `• **प्रवेश प्रक्रिया:** नीचे दिए हरे बटन से आधिकारिक प्रवेश पोर्टल (**${verifiedDomain}**) पर जाएं, छात्र पंजीकरण करें, कॉलेज/कोर्स की प्राथमिकता चुनें और ऑनलाइन पंजीकरण शुल्क जमा कर रसीद सुरक्षित रखें।`,
      ].join('\n'),
      sources,
    };
  }

  // 3. Explicit Recruitment / Govt Job query (NO canned ₹400-₹600 or 10वीं/12वीं boilerplate)
  const isGovtJob =
    /rpsc|rssb|rsmssb|ssc|upsc|railway|rrb|ibps|police|सरकारी नौकरी|भर्ती|vacancy|recruitment|exam|परीक्षा/i.test(lower);
  if (!isEnglish && isGovtJob) {
    const liveBullets = usableSnippets.length
      ? usableSnippets.map((s) => `• ${s}`).join('\n')
      : topPortal
        ? `• **विभाग विवरण:** ${topPortal.description}`
        : `• **आधिकारिक पोर्टल:** ${verifiedDomain}`;

    const otrLine = usesRajasthanSso
      ? `  2. **SSO ID (sso.rajasthan.gov.in)** से लॉगिन कर Recruitment Portal पर अपना **OTR (One-Time Registration)** पूरा करें।`
      : `  2. पोर्टल पर अपना **नया पंजीकरण / OTR** पूरा कर लॉगिन करें।`;

    return {
      text: [
        `**${prompt}** से जुड़ी ताज़ा आधिकारिक जानकारी:`,
        ``,
        liveBullets,
        `• **आधिकारिक वेबसाइट:** **${verifiedDomain}** (${departmentName})`,
        `• **महत्वपूर्ण बिंदु:** भर्ती विज्ञापन के अनुसार सटीक पदों की संख्या, आवेदन की शुरुआती व अंतिम तारीख, पात्रता, आयु सीमा और श्रेणी-वार आवेदन शुल्क **${verifiedDomain}** के ताज़ा नोटिफिकेशन में देखें।`,
        `• **ज़रूरी डॉक्यूमेंट:** आधार कार्ड, संबंधित शैक्षणिक अंकतालिकाएं, श्रेणी/मूल निवास प्रमाण पत्र, पासपोर्ट साइज फोटो (20KB–50KB) व साइन (10KB–20KB)।`,
        `• **आवेदन करने का तरीका:**`,
        `  1. नीचे दिए हरे बटन से **${verifiedDomain}** खोलें और संबंधित भर्ती का नोटिफिकेशन पढ़ें।`,
        otrLine,
        `  3. फॉर्म भरकर फोटो-साइन अपलोड करें, निर्धारित शुल्क जमा कर फाइनल प्रिंट सुरक्षित रखें।`,
      ].join('\n'),
      sources,
    };
  }

  // 4. Dynamic general response from live search snippets (zero fixed templates & no forced services.india.gov.in)
  if (isEnglish) {
    const liveLines = usableSnippets.length
      ? usableSnippets.map((s) => `• ${s}`).join('\n')
      : verifiedDomain
        ? `• Live verified information for **${prompt}** is available on **${verifiedDomain}**.`
        : `• Here is general guidance for **${prompt}**.`;

    return {
      text: [
        `Here is the information regarding **${prompt}**:`,
        ``,
        liveLines,
        verifiedDomain ? `• **Official Reference:** **${verifiedDomain}**` : '',
        `• You can ask a more specific follow-up question here in chat anytime.`,
      ]
        .filter(Boolean)
        .join('\n'),
      sources,
    };
  }

  const dynamicSnippets = usableSnippets.length
    ? usableSnippets.map((s) => `• ${s}`).join('\n')
    : verifiedDomain
      ? `• **"${prompt}"** से जुड़ी ताज़ा व सटीक जानकारी आधिकारिक पोर्टल (**${verifiedDomain}**) पर उपलब्ध है।`
      : `• **"${prompt}"** के बारे में अपना स्पष्ट सवाल या संबंधित विवरण लिखें (जैसे नाम, विषय या फोटो) — मैं तुरंत सटीक जानकारी दूंगा।`;

  return {
    text: [
      `**${prompt}** से जुड़ी जानकारी:`,
      ``,
      dynamicSnippets,
      `• यदि आप इस विषय से जुड़ा कोई खास विवरण (जैसे प्रक्रिया, शुल्क, नियम या उदाहरण) जानना चाहते हैं, तो कृपया स्पष्ट रूप से पूछें — मैं तुरंत विस्तार से बता दूंगा।`,
    ].join('\n'),
    sources,
  };
}

function getClientIp(req: express.Request): string {
  const forwarded = req.headers['x-forwarded-for'];
  if (typeof forwarded === 'string' && forwarded.trim()) {
    return forwarded.split(',')[0].trim();
  }
  return req.ip || req.socket.remoteAddress || 'unknown';
}

function checkRateLimit(ip: string): { allowed: boolean; retryAfterSec: number } {
  const now = Date.now();
  const windowStart = now - RATE_WINDOW_MS;
  const timestamps = (rateLimitMap.get(ip) || []).filter((ts) => ts > windowStart);

  if (timestamps.length >= MAX_API_REQUESTS_PER_MINUTE) {
    const oldest = timestamps[0] || now;
    const retryAfterSec = Math.max(1, Math.ceil((oldest + RATE_WINDOW_MS - now) / 1000));
    rateLimitMap.set(ip, timestamps);
    return { allowed: false, retryAfterSec };
  }

  timestamps.push(now);
  rateLimitMap.set(ip, timestamps);

  if (rateLimitMap.size > 500) {
    for (const [key, list] of rateLimitMap.entries()) {
      const valid = list.filter((ts) => ts > windowStart);
      if (valid.length === 0) {
        rateLimitMap.delete(key);
      } else {
        rateLimitMap.set(key, valid);
      }
    }
  }

  return { allowed: true, retryAfterSec: 0 };
}

function buildCacheKey(prompt: string, language: string, location: string): string {
  const normalizedPrompt = prompt.trim().replace(/\s+/g, ' ').toLowerCase();
  return `${language}::${location.toLowerCase()}::${normalizedPrompt}`;
}

function getCachedEntry(key: string): CacheEntry | null {
  const entry = searchCache.get(key);
  if (!entry) return null;
  if (Date.now() > entry.expiresAt) {
    searchCache.delete(key);
    return null;
  }
  searchCache.delete(key);
  searchCache.set(key, entry);
  return entry;
}

function setCachedEntry(key: string, text: string, sources: SourceItem[]) {
  if (searchCache.size >= MAX_CACHE_ENTRIES) {
    const oldestKey = searchCache.keys().next().value;
    if (oldestKey !== undefined) {
      searchCache.delete(oldestKey);
    }
  }
  searchCache.set(key, {
    text,
    sources,
    expiresAt: Date.now() + CACHE_TTL_MS,
  });
}

function createGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function tryGeminiWithFallback(
  contents: Array<{ role: 'user' | 'model'; parts: Array<Record<string, unknown>> }>,
  systemInstructionText: string
): Promise<{ text: string; sources: SourceItem[] } | null> {
  if (Date.now() < geminiCooldownUntil) {
    return null;
  }

  const ai = createGeminiClient();
  if (!ai) return null;

  const attempts: Array<{ model: string; useSearch: boolean; useThinkingBudget0: boolean }> = [
    { model: 'gemini-3-flash-preview', useSearch: true, useThinkingBudget0: true },
    { model: 'gemini-2.5-flash', useSearch: true, useThinkingBudget0: true },
    { model: 'gemini-4-hydrogen', useSearch: true, useThinkingBudget0: false },
    { model: 'gemini-2.5-flash-lite', useSearch: true, useThinkingBudget0: true },
    { model: 'gemini-2.5-flash-lite', useSearch: false, useThinkingBudget0: true },
  ];

  let sawQuotaLimit = false;

  for (const attempt of attempts) {
    const config: Record<string, unknown> = {
      systemInstruction: systemInstructionText,
      maxOutputTokens: 1500,
    };
    if (attempt.useSearch) {
      config.tools = [{ googleSearch: {} }];
    }
    if (attempt.useThinkingBudget0) {
      config.thinkingConfig = { thinkingBudget: 0 };
    }

    try {
      const response = await ai.models.generateContent({
        model: attempt.model,
        contents,
        config,
      });

      const rawChunks = response?.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      const rawSupports = response?.candidates?.[0]?.groundingMetadata?.groundingSupports || [];

      const chunkSnippets = new Map<number, string>();
      for (const sup of rawSupports) {
        const segText = sup?.segment?.text?.trim();
        const indices: number[] = Array.isArray(sup?.groundingChunkIndices) ? sup.groundingChunkIndices : [];
        if (!segText) continue;
        for (const idx of indices) {
          if (!chunkSnippets.has(idx)) {
            chunkSnippets.set(idx, segText);
          }
        }
      }

      const rawSources: Array<{ title: string; uri: string; snippet?: string }> = [];
      const seen = new Set<string>();
      rawChunks.forEach((chunk: { web?: { uri?: string; title?: string } }, idx: number) => {
        const uri = chunk?.web?.uri;
        const title = chunk?.web?.title || uri;
        if (uri && !seen.has(uri)) {
          seen.add(uri);
          rawSources.push({
            title: String(title),
            uri: String(uri),
            snippet: chunkSnippets.get(idx),
          });
        }
      });

      const resolvedUris = await Promise.all(rawSources.slice(0, 8).map((s) => resolveDirectUrl(s.uri)));
      const sources: SourceItem[] = rawSources.slice(0, 8).map((s, idx) => ({
        title: s.title,
        uri: resolvedUris[idx] || s.uri,
        snippet: s.snippet,
      }));

      const rawText = response?.text;
      if (rawText && rawText.trim()) {
        return { text: rawText, sources };
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      const lower = msg.toLowerCase();
      if (msg.includes('429') || lower.includes('resource_exhausted') || lower.includes('quota')) {
        sawQuotaLimit = true;
      }
      const isRetryable =
        msg.includes('429') ||
        lower.includes('resource_exhausted') ||
        lower.includes('quota') ||
        msg.includes('404') ||
        lower.includes('not found') ||
        lower.includes('not supported') ||
        lower.includes('thinking');

      if (!isRetryable) {
        return null;
      }
    }
  }

  if (sawQuotaLimit) {
    // Enter a short 60s cooldown so searches return instantaneously without hitting 429 repeatedly
    geminiCooldownUntil = Date.now() + 60 * 1000;
  }

  return null;
}

function buildSystemInstruction(language: string, location: string, isMedicineQuery: boolean = false): string {
  const langNames: Record<string, string> = {
    hi: 'Hindi',
    en: 'English',
    ar: 'Arabic',
    es: 'Spanish',
    fr: 'French',
    de: 'German',
    ja: 'Japanese',
    pa: 'Punjabi',
    bn: 'Bengali',
    mr: 'Marathi',
    ta: 'Tamil',
    te: 'Telugu',
    gu: 'Gujarati',
    ur: 'Urdu',
  };
  const targetLang = langNames[language] || 'Hindi';

  if (isMedicineQuery) {
    const disclaimer = language === 'en' ? MEDICINE_DISCLAIMER_EN : MEDICINE_DISCLAIMER_HI;
    return `You are "SaarthiAI", a helpful, accurate medical & medicine information assistant.
LANGUAGE RULE:
- Answer in simple, clear ${targetLang} (easy to understand for everyday patients).
STRICT RULES FOR MEDICINE / TABLET / PRESCRIPTION QUERIES:
1. NEVER mention government portals (like services.india.gov.in, e-Mitra, e-District) or region settings for medicine queries!
2. Identify the medicine from its name or uploaded strip/prescription image accurately and present point-to-point details clearly:
   • **दवाई का नाम और साल्ट (Composition):** Exact active ingredient(s) & strength (e.g. Cefpodoxime Proxetil 200mg + Clavulanic Acid 125mg).
   • **किस काम आती है (Uses):** Clear list of infections or conditions this medicine is commonly prescribed for.
   • **कैसे ली जाती है (General Usage):** General timing/administration guidance (e.g., usually taken with/after food, swallow whole, complete full prescribed course — do NOT prescribe personal unverified doses).
   • **सावधानियां और साइड इफेक्ट्स (Side Effects & Precautions):** Common side effects (stomach upset, nausea, allergy, etc.) and key safety precautions.
3. End EVERY medicine answer with this exact warning line:
${disclaimer}`;
  }

  const resolved = resolveCitizenPortalForQuery('', location);
  const regionPortalHint = resolved.meta
    ? `CRITICAL REGION LOCK: The user has ALREADY selected "${location}" in the top Region Selector! Active Official Citizen Portal is ${resolved.meta.portalName} (${resolved.meta.domain}). NEVER claim their region is "Global / World", NEVER ask them which state or country they want, and NEVER default to services.india.gov.in unless All India is selected. Use ONLY ${resolved.meta.label}'s authentic portal, real local currency fees, and state/country-specific documents (unless the user explicitly names a different state/country in their prompt).`
    : `Current location is "Global / World". Do NOT force Rajasthan (sso.rajasthan.gov.in) when no Indian state or country is specified! If the user asks generically for "e-Mitra / e-District / Caste / Domicile / Income Certificate" without specifying a state or country, politely ask which Indian state (e.g., MP: mpedistrict.gov.in/mponline.gov.in, UP: edistrict.up.gov.in, Bihar: serviceonline.bihar.gov.in, Rajasthan: sso.rajasthan.gov.in, Maharashtra: aaplesarkar.mahaonline.gov.in, Delhi: edistrict.delhigovt.nic.in) or country (USA: usa.gov, UK: gov.uk, UAE: u.ae/icp.gov.ae, Saudi: absher.sa, Canada: canada.ca, Australia: my.gov.au, Singapore: singpass.gov.sg, Germany: id.bund.de) they want, and mention services.india.gov.in as the All-India citizen portal.`;

  return `You are "SaarthiAI", a friendly, accurate ChatGPT-style AI assistant for India (All States & UTs) & Global users.
LANGUAGE RULE:
- Answer naturally and clearly in simple ${targetLang} (or match the user's message language automatically).
ACTIVE REGION / LOCATION CONTEXT: ${location}
${regionPortalHint}
RULES:
1. Use Google Search Grounding to read live, verified facts from official government/university/trusted portals (.gov.in, .nic.in, .gov, .gov.uk, .gc.ca, .gov.ae, .gov.au, .go.jp, .gov.sg, .absher.sa, .bund.de, .gouv.fr, .govt.nz) matching the state/country in the user's prompt (priority #1) or active location.
2. Do NOT force fixed template headings and do NOT output website card lists or multiple raw URLs. Write a natural, well-structured ChatGPT-style response tailored specifically to the user's exact question.
3. For Citizen Portals & Cards (e.g. PAN Card / Pancard -> incometax.gov.in / onlineservices.nsdl.com ₹0 e-PAN / ₹107 physical; Driving Licence -> parivahan.gov.in; State e-District / e-Mitra / RTPS / Aaple Sarkar / MPOnline / Saral; Global Emirates ID / Absher / USCIS / GOV.UK / Singpass / BundID / myGov), provide ONLY authentic portal details, real fees in local currency (₹, USD, GBP, AED, SAR, CAD, AUD, SGD, EUR), exact required documents, and step-by-step instructions — NEVER include jobs, exams, or age-limit info for citizen card queries.
4. For Govt Jobs/Exams/Admissions, share verified dates, eligibility, fees, documents, and apply steps cleanly without fabricating unannounced dates.`;
}

app.post('/api/gemini/generate', async (req, res) => {
  req.setTimeout(30000);
  res.setTimeout(30000);

  try {
    const {
      prompt,
      history = [],
      imageBase64,
      language = 'hi',
      location = 'Global',
    } = req.body ?? {};

    if (!prompt || typeof prompt !== 'string') {
      res.status(400).json({ error: 'Prompt is required.' });
      return;
    }

    const isCacheable = (!Array.isArray(history) || history.length === 0) && !imageBase64;
    const cacheKey = isCacheable ? buildCacheKey(prompt, String(language), String(location)) : '';

    if (isCacheable && cacheKey) {
      const cached = getCachedEntry(cacheKey);
      if (cached) {
        res.json({
          text: cached.text,
          sources: cached.sources,
          cached: true,
        });
        return;
      }
    }

    const clientIp = getClientIp(req);
    const rateCheck = checkRateLimit(clientIp);
    if (!rateCheck.allowed) {
      res.setHeader('Retry-After', String(rateCheck.retryAfterSec));
      res.status(429).json({
        error:
          language === 'en'
            ? `Too many requests. Please wait ${rateCheck.retryAfterSec} seconds and try again.`
            : `बहुत अधिक अनुरोध भेजे गए हैं। कृपया ${rateCheck.retryAfterSec} सेकंड बाद पुनः प्रयास करें।`,
      });
      return;
    }

    const medicineQuery = isMedicineOrHealthQuery(
      prompt,
      Boolean(imageBase64),
      Array.isArray(history) ? history : []
    );
    const systemInstructionText = buildSystemInstruction(
      String(language),
      String(location),
      medicineQuery
    );

    const contents: Array<{ role: 'user' | 'model'; parts: Array<Record<string, unknown>> }> = [];
    if (Array.isArray(history)) {
      for (const h of history) {
        if (!h || !h.content) continue;
        contents.push({
          role: h.role === 'user' ? 'user' : 'model',
          parts: [{ text: String(h.content) }],
        });
      }
    }

    const currentParts: Array<Record<string, unknown>> = [];
    if (typeof imageBase64 === 'string' && imageBase64) {
      const match = imageBase64.match(/^data:(image\/[a-zA-Z0-9.+_-]+);base64,(.+)$/);
      if (match) {
        currentParts.push({
          inlineData: {
            mimeType: match[1],
            data: match[2],
          },
        });
      }
    }
    currentParts.push({ text: prompt });

    contents.push({
      role: 'user',
      parts: currentParts,
    });

    const officialPortals = medicineQuery ? [] : findOfficialPortals(prompt, String(location));
    const aiResult = await tryGeminiWithFallback(contents, systemInstructionText);

    if (aiResult && aiResult.text.trim()) {
      const falseGlobalClaim =
        !medicineQuery &&
        !isGlobalUnspecifiedLocation(String(location)) &&
        /Global\s*\/\s*World\s*(पर\s*सेट|set)|region is currently set to \*\*Global/i.test(aiResult.text);
      const falsePortalInMedicine =
        medicineQuery && /services\.india\.gov\.in|आधिकारिक पोर्टल/i.test(aiResult.text);

      if (!falseGlobalClaim && !falsePortalInMedicine) {
        let finalText = aiResult.text.trim();
        if (medicineQuery) {
          const disclaimer = String(language) === 'en' ? MEDICINE_DISCLAIMER_EN : MEDICINE_DISCLAIMER_HI;
          if (!/डॉक्टर से सलाह|consult.*doctor/i.test(finalText)) {
            finalText = `${finalText}\n\n${disclaimer}`;
          }
        }
        const curatedSources = medicineQuery
          ? []
          : curateOfficialSources(aiResult.sources, officialPortals);
        if (isCacheable && cacheKey) {
          setCachedEntry(cacheKey, finalText, curatedSources);
        }
        res.json({
          text: finalText,
          sources: curatedSources,
          cached: false,
        });
        return;
      }
    }

    // Graceful direct ChatGPT-style fallback using live fetched snippets + structured knowledge
    const searchQuery = medicineQuery
      ? `${prompt} medicine composition salt uses side effects`
      : `${prompt} official`;
    const directResults = await fetchDirectWebSearchResults(searchQuery);
    const fallback = medicineQuery
      ? {
          text: buildStructuredMedicineReply(
            prompt,
            directResults.map((r) => cleanLiveSnippet(r.snippet)).filter(Boolean),
            String(language)
          ),
          sources: [],
        }
      : synthesizeDirectChatAnswer(
          prompt,
          directResults,
          officialPortals,
          String(language),
          String(location)
        );

    if (isCacheable && cacheKey && (directResults.length > 0 || medicineQuery)) {
      setCachedEntry(cacheKey, fallback.text, fallback.sources);
    }

    res.json({
      text: fallback.text,
      sources: fallback.sources,
      cached: false,
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    console.warn('Gemini route graceful fallback:', message);
    const promptStr = typeof req.body?.prompt === 'string' ? req.body.prompt : '';
    const langStr = typeof req.body?.language === 'string' ? req.body.language : 'hi';
    const locStr = typeof req.body?.location === 'string' ? req.body.location : 'Global';
    const hasImg = Boolean(req.body?.imageBase64);
    const histArr = Array.isArray(req.body?.history) ? req.body.history : [];
    if (isMedicineOrHealthQuery(promptStr, hasImg, histArr)) {
      res.json({
        text: buildStructuredMedicineReply(promptStr, [], langStr),
        sources: [],
        cached: false,
      });
      return;
    }
    const officialPortals = findOfficialPortals(promptStr, locStr);
    const fallback = synthesizeDirectChatAnswer(promptStr, [], officialPortals, langStr, locStr);
    res.json({
      text: fallback.text,
      sources: fallback.sources,
      cached: false,
    });
  }
});

app.post('/api/gemini/generate-image', async (req, res) => {
  req.setTimeout(30000);
  res.setTimeout(30000);

  const clientIp = getClientIp(req);
  const rateCheck = checkRateLimit(clientIp);
  if (!rateCheck.allowed) {
    res.setHeader('Retry-After', String(rateCheck.retryAfterSec));
    res.status(429).json({
      error: `बहुत अधिक अनुरोध भेजे गए हैं। कृपया ${rateCheck.retryAfterSec} सेकंड बाद पुनः प्रयास करें।`,
    });
    return;
  }

  try {
    const { prompt } = req.body ?? {};
    if (!prompt || typeof prompt !== 'string') {
      res.status(400).json({ error: 'Prompt is required.' });
      return;
    }

    const ai = createGeminiClient();
    if (!ai) {
      res.status(503).json({ error: 'इमेज सेवा अभी उपलब्ध नहीं है।' });
      return;
    }

    const response = await ai.models.generateImages({
      model: 'imagen-3.0-generate-002',
      prompt: prompt.trim(),
      config: {
        numberOfImages: 1,
        outputMimeType: 'image/jpeg',
        aspectRatio: '1:1',
      },
    });

    const base64Bytes = response.generatedImages?.[0]?.image?.imageBytes;
    if (!base64Bytes) {
      res.status(500).json({ error: 'इमेज तैयार नहीं हो सकी। कृपया दूसरा विवरण लिखें।' });
      return;
    }

    res.json({ imageDataUrl: `data:image/jpeg;base64,${base64Bytes}` });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    console.warn('Gemini image generation warning:', message);
    res.status(500).json({ error: message || 'Image generation failed.' });
  }
});

function synthesizeResumeEnhancement(payload: {
  fullName: string;
  jobTitle: string;
  education: string;
  skills: string;
  experience: string;
  projects: string;
  isFresher: boolean;
  language: string;
}) {
  const role = payload.jobTitle.trim() || (payload.isFresher ? 'Graduate Trainee / Executive' : 'Office & Operations Executive');
  const edu = payload.education.trim() || 'Graduate (Bachelor Degree)';
  const rawSkills = payload.skills
    .split(/[,\n]+/)
    .map((s) => s.trim())
    .filter(Boolean);

  const lowerRole = role.toLowerCase();
  const isTech = /software|developer|engineer|web|react|java|python|it|computer|data|analyst|tech/i.test(lowerRole);
  const isFinance = /account|tally|gst|finance|bank|commerce|ca|audit|billing/i.test(lowerRole);
  const isSales = /sales|marketing|business|retail|store|customer|support|telecaller|bpo/i.test(lowerRole);
  const isTeacher = /teacher|tutor|faculty|lecturer|educator|शिक्षक/i.test(lowerRole);
  const useHindi = payload.language === 'hi';

  const roleSuggestedSkills = isTech
    ? ['HTML5 / CSS3', 'JavaScript / React', 'SQL / Database', 'Git & GitHub', 'MS Office', 'Problem Solving']
    : isFinance
      ? ['Tally Prime & ERP 9', 'GST Filing & TDS', 'Advanced MS Excel', 'Accounting & Reconciliation', 'MIS Reporting', 'Billing & Auditing']
      : isSales
        ? ['Client Relationship Management', 'Target Achievement', 'Communication & Negotiation', 'CRM Tools', 'MS Excel', 'Lead Generation']
        : isTeacher
          ? ['Curriculum Planning', 'Classroom Management', 'Smart Board / Digital Teaching', 'Student Mentoring', 'Bilingual Communication', 'Assessment Design']
          : ['MS Office (Excel, Word, PowerPoint)', 'Data Entry & Documentation', 'Email & Client Coordination', 'Time Management', 'Team Collaboration', 'Problem Solving'];

  const mergedSkillsSet = new Set<string>(rawSkills);
  for (const suggested of roleSuggestedSkills) {
    if (mergedSkillsSet.size >= 8) break;
    const alreadyExists = Array.from(mergedSkillsSet).some(
      (existing) => existing.toLowerCase() === suggested.toLowerCase()
    );
    if (!alreadyExists) {
      mergedSkillsSet.add(suggested);
    }
  }
  const finalSkills = Array.from(mergedSkillsSet).join(', ');

  let summary = '';
  let experience = payload.experience.trim();
  let projects = payload.projects.trim();

  if (useHindi) {
    summary = payload.isFresher
      ? `${edu} योग्यता और ${Array.from(mergedSkillsSet).slice(0, 3).join(', ')} में मजबूत पकड़ रखने वाला एक समर्पित और तेज़ी से सीखने वाला ${role}। अपनी तकनीकी व संवाद क्षमताओं के माध्यम से संगठन की कार्यक्षमता और लक्ष्यों को प्राप्त करने हेतु प्रतिबद्ध।`
      : `${role} के रूप में कार्य अनुभव एवं ${Array.from(mergedSkillsSet).slice(0, 3).join(', ')} में दक्षता रखने वाला परिणाम-उन्मुख पेशेवर। समयबद्ध कार्य निष्पादन, टीम समन्वय और गुणवत्तापूर्ण आउटपुट द्वारा कंपनी की उत्पादकता बढ़ाने में सक्षम।`;

    if (!experience || experience.length < 25) {
      experience = payload.isFresher
        ? `• ${role} डोमेन में व्यावहारिक प्रशिक्षण एवं 4-सप्ताह की प्रोजेक्ट इंटर्नशिप पूर्ण की।\n• डिजिटल डॉक्यूमेंटेशन, डेटा प्रबंधन और टीम के साथ समयबद्ध रिपोर्ट तैयार करने का अनुभव।`
        : `• ${role} के रूप में दैनिक संचालन, डेटा सटीकता और क्लाइंट/टीम समन्वय का सफल प्रबंधन किया।\n• नियमित रिपोर्टिंग और प्रक्रिया सुधार से कार्य-गति में उल्लेखनीय सुधार लाया।`;
    } else if (!experience.includes('•')) {
      experience = experience
        .split(/\n+/)
        .map((line) => (line.trim() ? `• ${line.trim()}` : ''))
        .filter(Boolean)
        .join('\n');
    }

    if (!projects || projects.length < 20) {
      projects = isTech
        ? `• रिस्पॉन्सिव वेब एप्लिकेशन व डेटा प्रबंधन डैशबोर्ड प्रोजेक्ट तैयार किया।\n• कंप्यूटर दक्षता एवं डिजिटल स्किल्स प्रमाणपत्र प्राप्त।`
        : `• शैक्षणिक एवं व्यावहारिक प्रोजेक्ट समय सीमा से पहले उच्च गुणवत्ता के साथ पूर्ण किया।\n• बेहतर प्रदर्शन, अनुशासन और टीम वर्क के लिए प्रशंसा प्राप्त।`;
    }
  } else {
    summary = payload.isFresher
      ? `Detail-oriented and motivated ${role} with ${edu} and hands-on proficiency in ${Array.from(mergedSkillsSet).slice(0, 3).join(', ')}. Eager to apply strong analytical, technical, and communication skills to deliver measurable value from day one.`
      : `Results-driven ${role} with practical experience in ${Array.from(mergedSkillsSet).slice(0, 3).join(', ')} and a track record of accurate execution. Skilled at streamlining workflows, collaborating cross-functionally, and consistently meeting operational targets.`;

    if (!experience || experience.length < 25) {
      experience = payload.isFresher
        ? `• Completed hands-on practical training & academic internship aligned with ${role} workflows.\n• Prepared structured reports, digital documentation, and collaborated effectively in team assignments.`
        : `• Managed core ${role} responsibilities with high accuracy, on-time delivery, and structured reporting.\n• Collaborated with stakeholders to resolve operational bottlenecks and improve process efficiency by 20%.`;
    } else if (!experience.includes('•')) {
      experience = experience
        .split(/\n+/)
        .map((line) => (line.trim() ? `• ${line.trim()}` : ''))
        .filter(Boolean)
        .join('\n');
    }

    if (!projects || projects.length < 20) {
      projects = isTech
        ? `• Built a responsive full-stack management project featuring clean UI, form validation, and structured reporting.\n• Certified in modern office automation & computer applications.`
        : isFinance
          ? `• Prepared monthly reconciliation, GST compliance sheets, and automated Excel MIS trackers.\n• Awarded recognition for accuracy and timely audit documentation.`
          : `• Executed end-to-end capstone project on workflow optimization and client service excellence.\n• Recognized for leadership, punctuality, and effective bilingual communication.`;
    }
  }

  return {
    summary,
    skills: finalSkills,
    experience,
    projects,
    enhancedWithAI: false,
  };
}

app.post('/api/resume/ai-enhance', async (req, res) => {
  req.setTimeout(25000);
  res.setTimeout(25000);

  const clientIp = getClientIp(req);
  const rateCheck = checkRateLimit(clientIp);
  if (!rateCheck.allowed) {
    res.setHeader('Retry-After', String(rateCheck.retryAfterSec));
    res.status(429).json({
      error: `बहुत अधिक अनुरोध भेजे गए हैं। कृपया ${rateCheck.retryAfterSec} सेकंड बाद पुनः प्रयास करें।`,
    });
    return;
  }

  const body = req.body ?? {};
  const payload = {
    fullName: String(body.fullName || 'Candidate').trim(),
    jobTitle: String(body.jobTitle || '').trim(),
    education: String(body.education || '').trim(),
    skills: String(body.skills || '').trim(),
    experience: String(body.experience || '').trim(),
    projects: String(body.projects || '').trim(),
    isFresher: Boolean(body.isFresher),
    language: String(body.language || 'en'),
  };

  try {
    const ai = Date.now() >= geminiCooldownUntil ? createGeminiClient() : null;
    if (ai) {
      const prompt = `Create crisp, ATS-optimized, modern resume sections for this candidate.
Candidate Name: ${payload.fullName}
Target Role: ${payload.jobTitle || (payload.isFresher ? 'Fresher / Entry-Level Executive' : 'Professional Executive')}
Status: ${payload.isFresher ? 'Fresher / Student' : 'Experienced'}
Education: ${payload.education || 'Not specified'}
Current Skills: ${payload.skills || 'Not specified'}
Current Experience Notes: ${payload.experience || 'None'}
Current Projects/Achievements Notes: ${payload.projects || 'None'}
Preferred Language Style: ${payload.language === 'hi' ? 'Clean professional Hindi (Devanagari script)' : 'Clean professional corporate English'}

Rules:
- summary: 2-3 punchy, tailored sentences showcasing value and skills (no first-person "I/my").
- skills: 6-8 comma-separated relevant technical & soft skills keeping the candidate's existing skills and adding role-aligned modern keywords.
- experience: 2-3 crisp bullet points starting with "• " using strong action verbs (for Freshers, write internship/practical training bullets).
- projects: 2 crisp bullet points starting with "• " highlighting concrete projects, certifications, or achievements.`;

      const models = ['gemini-4-hydrogen', 'gemini-2.5-flash', 'gemini-2.5-flash-lite'];
      for (const model of models) {
        try {
          const response = await ai.models.generateContent({
            model,
            contents: prompt,
            config: {
              systemInstruction:
                'You are an expert executive resume writer and ATS specialist. Return strictly valid JSON.',
              responseMimeType: 'application/json',
              responseSchema: {
                type: Type.OBJECT,
                properties: {
                  summary: { type: Type.STRING },
                  skills: { type: Type.STRING },
                  experience: { type: Type.STRING },
                  projects: { type: Type.STRING },
                },
                required: ['summary', 'skills', 'experience', 'projects'],
              },
            },
          });

          const rawJson = (response?.text || '').trim();
          if (rawJson) {
            const parsed = JSON.parse(rawJson);
            if (parsed.summary && parsed.skills) {
              res.json({
                summary: String(parsed.summary).trim(),
                skills: String(parsed.skills).trim(),
                experience: String(parsed.experience || '').trim(),
                projects: String(parsed.projects || '').trim(),
                enhancedWithAI: true,
              });
              return;
            }
          }
        } catch (modelErr: unknown) {
          const msg = modelErr instanceof Error ? modelErr.message : String(modelErr);
          if (msg.includes('429') || msg.toLowerCase().includes('quota')) {
            geminiCooldownUntil = Date.now() + 60 * 1000;
            break;
          }
        }
      }
    }
  } catch (err: unknown) {
    console.warn('Resume AI enhance fallback triggered:', err instanceof Error ? err.message : String(err));
  }

  res.json(synthesizeResumeEnhancement(payload));
});

async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.use((_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`SaarthiAI server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
